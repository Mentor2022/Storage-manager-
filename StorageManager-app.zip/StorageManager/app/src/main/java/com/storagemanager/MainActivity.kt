package com.storagemanager

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.format.Formatter
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.border
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private var storageOk by mutableStateOf(false)
    private var usageOk by mutableStateOf(false)

    private val legacyPerm =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            storageOk = hasStorage()
            if (storageOk) vm.scan()
        }

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private var askedNotif = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppConfig.load(this)
        LowSpaceWorker.schedule(this)
        UpdateWorker.schedule(this)
        enableEdgeToEdge()
        setContent {
            StorageTheme {
                Surface(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(), color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.checkUpdate()
        storageOk = hasStorage()
        usageOk = AppUsage.hasAccess(this)
        if (storageOk && !askedNotif && Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotif = true
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (storageOk && vm.result == null && !vm.scanning) vm.scan()
        else if (usageOk && vm.apps.isEmpty()) vm.refreshApps()
    }

    private fun hasStorage() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else {
            legacyPerm.launch(
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            )
        }
    }

    private fun requestUsage() = startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))

    // ───────────────────────── UI ─────────────────────────

    @Composable
    private fun App() {
        if (!storageOk) {
            PermissionScreen(); return
        }
        val snack = remember { SnackbarHostState() }
        var tab by remember { mutableIntStateOf(0) }
        var confirm by remember { mutableStateOf(false) }
        val everyTab = listOf(
            "Overview" to "overview", "Large" to "large", "Duplicates" to "duplicates", "Similar" to "similar", "Junk" to "junk", "WhatsApp" to "whatsapp",
            "Downloads" to "downloads", "Screenshots" to "screenshots", "Safety" to "safety", "Email" to "email", "Apps" to "apps", "Battery" to "battery", "Bin" to "bin",
        )
        // The admin can switch features off in the portal; Overview is always there
        val tabs = everyTab.filter { it.second == "overview" || it.second in AppConfig.features }.map { it.first }
        val tabKeys = everyTab.filter { it.second == "overview" || it.second in AppConfig.features }.map { it.second }

        LaunchedEffect(Unit) { vm.refreshBin() }
        LaunchedEffect(vm.message) {
            vm.message?.let { snack.showSnackbar(it); vm.message = null }
        }

        Scaffold(
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = { if (vm.selected.isNotEmpty()) DeleteBar { confirm = true } },
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                Header(vm.result)
                TopMenu(tabs, tabKeys, tab) { tab = it }
                vm.update?.let { UpdateBanner(it) }
                val r = vm.result
                if (vm.scanning || r == null) {
                    FancyLoader(
                        emoji = "🔍", title = "Scanning your phone",
                        subtitle = "Looking through your photos, videos and files. Nothing leaves your phone.",
                        detail = vm.progress.ifEmpty { "Starting…" },
                    )
                } else when (tabKeys.getOrElse(tab) { "overview" }) {
                    "overview" -> Overview(
                        r,
                        onSmartClean = { vm.clearSelection(); vm.selectAll(vm.smartPaths()); if (vm.selected.isNotEmpty()) confirm = true },
                        onGo = { key -> val i = tabKeys.indexOf(key); if (i >= 0) tab = i },
                    )
                    "large" -> LargeTab(r)
                    "duplicates" -> DuplicatesTab(r)
                    "similar" -> SimilarTab()
                    "junk" -> JunkTab(r)
                    "whatsapp" -> WhatsAppTab(r)
                    "downloads" -> SimpleTab(r.downloads, "Files in Downloads older than 60 days", "No old downloads.")
                    "screenshots" -> SimpleTab(r.screenshots, "Screenshots, biggest first", "No screenshots found.")
                    "safety" -> SafetyTab(r)
                    "email" -> EmailTab()
                    "bin" -> BinTab()
                    "battery" -> BatteryTab()
                    else -> AppsTab()
                }
            }
        }

        vm.preview?.let { f ->
            FilePreview(
                f, marked = f.path in vm.selected,
                onToggleMark = { vm.toggle(f.path) },
                onClose = { vm.preview = null },
            )
        }

        if (confirm) {
            AlertDialog(
                onDismissRequest = { confirm = false },
                title = { Text((if (vm.binOn) "Move " else "Delete ") + "${vm.selected.size} files" + (if (vm.binOn) " to the Bin?" else "?")) },
                text = {
                    Column {
                        Text(
                            (if (vm.binOn) "These go to the Bin (${fmt(vm.selectedBytes)}). You can undo for ${AppConfig.binDays} days; space is freed when they are removed from the Bin."
                            else "This frees ${fmt(vm.selectedBytes)} and cannot be undone.") + " Tap a file to look at it first."
                        )
                        Spacer(Modifier.height(8.dp))
                        vm.selected.take(6).forEach { p ->
                            val item = vm.fileFor(p)
                            Text(
                                (item?.name ?: p.substringAfterLast('/')) + (item?.let { " · " + fmt(it.size) } ?: ""),
                                Modifier.fillMaxWidth().clickable(enabled = item != null) { confirm = false; vm.preview = item }.padding(vertical = 6.dp),
                                maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                        if (vm.selected.size > 6) Text("and ${vm.selected.size - 6} more", style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = { TextButton(onClick = { confirm = false; vm.deleteSelected() }) { Text(if (vm.binOn) "Move to Bin" else "Delete") } },
                dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
            )
        }
    }

    @Composable
    private fun PermissionScreen() {
        Column(
            Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally
        ) {
            Text("🧹", fontSize = 72.sp)
            Spacer(Modifier.height(8.dp))
            Text("Free up your phone", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text(
                "To find big files, duplicates and junk, this app needs access to your files. " +
                    "Everything runs on your phone. No internet is used and nothing is uploaded."
            )
            Spacer(Modifier.height(20.dp))
            Button(onClick = { requestStorage() }) { Text("Allow file access") }
        }
    }

    @Composable
    private fun Overview(r: ScanResult, onSmartClean: () -> Unit, onGo: (String) -> Unit) {
        val total = r.total.coerceAtLeast(1)
        val usedFrac = (r.used.toFloat() / total).coerceIn(0f, 1f)
        val low = r.free.toFloat() / total < 0.10f
        val hero = if (low) Brush.linearGradient(listOf(Pal.orange, Pal.red)) else Brush.linearGradient(listOf(Pal.teal, Pal.blue))
        val dupWaste = r.duplicates.sumOf { it[0].size * (it.size - 1) }
        val tiles = listOf(
            listOf("🧹", "Junk", r.junk.sumOf { it.size }, Pal.orange, "junk"),
            listOf("👯", "Duplicates", if (vm.dupBusy) -1L else dupWaste, Pal.purple, "duplicates"),
            listOf("📦", "Large files", r.large.sumOf { it.size }, Pal.blue, "large"),
            listOf("💬", "WhatsApp", r.whatsapp.sumOf { it.size }, Pal.green, "whatsapp"),
            listOf("⬇️", "Old downloads", r.downloads.sumOf { it.size }, Pal.amber, "downloads"),
            listOf("📸", "Screenshots", r.screenshots.sumOf { it.size }, Pal.pink, "screenshots"),
        )
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item {
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(hero).padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StorageRing(usedFrac, 124.dp, Color.White.copy(alpha = 0.28f), Color.White) {
                            Text("${(usedFrac * 100).toInt()}%", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(18.dp))
                        Column {
                            Text("${fmt(r.free)} free", color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Text("${fmt(r.used)} used of ${fmt(r.total)}", color = Color.White.copy(alpha = 0.92f))
                            Spacer(Modifier.height(8.dp))
                            Text(
                                if (low) "Almost full. Try Smart clean below." else "Your phone has room to breathe.",
                                color = Color.White.copy(alpha = 0.92f), style = MaterialTheme.typography.bodySmall,
                            )
                        }
                    }
                }
            }
            if ("smart" in AppConfig.features) {
                val smart = vm.smartPaths()
                val known = (r.junk + r.duplicates.flatten()).associateBy { it.path }
                val bytes = smart.sumOf { known[it]?.size ?: 0L }
                if (smart.isNotEmpty()) {
                    item {
                        Box(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp))
                                .background(Brush.linearGradient(listOf(Pal.purple, Pal.pink))).padding(18.dp)
                        ) {
                            Column {
                                Text("✨ Smart clean", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "${smart.size} safe files · ${fmt(bytes)} of junk and extra copies. One copy of every file stays, and you see the list first.",
                                    color = Color.White.copy(alpha = 0.95f), style = MaterialTheme.typography.bodyMedium,
                                )
                                Spacer(Modifier.height(12.dp))
                                Button(
                                    onClick = onSmartClean, Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Pal.purple),
                                ) { Text("Clean ${fmt(bytes)} now", fontWeight = FontWeight.Bold) }
                            }
                        }
                    }
                }
            }
            if (vm.freedTotal > 0) {
                item {
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Pal.green.copy(alpha = 0.16f)).padding(14.dp)) {
                        Text("🎉 You have freed ${fmt(vm.freedTotal)} with this app", fontWeight = FontWeight.SemiBold)
                    }
                }
            }
            item { Text("Easy wins", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            tiles.chunked(2).forEach { pair ->
                item {
                    Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(12.dp)) {
                        pair.forEach { t ->
                            WinTile(t[0] as String, t[1] as String, t[2] as Long, t[3] as Color, Modifier.weight(1f)) { onGo(t[4] as String) }
                        }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
            item { Text("What's taking space", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold) }
            val max = r.byCategory.values.maxOrNull()?.coerceAtLeast(1) ?: 1
            items(r.byCategory.entries.sortedByDescending { it.value }.toList()) { (cat, bytes) ->
                val c = catColor(cat)
                Column {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Text(catEmoji(cat) + "  " + cat.label); Text(fmt(bytes), fontWeight = FontWeight.SemiBold)
                    }
                    Spacer(Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { bytes.toFloat() / max },
                        modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(5.dp)),
                        color = c, trackColor = c.copy(alpha = 0.18f),
                    )
                }
            }
            item {
                OutlinedButton(onClick = { vm.scan() }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) { Text("🔄  Scan again") }
            }
        }
    }

    /** App name, free space and a rescan button. */
    @Composable
    private fun Header(r: ScanResult?) {
        val ctx = LocalContext.current
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 16.dp, top = 14.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(ctx.getString(R.string.app_name), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    if (r != null && !vm.scanning) "${fmt(r.free)} free of ${fmt(r.total)}" else "Checking your phone…",
                    style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant).clickable(enabled = !vm.scanning) { vm.scan() },
                Alignment.Center,
            ) { Text("🔄", fontSize = 18.sp) }
        }
    }

    /** Shown under the menu when a newer version is ready. */
    @Composable
    private fun UpdateBanner(u: UpdateInfo) {
        val ctx = LocalContext.current
        Column(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp).padding(bottom = 10.dp)
                .clip(RoundedCornerShape(20.dp)).background(Brush.linearGradient(listOf(Pal.purple, Pal.blue))).padding(16.dp)
        ) {
            Text("🆕 New version ${u.version} is ready", color = Color.White, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
            if (u.notes.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(u.notes, color = Color.White.copy(alpha = 0.92f), style = MaterialTheme.typography.bodySmall, maxLines = 3, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick = { safeStart(ctx, Intent(Intent.ACTION_VIEW, Uri.parse(u.url))) }, shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Pal.purple),
                ) { Text("Update now", fontWeight = FontWeight.Bold) }
                TextButton(onClick = { vm.dismissUpdate() }) { Text("Later", color = Color.White) }
            }
        }
    }

    /** The menu: soft pills that slide along; the chosen one is filled and always scrolled into view. */
    @Composable
    private fun TopMenu(labels: List<String>, keys: List<String>, selected: Int, onSelect: (Int) -> Unit) {
        val state = rememberLazyListState()
        val sel = selected.coerceIn(0, labels.lastIndex)
        LaunchedEffect(sel) { state.animateScrollToItem((sel - 1).coerceAtLeast(0)) }
        LazyRow(
            state = state, modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 10.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            items(labels.size) { i ->
                val on = i == sel
                val shape = RoundedCornerShape(50)
                val textColor by animateColorAsState(if (on) Color.White else MaterialTheme.colorScheme.onSurface, label = "pillText")
                val fill = if (on) Brush.linearGradient(listOf(Pal.teal, Pal.blue)) else Brush.linearGradient(listOf(Color.Transparent, Color.Transparent))
                Row(
                    Modifier.height(40.dp).clip(shape).background(fill)
                        .border(1.dp, if (on) Color.Transparent else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f), shape)
                        .clickable { onSelect(i) }.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(tabEmoji(keys[i]), fontSize = 15.sp)
                    Spacer(Modifier.width(7.dp))
                    Text(labels[i], color = textColor, fontSize = 14.sp, fontWeight = if (on) FontWeight.Bold else FontWeight.Medium, maxLines = 1)
                }
            }
        }
    }

    @Composable
    private fun WinTile(emoji: String, label: String, bytes: Long, color: Color, modifier: Modifier, onClick: () -> Unit) {
        Column(
            modifier.clip(RoundedCornerShape(20.dp)).background(color.copy(alpha = 0.15f)).clickable { onClick() }.padding(14.dp),
        ) {
            Text(emoji, fontSize = 26.sp)
            Spacer(Modifier.height(6.dp))
            Text(label, style = MaterialTheme.typography.bodyMedium)
            Text(if (bytes < 0) "Checking…" else fmt(bytes), color = color, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
        }
    }

    @Composable
    private fun LargeTab(r: ScanResult) {
        if (r.large.isEmpty()) return Empty("No files over 50 MB. Nice.")
        FileList(r.large)
    }

    @Composable
    private fun JunkTab(r: ScanResult) {
        if (r.junk.isEmpty()) return Empty("No junk found.")
        Column {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Temp files, logs, old installers, empty files", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { vm.selectAll(r.junk.map { it.path }) }) { Text("Select all") }
            }
            FileList(r.junk)
        }
    }

    @Composable
    private fun SafetyTab(r: ScanResult) {
        val ctx = LocalContext.current
        val apkCount = r.junk.count { it.name.endsWith(".apk", ignoreCase = true) }
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        "This is a simple check, not an antivirus. It cannot find viruses, but it points out " +
                            "apps worth a second look. It works offline. A flagged app is not necessarily harmful.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    if (apkCount > 0) {
                        Spacer(Modifier.height(8.dp))
                        Text("$apkCount installer (.apk) files in storage. Only install files from sources you trust.")
                    }
                }
            }
            if (vm.safety.isEmpty()) item { Text("No apps need a second look.", Modifier.padding(16.dp)) }
            items(vm.safety, key = { it.pkg }) { a ->
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Text(a.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            when (a.level) { 2 -> "High"; 1 -> "Medium"; else -> "Low" },
                            color = if (a.level == 2) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                        )
                    }
                    a.reasons.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                    Row {
                        TextButton(onClick = {
                            safeStart(ctx,
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))
                            )
                        }) { Text("App info") }
                        TextButton(onClick = {
                            safeStart(ctx, Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
                        }) { Text("Uninstall") }
                    }
                    HorizontalDivider()
                }
            }
        }
    }

    /** Starts a screen; shows a message instead of crashing when the phone has nothing to handle it. */
    private fun safeStart(ctx: android.content.Context, i: Intent) {
        try { ctx.startActivity(i) } catch (e: Exception) {
            android.widget.Toast.makeText(ctx, "This phone cannot open that screen.", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    /** Opens the Gmail app with the search. Falls back to the Gmail app's home screen, then to a browser. Never crashes. */
    private fun openGmailSearch(ctx: android.content.Context, query: String) {
        val gmail = "com.google.android.gm"
        // 1. Gmail app, straight into the search
        try {
            val i = Intent(Intent.ACTION_SEARCH).setPackage(gmail)
                .putExtra(android.app.SearchManager.QUERY, query)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            return
        } catch (e: Exception) {
            // not supported by this Gmail version
        }
        // 2. Gmail app home, with the search words copied so they can be pasted into the search box
        try {
            val gm = ctx.packageManager.getLaunchIntentForPackage(gmail)
            if (gm != null) {
                val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("Gmail search", query))
                ctx.startActivity(gm)
                android.widget.Toast.makeText(ctx, "Paste this in Gmail search: $query", android.widget.Toast.LENGTH_LONG).show()
                return
            }
        } catch (e: Exception) {
            // fall through
        }
        // 3. No Gmail app: use a browser
        try {
            val url = "https://mail.google.com/mail/u/0/#search/" + Uri.encode(query)
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE))
            return
        } catch (e: Exception) {
            // fall through
        }
        android.widget.Toast.makeText(ctx, "Could not open Gmail. Install the Gmail app.", android.widget.Toast.LENGTH_LONG).show()
    }

    @Composable
    private fun EmailTab() {
        val ctx = LocalContext.current
        val searches = listOf(
            "Emails over 10 MB" to "larger:10M",
            "Attachments older than 1 year" to "has:attachment older_than:1y",
            "Promotions" to "category:promotions",
            "Social" to "category:social",
            "Spam" to "in:spam",
            "Trash" to "in:trash",
        )
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Column(Modifier.padding(16.dp)) {
                    Text("Gmail cleaner", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Opens the Gmail app with a ready-made search. Tick the select-all box, then tap Delete. " +
                            "Empty Spam and Trash afterwards to really free space.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "This frees space in your Google account (the 15 GB shared by Gmail, Drive and Photos), " +
                            "not on the phone itself. It needs internet and the Gmail app. The rest of this app stays offline.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
            items(searches) { (label, query) ->
                OutlinedButton(
                    onClick = {
                        openGmailSearch(ctx, query)
                    },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                ) { Text(label) }
            }
        }
    }

    @Composable
    private fun SimpleTab(files: List<FileItem>, hint: String, empty: String) {
        if (files.isEmpty()) return Empty(empty)
        Column {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text(hint, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { vm.selectAll(files.map { it.path }) }) { Text("Select all") }
            }
            FileList(files)
        }
    }

    @Composable
    private fun WhatsAppTab(r: ScanResult) {
        if (r.whatsapp.isEmpty()) return Empty("No WhatsApp media found.")
        val groups = r.whatsapp.groupBy { it.waGroup }.entries.sortedByDescending { e -> e.value.sumOf { it.size } }
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Text(
                    "Deleting here removes media from this phone only. Files you sent are not selected automatically.",
                    Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            groups.forEach { (name, files) ->
                item(key = "h-$name") {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp),
                        Arrangement.SpaceBetween, Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(name, style = MaterialTheme.typography.titleSmall)
                            Text("${files.size} files · ${fmt(files.sumOf { it.size })}", style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { vm.selectAll(files.filter { !it.isSent }.map { it.path }) }) {
                            Text("Select received")
                        }
                    }
                }
                items(files, key = { it.path }) { FileRow(it) }
                item(key = "d-$name") { HorizontalDivider() }
            }
        }
    }

    @Composable
    private fun DuplicatesTab(r: ScanResult) {
        if (vm.dupBusy) {
            FancyLoader(
                emoji = "👯", title = "Finding duplicates",
                subtitle = "This runs in the background. You can use the other tabs meanwhile.",
                detail = vm.dupProgress.ifEmpty { "Starting…" },
                colors = listOf(Pal.purple, Pal.pink, Pal.orange),
            )
            return
        }
        if (r.duplicates.isEmpty()) return Empty("No duplicates found.")
        Column {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("The oldest copy in each group is kept", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { vm.selectAll(r.duplicates.flatMap { it.drop(1) }.map { it.path }) }) {
                    Text("Select extras")
                }
            }
            LazyColumn(Modifier.fillMaxSize()) {
                r.duplicates.forEach { group ->
                    item {
                        Text(
                            "${group.size} copies · ${fmt(group[0].size * (group.size - 1))} wasted",
                            Modifier.padding(16.dp, 12.dp, 16.dp, 0.dp),
                            style = MaterialTheme.typography.titleSmall,
                        )
                    }
                    items(group, key = { it.path }) { FileRow(it) }
                    item { HorizontalDivider() }
                }
            }
        }
    }

    @Composable
    private fun SimilarTab() {
        LaunchedEffect(Unit) { vm.loadSimilar() }
        val groups = vm.similar
        if (groups == null || vm.similarBusy) {
            FancyLoader(
                emoji = "🖼️", title = "Finding similar photos",
                subtitle = "This can take a minute. It all happens on your phone.",
                detail = vm.similarProgress.ifEmpty { "Starting…" },
                colors = listOf(Pal.pink, Pal.purple, Pal.blue),
            )
            return
        }
        if (groups.isEmpty()) return Empty("No similar photos found.")
        Column {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("The biggest (best quality) photo in each group is kept. Tap a photo to compare.", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { vm.selectAll(groups.flatMap { it.drop(1) }.map { it.path }) }) { Text("Select extras") }
            }
            LazyColumn(Modifier.fillMaxSize()) {
                groups.forEach { group ->
                    item(key = "sg-" + group[0].path) {
                        Text(
                            "${group.size} similar photos · ${fmt(group.drop(1).sumOf { it.size })} could be freed",
                            Modifier.padding(16.dp, 12.dp, 16.dp, 0.dp), style = MaterialTheme.typography.titleSmall,
                        )
                    }
                    items(group, key = { "s-" + it.path }) { FileRow(it) }
                    item(key = "sd-" + group[0].path) { HorizontalDivider() }
                }
            }
        }
    }

    @Composable
    private fun FileList(files: List<FileItem>) {
        LazyColumn(Modifier.fillMaxSize()) {
            item(key = "hint") { Text("Tap a file to look at it before you delete.", Modifier.padding(16.dp, 8.dp), style = MaterialTheme.typography.bodySmall) }
            items(files, key = { it.path }) { FileRow(it) }
        }
    }

    @Composable
    private fun FileRow(f: FileItem) {
        val checked = f.path in vm.selected
        val (emoji, tint) = fileLook(f.name)
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 3.dp).clip(RoundedCornerShape(16.dp))
                .background(if (checked) MaterialTheme.colorScheme.primary.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                .padding(end = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Checkbox(checked = checked, onCheckedChange = { vm.toggle(f.path) })
            Box(Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(tint.copy(alpha = 0.2f)), Alignment.Center) {
                Text(emoji, fontSize = 20.sp)
            }
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f).clickable { vm.preview = f }.padding(vertical = 8.dp)) {
                Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.Medium)
                Text(
                    "${f.folder} · ${DateFormat.getDateInstance().format(Date(f.modified))}",
                    style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Text(fmt(f.size), Modifier.padding(start = 8.dp), color = tint, fontWeight = FontWeight.Bold)
        }
    }

    @Composable
    private fun AppsTab() {
        if (!usageOk) {
            Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                Text("To see how much space each app uses, allow Usage access for this app.")
                Spacer(Modifier.height(16.dp))
                Button(onClick = { requestUsage() }) { Text("Open settings") }
            }
            return
        }
        if (vm.apps.isEmpty()) return Empty("No app data yet.")
        val ctx = LocalContext.current
        LazyColumn(Modifier.fillMaxSize()) {
            items(vm.apps, key = { it.pkg }) { a ->
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Text(a.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(fmt(a.bytes))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Cache ${fmt(a.cache)}", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = {
                            safeStart(ctx,
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))
                            )
                        }) { Text("Clear cache") }
                        TextButton(onClick = {
                            safeStart(ctx, Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
                        }) { Text("Uninstall") }
                    }
                    HorizontalDivider()
                }
            }
        }
    }

    @Composable
    private fun BinTab() {
        var look by remember { mutableStateOf<TrashItem?>(null) }
        var emptyAsk by remember { mutableStateOf(false) }
        val items = vm.bin
        if (items.isEmpty()) return Empty("The Bin is empty. Deleted files wait here for ${AppConfig.binDays} days.")
        Column {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text(
                    "${items.size} files · ${fmt(items.sumOf { it.size })}. Removed for good after ${AppConfig.binDays} days.",
                    Modifier.weight(1f), style = MaterialTheme.typography.bodySmall,
                )
                TextButton(onClick = { emptyAsk = true }) { Text("Empty Bin") }
            }
            LazyColumn(Modifier.fillMaxSize()) {
                items(items, key = { it.id }) { t ->
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                        Row(Modifier.fillMaxWidth().clickable { look = t }, Arrangement.SpaceBetween) {
                            Text(t.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(fmt(t.size), Modifier.padding(start = 8.dp))
                        }
                        val daysLeft = (AppConfig.binDays - (System.currentTimeMillis() - t.deleted) / 86_400_000L).coerceAtLeast(0)
                        Text(
                            "${t.original.substringBeforeLast('/').substringAfter("/storage/emulated/0")} · $daysLeft days left",
                            style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        Row {
                            TextButton(onClick = { vm.restore(t.id) }) { Text("Restore") }
                            TextButton(onClick = { vm.deleteForever(setOf(t.id)) }) { Text("Delete for good") }
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
        look?.let { t ->
            FilePreview(FileItem(t.stored, t.size, t.deleted), marked = false, onToggleMark = null, onClose = { look = null }, title = t.name)
        }
        if (emptyAsk) {
            AlertDialog(
                onDismissRequest = { emptyAsk = false },
                title = { Text("Empty the Bin?") },
                text = { Text("${items.size} files (${fmt(items.sumOf { it.size })}) will be removed for good.") },
                confirmButton = { TextButton(onClick = { emptyAsk = false; vm.deleteForever(items.map { it.id }.toSet()) }) { Text("Empty Bin") } },
                dismissButton = { TextButton(onClick = { emptyAsk = false }) { Text("Cancel") } },
            )
        }
    }

    @Composable
    private fun DeleteBar(onDelete: () -> Unit) {
        Surface(tonalElevation = 8.dp, shadowElevation = 8.dp, shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)) {
            Row(Modifier.fillMaxWidth().padding(14.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                TextButton(onClick = { vm.clearSelection() }) { Text("Clear") }
                Box(Modifier.weight(1f))
                Button(
                    onClick = onDelete, shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Pal.orange, contentColor = Color.White),
                ) { Text((if (vm.binOn) "🗑️ Move to Bin " else "🗑️ Delete ") + "${vm.selected.size} · ${fmt(vm.selectedBytes)}", fontWeight = FontWeight.Bold) }
            }
        }
    }

    @Composable
    private fun Empty(text: String) {
        Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("✨", fontSize = 56.sp)
            Spacer(Modifier.height(10.dp))
            Text(text, style = MaterialTheme.typography.bodyLarge)
        }
    }

    private fun fmt(b: Long): String = Formatter.formatShortFileSize(this, b)
}

package com.storagemanager

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaScannerConnection
import android.os.Environment
import android.os.StatFs
import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

data class FileItem(val path: String, val size: Long, val modified: Long) {
    val name: String get() = path.substringAfterLast('/')
    val folder: String get() = path.substringBeforeLast('/').substringAfter("/storage/emulated/0")

    /** For WhatsApp files: "WhatsApp Images", "WhatsApp Video", "Statuses"… */
    val waGroup: String get() = path.substringAfter("/Media/", "").substringBefore('/').trimStart('.').ifEmpty { "Other" }
    val isSent: Boolean get() = path.contains("/Sent/")
}

enum class Category(val label: String) {
    IMAGES("Photos"), VIDEO("Videos"), AUDIO("Audio"), DOCS("Documents"), APK("App installers"), OTHER("Other")
}

data class ScanResult(
    val total: Long,
    val free: Long,
    val byCategory: Map<Category, Long>,
    val large: List<FileItem>,
    val junk: List<FileItem>,
    val duplicates: List<List<FileItem>>,
    val whatsapp: List<FileItem> = emptyList(),
    val downloads: List<FileItem> = emptyList(),
    val screenshots: List<FileItem> = emptyList(),
    /** Files that share a size with another file. Checked in the background to find real duplicates. */
    val dupCandidates: List<List<FileItem>> = emptyList(),
) {
    val used: Long get() = total - free

    fun without(paths: Set<String>) = copy(
        large = large.filterNot { it.path in paths },
        junk = junk.filterNot { it.path in paths },
        whatsapp = whatsapp.filterNot { it.path in paths },
        downloads = downloads.filterNot { it.path in paths },
        screenshots = screenshots.filterNot { it.path in paths },
        duplicates = duplicates
            .map { g -> g.filterNot { it.path in paths } }
            .filter { it.size > 1 },
    )
}

/** Everything here works fully offline: it only reads the phone's own storage. */
object StorageScanner {
    const val LARGE_MIN = 50L * 1024 * 1024       // files >= 50 MB count as "large"
    const val DUP_MIN = 100L * 1024               // ignore tiny files when looking for duplicates
    private const val SAMPLE = 16 * 1024

    private val images = setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "bmp")
    private val videos = setOf("mp4", "mkv", "3gp", "avi", "mov", "webm")
    private val audio = setOf("mp3", "m4a", "aac", "wav", "ogg", "opus", "amr", "flac")
    private val docs = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "epub")
    private val junkExt = setOf("tmp", "temp", "log", "bak", "chk", "old", "thumb", "thumbdata")

    fun root(): File = Environment.getExternalStorageDirectory()

    fun space(): Pair<Long, Long> {
        val s = StatFs(root().path)
        return s.totalBytes to s.availableBytes
    }

    private fun categoryOf(ext: String) = when (ext) {
        in images -> Category.IMAGES
        in videos -> Category.VIDEO
        in audio -> Category.AUDIO
        in docs -> Category.DOCS
        "apk" -> Category.APK
        else -> Category.OTHER
    }

    private fun isJunk(f: File, ext: String): Boolean {
        val p = f.path
        return ext in junkExt || ext == "apk" || f.length() == 0L ||
            p.contains("/.thumbnails/") || p.contains("/.Trash") || p.contains("/.trash")
    }

    fun scan(onProgress: (String) -> Unit): ScanResult {
        val cats = Category.values().associateWith { 0L }.toMutableMap()
        val large = ArrayList<FileItem>()
        val junk = ArrayList<FileItem>()
        val whatsapp = ArrayList<FileItem>()
        val downloads = ArrayList<FileItem>()
        val screenshots = ArrayList<FileItem>()
        val rootPath = root().path
        val startTime = System.currentTimeMillis()
        val oldMs = 60L * 24 * 3600 * 1000 // "old" = older than 60 days
        val bySize = HashMap<Long, MutableList<FileItem>>()
        var count = 0
        var lastReport = 0L

        root().walkTopDown()
            .onEnter { it.path != "${root().path}/Android/data" && it.path != "${root().path}/Android/obb" && it.path != Trash.dir().path }
            .onFail { _, _ -> }
            .filter { it.isFile }
            .forEach { f ->
                val size = f.length()
                val ext = f.extension.lowercase()
                val item = FileItem(f.path, size, f.lastModified())
                cats[categoryOf(ext)] = cats.getValue(categoryOf(ext)) + size
                if (size >= LARGE_MIN) large += item
                if (isJunk(f, ext)) junk += item
                val p = f.path
                if (ext != "nomedia" && (p.contains("/WhatsApp/Media/") || p.contains("/WhatsApp Business/Media/"))) whatsapp += item
                if (p.startsWith("$rootPath/Download/") && startTime - item.modified > oldMs) downloads += item
                if (p.contains("/Screenshots/", ignoreCase = true)) screenshots += item
                if (size >= DUP_MIN && ext !in junkExt) bySize.getOrPut(size) { ArrayList() } += item
                // Update the screen at most ~3 times a second so the spinner stays smooth
                if (++count % 200 == 0) {
                    val now = System.currentTimeMillis()
                    if (now - lastReport > 350) { lastReport = now; onProgress("Scanned $count files…") }
                }
            }

        val (total, free) = space()
        return ScanResult(
            total = total,
            free = free,
            byCategory = cats,
            large = large.sortedByDescending { it.size }.take(200),
            junk = junk.sortedByDescending { it.size },
            dupCandidates = bySize.values.filter { it.size > 1 },
            whatsapp = whatsapp.sortedByDescending { it.size },
            downloads = downloads.sortedByDescending { it.size },
            screenshots = screenshots.sortedByDescending { it.size },
        )
    }

    /**
     * Same size -> same 3 small samples -> same full SHA-256. Fast, and no false positives.
     * Runs on 3 low-priority threads so the phone stays smooth and the work finishes sooner.
     */
    fun findDuplicates(candidates: List<List<FileItem>>, onProgress: (String) -> Unit): List<List<FileItem>> {
        if (candidates.isEmpty()) return emptyList()
        val pool = Executors.newFixedThreadPool(3) { r -> Thread(r).apply { priority = Thread.MIN_PRIORITY; isDaemon = true } }
        val done = AtomicInteger(0)
        val lastReport = AtomicLong(0)
        val total = candidates.size
        try {
            // Biggest groups first so the slow ones start early
            val futures = candidates.sortedByDescending { it[0].size }.map { group ->
                pool.submit<List<List<FileItem>>> {
                    try { dupGroup(group) } catch (e: Exception) { emptyList() } finally {
                        val d = done.incrementAndGet()
                        val now = System.currentTimeMillis()
                        val last = lastReport.get()
                        if (d == total || (now - last > 350 && lastReport.compareAndSet(last, now))) onProgress("Comparing files… $d of $total")
                    }
                }
            }
            val result = futures.flatMap { f -> try { f.get() } catch (e: Exception) { emptyList() } }
            return result.sortedByDescending { it[0].size * (it.size - 1) }
        } finally {
            pool.shutdown()
        }
    }

    private fun dupGroup(group: List<FileItem>): List<List<FileItem>> {
        val out = ArrayList<List<FileItem>>()
        for (q in group.groupBy { quickKey(it) }.values.filter { it.size > 1 }) {
            for (g in q.groupBy { fullHash(it) }.filterKeys { it != null }.values.filter { it.size > 1 }) {
                out += g.sortedBy { it.modified } // oldest first = the one we keep
            }
        }
        return out
    }

    /** Fingerprint of the start, middle and end of a file. Rules out most look-alikes after reading only 48 KB. */
    private fun quickKey(i: FileItem): String = try {
        RandomAccessFile(i.path, "r").use { r ->
            val md = MessageDigest.getInstance("SHA-256")
            val buf = ByteArray(SAMPLE)
            for (pos in longArrayOf(0L, (i.size / 2 - SAMPLE / 2).coerceAtLeast(0L), (i.size - SAMPLE).coerceAtLeast(0L))) {
                r.seek(pos)
                val n = r.read(buf); if (n > 0) md.update(buf, 0, n)
            }
            md.digest().joinToString("") { "%02x".format(it) }
        }
    } catch (e: Exception) { "err-${i.path}" }

    private fun fullHash(i: FileItem): String? = try {
        val md = MessageDigest.getInstance("SHA-256")
        File(i.path).inputStream().use { s ->
            val buf = ByteArray(1 shl 20)
            while (true) { val n = s.read(buf); if (n < 0) break; md.update(buf, 0, n) }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    } catch (e: Exception) { null }

    /**
     * Finds photos that LOOK alike (burst shots, edited copies, resaved versions) even when the files differ.
     * Each photo gets a tiny 64-bit fingerprint of its brightness pattern; fingerprints that differ in only a few bits are grouped.
     * In every group the biggest file (best quality) comes first and is the one to keep.
     */
    fun findSimilarPhotos(onProgress: (String) -> Unit): List<List<FileItem>> {
        val root = root()
        val list = ArrayList<FileItem>()
        root.walkTopDown()
            .onEnter {
                it.path != "${root.path}/Android/data" && it.path != "${root.path}/Android/obb" &&
                    it.path != Trash.dir().path && !it.name.startsWith(".")
            }
            .onFail { _, _ -> }
            .filter { it.isFile && it.extension.lowercase() in setOf("jpg", "jpeg", "png", "webp") && it.length() >= 30 * 1024 }
            .forEach { list += FileItem(it.path, it.length(), it.lastModified()) }
        // newest 4000 photos keeps the time reasonable on big galleries
        val photos = list.sortedByDescending { it.modified }.take(4000)
        val hashes = LongArray(photos.size)
        val ratio = FloatArray(photos.size)
        val ok = BooleanArray(photos.size)
        var lastReport = 0L
        photos.forEachIndexed { i, f ->
            val now = System.currentTimeMillis()
            if (now - lastReport > 350) { lastReport = now; onProgress("Looking at photos… $i of ${photos.size}") }
            val h = fingerprint(f.path)
            if (h != null) { hashes[i] = h.first; ratio[i] = h.second; ok[i] = true }
        }
        onProgress("Comparing photos…")
        val used = BooleanArray(photos.size)
        val groups = ArrayList<List<FileItem>>()
        for (i in photos.indices) {
            if (!ok[i] || used[i]) continue
            val g = arrayListOf(photos[i])
            for (j in i + 1 until photos.size) {
                if (!ok[j] || used[j]) continue
                if (kotlin.math.abs(ratio[i] - ratio[j]) > 0.08f) continue
                if (java.lang.Long.bitCount(hashes[i] xor hashes[j]) <= 6) { g += photos[j]; used[j] = true }
            }
            if (g.size > 1) { used[i] = true; groups += g.sortedWith(compareByDescending<FileItem> { it.size }.thenBy { it.modified }) }
        }
        return groups.sortedByDescending { g -> g.drop(1).sumOf { it.size } }
    }

    /** Brightness fingerprint (difference hash) and width/height ratio of a photo, or null if it cannot be read. */
    private fun fingerprint(path: String): Pair<Long, Float>? {
        var small: Bitmap? = null
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, o)
            if (o.outWidth <= 0 || o.outHeight <= 0) return null
            var sample = 1
            while (o.outWidth / (sample * 2) >= 64 && o.outHeight / (sample * 2) >= 64) sample *= 2
            val bm = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return null
            small = Bitmap.createScaledBitmap(bm, 9, 8, true)
            if (bm !== small) bm.recycle()
            var h = 0L
            for (y in 0 until 8) {
                for (x in 0 until 8) {
                    h = h shl 1
                    if (luma(small.getPixel(x, y)) > luma(small.getPixel(x + 1, y))) h = h or 1L
                }
            }
            return h to (o.outWidth.toFloat() / o.outHeight)
        } catch (t: Throwable) {
            return null
        } finally {
            small?.recycle()
        }
    }

    private fun luma(c: Int): Int = ((c shr 16 and 255) * 3 + (c shr 8 and 255) * 6 + (c and 255)) / 10

    /** Deletes the files and tells the gallery/media store. Returns the paths actually removed. */
    fun delete(ctx: Context, paths: List<String>): Set<String> {
        val gone = HashSet<String>()
        for (p in paths) if (File(p).let { it.exists() && it.delete() }) gone += p
        if (gone.isNotEmpty()) MediaScannerConnection.scanFile(ctx, gone.toTypedArray(), null, null)
        return gone
    }
}

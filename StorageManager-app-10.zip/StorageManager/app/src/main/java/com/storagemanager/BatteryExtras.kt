package com.storagemanager

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** A small offline log of the battery level, kept for 2 days, used for the graph and time-to-full estimate. */
object BatteryHistory {
    data class Point(val t: Long, val pct: Int, val charging: Boolean, val tempC: Float)

    private fun p(c: Context) = c.applicationContext.getSharedPreferences("battery_history", 0)
    private const val KEEP_MS = 48L * 3600 * 1000
    private const val MAX = 600

    fun load(c: Context): List<Point> {
        val raw = p(c).getString("log", "") ?: ""
        if (raw.isBlank()) return emptyList()
        return raw.split(";").mapNotNull { s ->
            val a = s.split(",")
            if (a.size < 4) null else try { Point(a[0].toLong(), a[1].toInt(), a[2] == "1", a[3].toFloat()) } catch (e: Exception) { null }
        }
    }

    @Synchronized
    fun record(c: Context, pct: Int, charging: Boolean, tempC: Float) {
        val now = System.currentTimeMillis()
        val list = load(c).filter { now - it.t < KEEP_MS }.toMutableList()
        val last = list.lastOrNull()
        if (last != null && last.pct == pct && last.charging == charging && now - last.t < 10 * 60 * 1000) return
        list.add(Point(now, pct, charging, tempC))
        val kept = if (list.size > MAX) list.takeLast(MAX) else list
        p(c).edit().putString("log", kept.joinToString(";") { "${it.t},${it.pct},${if (it.charging) 1 else 0},${"%.1f".format(java.util.Locale.US, it.tempC)}" }).apply()
    }

    /** Times the phone was charged up to 100% in the saved period. */
    fun fullCharges(c: Context): Int {
        var n = 0
        var prev = 0
        for (pt in load(c)) { if (pt.pct >= 100 && prev < 100) n++; prev = pt.pct }
        return n
    }
}

object ChargeInfo {
    /** Charging current in mA (sign ignored). Null when the phone does not report it. */
    fun currentMa(c: Context): Int? {
        val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        val raw = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW)
        if (raw == Int.MIN_VALUE || raw == 0) return null
        val a = Math.abs(raw)
        // Most phones give microamps, a few give milliamps
        return if (a > 20000) a / 1000 else a
    }

    /** Minutes until full while charging, or null when unknown. */
    fun minutesToFull(c: Context, b: BatteryInfo): Int? {
        if (!b.charging || b.percent >= 100) return null
        if (Build.VERSION.SDK_INT >= 28) {
            val bm = c.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val ms = bm.computeChargeTimeRemaining()
            if (ms > 0) return (ms / 60000).toInt().coerceAtLeast(1)
        }
        // Fallback: how fast the level rose in the saved history
        val h = BatteryHistory.load(c).filter { it.charging }.takeLast(8)
        if (h.size >= 2) {
            val dp = h.last().pct - h.first().pct
            val dt = h.last().t - h.first().t
            if (dp > 0 && dt > 0) {
                val minPerPct = dt / 60000.0 / dp
                return (minPerPct * (100 - b.percent)).toInt().coerceAtLeast(1)
            }
        }
        return null
    }

    fun format(min: Int): String = if (min >= 60) "${min / 60} h ${min % 60} min" else "$min min"

    fun tips(c: Context, b: BatteryInfo): List<String> = buildList {
        val full = BatteryHistory.fullCharges(c)
        if (full >= 3) add("🔌 Charged to 100% $full times in the last 2 days. Topping up between 20% and 80% wears the battery more slowly.")
        val hot = BatteryHistory.load(c).count { it.tempC >= 40f && it.charging }
        if (hot >= 2) add("🌡️ The battery got hot while charging more than once recently. Charge in a cool place and use the phone's own charger.")
        if (b.healthPercent != null && b.healthPercent < 85) add("⚠️ Your battery is wearing out (${b.healthPercent}% of new). Plan for a replacement when it no longer lasts the day.")
        val ma = if (b.charging) currentMa(c) else null
        if (ma != null && ma < 400 && b.plugged != "USB") add("🐢 Charging is slow (${ma} mA). Try the original charger and cable, and close heavy apps while charging.")
    }
}

@Composable
fun ChargeCard(b: BatteryInfo) {
    val ctx = LocalContext.current
    val ma = if (b.charging) ChargeInfo.currentMa(ctx) else null
    val mins = ChargeInfo.minutesToFull(ctx, b)
    Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(Lang.tr("Charging"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(8.dp))
            if (!b.charging) {
                Text("Plug in your charger to see the speed and the time left to full.", style = MaterialTheme.typography.bodyMedium)
            } else {
                if (ma != null) {
                    val watts = ma / 1000f * b.voltageV
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Text(Lang.tr("Speed"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("$ma mA  (about ${"%.1f".format(watts)} W)", fontWeight = FontWeight.SemiBold)
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), Arrangement.SpaceBetween) {
                    Text(Lang.tr("Time to full"), color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(if (b.percent >= 100) "Full" else mins?.let { ChargeInfo.format(it) } ?: "Working it out...", fontWeight = FontWeight.SemiBold)
                }
                if (ma == null) Text("This phone does not report charging speed.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
            }
        }
    }
}

@Composable
fun HistoryCard() {
    val ctx = LocalContext.current
    val pts = remember { BatteryHistory.load(ctx) }
    val line = MaterialTheme.colorScheme.primary
    val grid = MaterialTheme.colorScheme.outline
    Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(Lang.tr("Battery history"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("Last 2 days, saved on this phone only", style = MaterialTheme.typography.bodySmall)
            Spacer(Modifier.height(10.dp))
            if (pts.size < 2) {
                Text("Not enough readings yet. Use the phone for a while and check again.", style = MaterialTheme.typography.bodyMedium)
            } else {
                Canvas(Modifier.fillMaxWidth().height(120.dp)) {
                    val w = size.width; val h = size.height
                    for (g in listOf(0, 50, 100)) {
                        val y = h - h * g / 100f
                        drawLine(grid.copy(alpha = 0.35f), Offset(0f, y), Offset(w, y), 1f)
                    }
                    val t0 = pts.first().t; val span = (pts.last().t - t0).coerceAtLeast(1L)
                    val path = Path()
                    pts.forEachIndexed { i, p ->
                        val x = w * (p.t - t0) / span
                        val y = h - h * p.pct / 100f
                        if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(path, line, style = Stroke(width = 5f))
                }
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                    Text("2 days ago", style = MaterialTheme.typography.bodySmall)
                    Text("Now", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

/** Helps alarms survive on phones that close background apps (Tecno, Infinix, itel, Xiaomi, Oppo, Vivo, Huawei, Samsung). */
@Composable
fun KeepAliveCard() {
    val ctx = LocalContext.current
    val pm = ctx.getSystemService(Context.POWER_SERVICE) as PowerManager
    var unrestricted by remember { mutableStateOf(pm.isIgnoringBatteryOptimizations(ctx.packageName)) }
    Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("🛡️ " + Lang.tr("Keep alarms working"), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "Many phones close apps in the background to save power, and then alarms stop. Do these 3 things once:",
                style = MaterialTheme.typography.bodyMedium,
            )
            Text("1. Allow background use", fontWeight = FontWeight.SemiBold)
            Text(
                (if (unrestricted) "✅ Done. " else "") + "Find this app and choose Unrestricted or Don't optimise.",
                style = MaterialTheme.typography.bodySmall,
            )
            OutlinedButton(onClick = {
                KeepAlive.go(ctx, Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
                unrestricted = pm.isIgnoringBatteryOptimizations(ctx.packageName)
            }, Modifier.fillMaxWidth()) { Text(Lang.tr("Open battery settings")) }
            Text("2. Allow auto-start", fontWeight = FontWeight.SemiBold)
            Text("Switch this app on in your phone's auto-start or app launch list.", style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = { KeepAlive.openAutoStart(ctx) }, Modifier.fillMaxWidth()) { Text(Lang.tr("Open auto-start settings")) }
            Text("3. Lock the app in recent apps", fontWeight = FontWeight.SemiBold)
            Text(
                "Open the recent apps screen, then pull this app's card down or tap its menu and choose Lock. Do not swipe it away afterwards.",
                style = MaterialTheme.typography.bodySmall,
            )
            OutlinedButton(onClick = { KeepAlive.openAppInfo(ctx) }, Modifier.fillMaxWidth()) { Text(Lang.tr("Open this app's settings")) }
        }
    }
}

object KeepAlive {
    private val oem = listOf(
        "xiaomi" to ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
        "redmi" to ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
        "poco" to ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity"),
        "oppo" to ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
        "realme" to ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity"),
        "vivo" to ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity"),
        "huawei" to ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
        "honor" to ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity"),
        "samsung" to ComponentName("com.samsung.android.lool", "com.samsung.android.sm.battery.ui.BatteryActivity"),
    )

    fun go(ctx: Context, action: String) {
        try { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { openAppInfo(ctx) }
    }

    fun openAppInfo(ctx: Context) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {}
    }

    fun openAutoStart(ctx: Context) {
        val maker = (Build.MANUFACTURER + " " + Build.BRAND).lowercase()
        // Tecno, Infinix and itel use the Phone Master app
        if (maker.contains("tecno") || maker.contains("infinix") || maker.contains("itel") || maker.contains("transsion")) {
            for (pkg in listOf("com.transsion.phonemaster", "com.itel.autostart", "com.transsion.systemmanager")) {
                val i = ctx.packageManager.getLaunchIntentForPackage(pkg)
                if (i != null) { try { ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Exception) {} }
            }
        }
        for ((name, comp) in oem) {
            if (maker.contains(name)) {
                try { ctx.startActivity(Intent().setComponent(comp).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (_: Exception) {}
            }
        }
        openAppInfo(ctx)
    }
}

/** Three-screen first-run guide. Storage access is required; the other two can be skipped. */
@Composable
fun Walkthrough(
    storageOk: Boolean,
    usageOk: Boolean,
    notifOk: Boolean,
    onStorage: () -> Unit,
    onUsage: () -> Unit,
    onNotif: () -> Unit,
    onFinish: () -> Unit,
) {
    var step by remember { mutableIntStateOf(0) }
    val titles = listOf("All files access", "Usage access", "Notifications")
    val icons = listOf("📁", "📊", "🔔")
    val why = listOf(
        "So the app can find big files, duplicates and junk across your phone. Everything stays on your phone and nothing is uploaded.",
        "So the Apps tab can show how much space each app uses. You can skip this and the rest still works.",
        "So the phone can warn you when storage is almost full and ring your battery alarms. You can skip this too.",
    )
    val ok = listOf(storageOk, usageOk, notifOk)
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        LanguageChips()
        Spacer(Modifier.height(8.dp))
        Text(Lang.tr("Step {a} of 3", "${step + 1}"), style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(12.dp))
        Text(icons[step], fontSize = 72.sp)
        Spacer(Modifier.height(8.dp))
        Text(Lang.tr(titles[step]), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text(Lang.tr(why[step]))
        Spacer(Modifier.height(20.dp))
        if (ok[step]) {
            Text(Lang.tr("✅ Allowed"), fontWeight = FontWeight.Bold)
        } else {
            Button(onClick = { when (step) { 0 -> onStorage(); 1 -> onUsage(); else -> onNotif() } }) { Text(Lang.tr("Grant")) }
        }
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            if (step > 0) TextButton(onClick = { step-- }) { Text(Lang.tr("Back")) }
            if (step < 2) {
                Button(onClick = { step++ }, enabled = step != 0 || storageOk) { Text(Lang.tr(if (ok[step] || step == 0) "Next" else "Skip")) }
            } else {
                Button(onClick = onFinish, enabled = storageOk) { Text(Lang.tr("Finish")) }
            }
        }
        if (step == 0 && !storageOk) {
            Spacer(Modifier.height(8.dp))
            Text(Lang.tr("File access is needed to continue."), style = MaterialTheme.typography.bodySmall)
        }
    }
}

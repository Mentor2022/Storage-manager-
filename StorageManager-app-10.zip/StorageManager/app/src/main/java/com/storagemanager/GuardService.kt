package com.storagemanager

import android.accessibilityservice.AccessibilityService
import android.content.ComponentName
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Settings for the guard, shared by the app and the guard service. */
object Guard {
    private fun p(c: Context) = c.applicationContext.getSharedPreferences("guard", 0)

    /** The owner's switch. Only does anything once a PIN exists. */
    fun on(c: Context) = AntiTheft.hasPin(c) && p(c).getBoolean("on", true)
    fun setOn(c: Context, v: Boolean) { p(c).edit().putBoolean("on", v).apply() }

    /** After the right PIN, protected screens stay open for two minutes. */
    fun unlock(c: Context) { p(c).edit().putLong("until", System.currentTimeMillis() + 120_000L).apply() }
    fun isUnlocked(c: Context) = System.currentTimeMillis() < p(c).getLong("until", 0L)

    /** Is the accessibility service switched on in Android's settings? */
    fun enabled(c: Context): Boolean {
        val list = Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: return false
        val me = ComponentName(c, GuardService::class.java)
        return list.split(':').any { it.equals(me.flattenToString(), true) || it.equals(me.flattenToShortString(), true) }
    }

    /** Covers the whole screen with the PIN pad (the alarm went off). Does nothing if the service is not on. */
    fun showAlarm() { GuardService.instance?.let { s -> s.post { s.showLock(GuardService.MODE_ALARM) } } }
    fun hide() { GuardService.instance?.let { s -> s.post { s.hideLock() } } }
}

/**
 * Two jobs, both needing the owner's PIN:
 *  1. When the anti-theft alarm goes off, cover the whole screen with a PIN pad so nobody can use the phone.
 *  2. While the guard is on, cover this app's own uninstall, Force stop, Device admin and Accessibility screens.
 * It only reads Settings and installer screens, looks for this app's name, and keeps nothing.
 */
class GuardService : AccessibilityService() {
    companion object {
        @Volatile var instance: GuardService? = null
        const val MODE_ALARM = 0
        const val MODE_PROTECT = 1

        /** Screens that can remove or switch off the app. Other apps are never read. */
        private val SENSITIVE = listOf("settings", "packageinstaller", "securitycenter", "phonemaster", "systemmanager", "appmanager", "vending")
        private val DANGER = listOf("uninstall", "force stop", "deactivate", "clear data", "clear storage", "device admin", "accessibility")
    }

    private val handler = Handler(Looper.getMainLooper())
    private var overlay: View? = null
    private var overlayMode = -1
    private var lastScan = 0L
    private var label = ""

    fun post(r: () -> Unit) { handler.post { r() } }

    override fun onServiceConnected() {
        instance = this
        label = getString(R.string.app_name).lowercase()
        AntiTheft.refresh(this)
        // After a restart the alarm may still be on: the screen stays covered until the PIN is entered
        if (AntiTheft.ringing) handler.post { showLock(MODE_ALARM) }
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        hideLock()
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        hideLock()
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        e ?: return
        if (overlay != null) return
        if (!Guard.on(this) || Guard.isUnlocked(this)) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || SENSITIVE.none { pkg.contains(it) }) return
        val now = SystemClock.uptimeMillis()
        if (now - lastScan < 350) return
        lastScan = now
        val root = rootInActiveWindow ?: return
        val text = collect(root)
        if (text.contains(label) && DANGER.any { text.contains(it) }) showLock(MODE_PROTECT)
    }

    private fun collect(root: AccessibilityNodeInfo): String {
        val sb = StringBuilder()
        var n = 0
        fun walk(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || n > 500 || depth > 25) return
            n++
            node.text?.let { sb.append(it).append(' ') }
            node.contentDescription?.let { sb.append(it).append(' ') }
            for (i in 0 until node.childCount) walk(node.getChild(i), depth + 1)
        }
        walk(root, 0)
        return sb.toString().lowercase()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    fun hideLock() {
        overlay?.let { try { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {} }
        overlay = null
        overlayMode = -1
    }

    fun showLock(mode: Int) {
        if (overlay != null) {
            if (overlayMode == MODE_ALARM || mode != MODE_ALARM) return
            hideLock() // the alarm is more important than the settings screen
        }
        val view = build(mode)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_FULLSCREEN or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.OPAQUE,
        )
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(view, lp)
            overlay = view
            overlayMode = mode
        } catch (_: Exception) {}
    }

    /** A plain PIN pad (no keyboard needed), drawn with ordinary views. */
    private fun build(mode: Int): View {
        val pin = StringBuilder()
        var attempts = 0
        var lockedUntil = 0L
        val alarm = mode == MODE_ALARM
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFF0B1F1D.toInt())
            setPadding(dp(24), dp(56), dp(24), dp(24))
            isClickable = true
        }
        fun tv(text: String, size: Float, bold: Boolean = false, color: Int = Color.WHITE) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(4), 0, dp(4))
        }
        root.addView(tv(if (alarm) "🚨" else "🔐", 56f))
        root.addView(tv(if (alarm) "This phone is protected" else "Owner's PIN needed", 24f, true))
        root.addView(tv(if (alarm) "Enter the owner's PIN to use this phone." else "Enter your PIN to open this screen.", 15f, false, 0xFFB8CFCB.toInt()))
        val contact = AntiTheft.contact(this)
        if (alarm && contact.isNotBlank()) root.addView(tv("If you found this phone, please call: $contact", 16f, true, 0xFFFFD54F.toInt()))
        val dots = tv("", 30f)
        val msg = tv("", 14f, false, 0xFFFF8A80.toInt())
        root.addView(dots)
        root.addView(msg)
        fun refresh() { dots.text = (0 until 6).joinToString(" ") { if (it < pin.length) "●" else "○" } }
        refresh()

        fun submit() {
            if (System.currentTimeMillis() < lockedUntil) return
            if (AntiTheft.check(this, pin.toString())) {
                if (alarm) AntiTheft.disarm(this) else Guard.unlock(this)
                hideLock()
            } else {
                attempts++
                pin.setLength(0); refresh()
                msg.text = "Wrong PIN"
                if (attempts % 5 == 0) { lockedUntil = System.currentTimeMillis() + 30_000L; msg.text = "Too many tries. Wait 30 seconds." }
            }
        }

        fun key(label: String, action: () -> Unit) = android.widget.Button(this).apply {
            text = label; textSize = 22f; setAllCaps(false); setTextColor(Color.WHITE)
            background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0xFF1E3A36.toInt()) }
            setOnClickListener { action() }
            layoutParams = GridLayout.LayoutParams().apply { width = dp(86); height = dp(62); setMargins(dp(6), dp(6), dp(6), dp(6)) }
        }
        val grid = GridLayout(this).apply { columnCount = 3 }
        for (d in listOf("1", "2", "3", "4", "5", "6", "7", "8", "9")) {
            grid.addView(key(d) { if (pin.length < 6) { pin.append(d); msg.text = ""; refresh() } })
        }
        grid.addView(key("⌫") { if (pin.isNotEmpty()) { pin.setLength(pin.length - 1); refresh() } })
        grid.addView(key("0") { if (pin.length < 6) { pin.append("0"); msg.text = ""; refresh() } })
        grid.addView(key("OK") { submit() })
        val holder = LinearLayout(this).apply { gravity = Gravity.CENTER_HORIZONTAL; addView(grid) }
        root.addView(holder)
        if (!alarm) {
            val cancel = tv("Cancel", 16f, true, 0xFF80CBC4.toInt())
            cancel.setPadding(dp(24), dp(16), dp(24), dp(16))
            cancel.setOnClickListener { hideLock(); performGlobalAction(GLOBAL_ACTION_HOME) }
            root.addView(cancel)
        }
        return root
    }
}

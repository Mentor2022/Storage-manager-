package com.storagemanager

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.LifecycleResumeEffect

/** Turns on the guard: a PIN pad over the whole screen when the alarm goes off, and PIN-protected removal screens. */
@Composable
fun GuardCard() {
    val ctx = LocalContext.current
    var enabled by remember { mutableStateOf(Guard.enabled(ctx)) }
    var on by remember { mutableStateOf(Guard.on(ctx)) }
    var askOff by remember { mutableStateOf(false) }
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    LifecycleResumeEffect(Unit) {
        enabled = Guard.enabled(ctx)
        on = Guard.on(ctx)
        onPauseOrDispose { }
    }
    Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("🛡️ Lock the phone and protect the app", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "When the alarm goes off, the whole screen is covered with a PIN pad, so nobody can use the phone. " +
                    "It also asks for your PIN before anyone can open this app's Uninstall, Force stop, Device admin or Accessibility screens.",
                style = MaterialTheme.typography.bodyMedium,
            )
            if (!AntiTheft.hasPin(ctx)) {
                Text("Choose a PIN in the alarm card above first.", fontWeight = FontWeight.SemiBold)
            } else if (!enabled) {
                Text("Turn it on in 3 steps:", fontWeight = FontWeight.SemiBold)
                Text(
                    "1. Tap the first button. Find this app in the list (it may be under Installed apps or Downloaded apps).\n" +
                        "2. Switch it on and tap Allow.\n" +
                        "3. If the switch is grey (Android 13 and newer): tap the second button, then the three dots at the top right, choose Allow restricted settings, and try step 1 again.",
                    style = MaterialTheme.typography.bodySmall,
                )
                Button(onClick = { open(ctx, Settings.ACTION_ACCESSIBILITY_SETTINGS) }, Modifier.fillMaxWidth()) { Text("1. Open Accessibility settings") }
                OutlinedButton(onClick = { KeepAlive.openAppInfo(ctx) }, Modifier.fillMaxWidth()) { Text("2. Open this app's info (for Allow restricted settings)") }
                Text(
                    "This permission is used only to find this app's name on Settings and installer screens and to draw the PIN pad. Nothing is saved or sent.",
                    style = MaterialTheme.typography.bodySmall,
                )
            } else {
                Text("✅ Guard is switched on in Android", fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Ask for my PIN on removal screens", fontWeight = FontWeight.SemiBold)
                        Text("Needed to uninstall, force stop or switch off this app. Open for 2 minutes after the PIN.", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(checked = on, onCheckedChange = { v -> if (v) { Guard.setOn(ctx, true); on = true } else askOff = true })
                }
            }
            TextButton(onClick = { enabled = Guard.enabled(ctx); on = Guard.on(ctx) }) { Text("Check again") }
        }
    }
    if (askOff) {
        AlertDialog(
            onDismissRequest = { askOff = false; pin = ""; wrong = false },
            title = { Text("Enter your PIN") },
            text = {
                OutlinedTextField(
                    value = pin, onValueChange = { pin = it.filter { c -> c.isDigit() }.take(6); wrong = false }, singleLine = true, isError = wrong,
                    label = { Text(if (wrong) "Wrong PIN" else "PIN") },
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (AntiTheft.check(ctx, pin)) { Guard.setOn(ctx, false); on = false; askOff = false; pin = "" } else { wrong = true; pin = "" }
                }) { Text("Turn off") }
            },
            dismissButton = { TextButton(onClick = { askOff = false; pin = ""; wrong = false }) { Text("Cancel") } },
        )
    }
}

private fun open(ctx: Context, action: String) {
    try { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) { KeepAlive.openAppInfo(ctx) }
}

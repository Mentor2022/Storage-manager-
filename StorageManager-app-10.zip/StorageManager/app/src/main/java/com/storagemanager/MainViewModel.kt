package com.storagemanager

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("stats", 0)

    var scanning by mutableStateOf(false); private set
    var progress by mutableStateOf("")
    var result by mutableStateOf<ScanResult?>(null); private set
    var apps by mutableStateOf<List<AppItem>>(emptyList()); private set
    var message by mutableStateOf<String?>(null)
    var safety by mutableStateOf<List<AppRisk>>(emptyList()); private set
    /** Total space this app has freed over time (kept on the phone). */
    var freedTotal by mutableStateOf(prefs.getLong("freed", 0L)); private set
    val selected = mutableStateListOf<String>()
    /** The file the person tapped to look at before deciding. */
    var preview by mutableStateOf<FileItem?>(null)

    /** Photos that look alike. null = not looked at yet. */
    var similar by mutableStateOf<List<List<FileItem>>?>(null); private set
    var similarBusy by mutableStateOf(false); private set
    var similarProgress by mutableStateOf("")

    /** Duplicates are found in the background after the main scan, so the app opens sooner. */
    var dupBusy by mutableStateOf(false); private set
    var dupProgress by mutableStateOf("")
    private var scanId = 0

    // ───────── Gmail cleaner (Gmail over IMAP, with the person's own app password) ─────────
    data class MailFound(val uids: List<Long>, val box: String) {
        val size: Int get() = uids.size
        fun isEmpty() = uids.isEmpty()
        fun isNotEmpty() = uids.isNotEmpty()
    }

    /** The address is remembered; the app password is kept in memory only and is gone when the app closes. */
    var mailUser by mutableStateOf(prefs.getString("mail_user", "") ?: "")
    var mailConnected by mutableStateOf(false); private set
    var mailBusy by mutableStateOf(false); private set
    val mailFound = mutableStateMapOf<String, MailFound>()
    private var mailPass = ""
    private var mailFolders: GmailImap.Folders? = null

    private fun mailFail(e: Exception) {
        message = when (e) {
            is GmailImap.BadLogin -> {
                mailConnected = false; mailPass = ""
                "Gmail did not accept that address and code. Check both and try again."
            }
            is java.net.UnknownHostException, is java.net.SocketTimeoutException, is java.net.ConnectException ->
                "No internet connection. Please try again."
            else -> "Gmail problem: ${e.message ?: "unknown error"}"
        }
    }

    fun mailConnect(user: String, code: String) {
        val u = user.trim()
        val p = code.filter { !it.isWhitespace() }
        if (!u.contains("@") || p.length < 8) { message = "Type your Gmail address and the 16-letter app password."; return }
        if (mailBusy) return
        viewModelScope.launch {
            mailBusy = true
            try {
                mailFolders = withContext(Dispatchers.IO) { GmailImap.connect(u, p) }
                mailUser = u; mailPass = p; mailConnected = true
                prefs.edit().putString("mail_user", u).apply()
                message = "Connected to Gmail."
            } catch (e: Exception) { mailFail(e) }
            mailBusy = false
        }
    }

    fun mailDisconnect() { mailPass = ""; mailConnected = false; mailFound.clear() }

    fun mailCount(key: String, query: String, box: String) {
        val f = mailFolders ?: return
        if (!mailConnected || mailBusy) return
        viewModelScope.launch {
            mailBusy = true
            try { mailFound[key] = MailFound(withContext(Dispatchers.IO) { GmailImap.find(mailUser, mailPass, f, query, box) }, box) }
            catch (e: Exception) { mailFail(e) }
            mailBusy = false
        }
    }

    fun mailRemove(key: String, forever: Boolean) {
        val f = mailFolders ?: return
        val found = mailFound[key] ?: return
        if (!mailConnected || mailBusy || found.isEmpty()) return
        viewModelScope.launch {
            mailBusy = true
            try {
                withContext(Dispatchers.IO) {
                    if (forever) GmailImap.deleteForever(mailUser, mailPass, f, found.uids, found.box)
                    else GmailImap.trash(mailUser, mailPass, f, found.uids)
                }
                mailFound.remove(key)
                message = if (forever) "Deleted ${found.size} emails for good." else "Moved ${found.size} emails to Trash."
            } catch (e: Exception) { mailFail(e) }
            mailBusy = false
        }
    }

    /** A newer version of this app is ready to download. null = none (or the admin turned the check off). */
    var update by mutableStateOf<UpdateInfo?>(null); private set

    /** A message from the admin (scam warning, news). null = none or already closed. */
    var announce by mutableStateOf<Announcement?>(null); private set

    fun dismissAnnounce() {
        announce?.let { UpdateCheck.dismissAnnouncement(app, it.id) }
        announce = null
    }

    fun checkUpdate() {
        if (!AppConfig.updateOn) return
        if (announce == null) announce = UpdateCheck.announcement(app)
        if (update == null && System.currentTimeMillis() - UpdateCheck.lastCheck(app) < 6 * 3600_000L) return
        viewModelScope.launch {
            val info = withContext(Dispatchers.IO) { UpdateCheck.fetch(app) }
            UpdateCheck.markChecked(app)
            update = info?.takeIf { it.code > UpdateCheck.dismissed(app) }
            announce = UpdateCheck.announcement(app)
        }
    }

    fun dismissUpdate() {
        update?.let { UpdateCheck.dismiss(app, it.code) }
        update = null
    }

    fun loadSimilar(force: Boolean = false) {
        if (similarBusy || (similar != null && !force)) return
        viewModelScope.launch {
            similarBusy = true
            similar = withContext(Dispatchers.IO) {
                val t = Thread.currentThread()
                val old = t.priority
                t.priority = Thread.MIN_PRIORITY
                try { StorageScanner.findSimilarPhotos { similarProgress = it } } finally { t.priority = old }
            }
            similarBusy = false
        }
    }

    /** Files that are safe to clear in one go: junk and extra copies of exact duplicates. One copy of every file always stays. */
    fun smartPaths(): List<String> {
        val r = result ?: return emptyList()
        val set = LinkedHashSet<String>()
        r.junk.forEach { set += it.path }
        r.duplicates.forEach { g -> g.drop(1).forEach { set += it.path } }
        r.duplicates.forEach { g -> if (g.all { it.path in set }) set -= g[0].path }
        return set.toList()
    }

    var bin by mutableStateOf<List<TrashItem>>(emptyList()); private set
    val binOn: Boolean get() = "bin" in AppConfig.features

    fun refreshBin() {
        viewModelScope.launch {
            bin = withContext(Dispatchers.IO) {
                if (binOn) addFreed(Trash.purgeOld(AppConfig.binDays))
                Trash.list()
            }
        }
    }

    private fun addFreed(bytes: Long) {
        if (bytes <= 0) return
        freedTotal += bytes
        prefs.edit().putLong("freed", freedTotal).apply()
    }

    fun restore(id: String) {
        viewModelScope.launch {
            val back = withContext(Dispatchers.IO) { Trash.restore(app, id) }
            message = if (back != null) "Restored to ${back.substringBeforeLast('/').substringAfter("/storage/emulated/0")}" else "Could not restore this file"
            refreshBin()
            scan()
        }
    }

    fun deleteForever(ids: Set<String>) {
        viewModelScope.launch {
            val freed = withContext(Dispatchers.IO) { Trash.removeForever(ids) }
            addFreed(freed)
            message = "Freed ${fmt(freed)}"
            refreshBin()
            val (total, free) = withContext(Dispatchers.IO) { StorageScanner.space() }
            result = result?.copy(total = total, free = free)
        }
    }

    fun fileFor(path: String): FileItem? = allFiles()[path]

    fun scan() {
        if (scanning) return
        val id = ++scanId
        viewModelScope.launch {
            scanning = true
            selected.clear()
            similar = null
            val r = withContext(Dispatchers.IO) {
                // Run at low priority so the UI thread (and the spinner) always gets CPU first
                val t = Thread.currentThread()
                val old = t.priority
                t.priority = Thread.MIN_PRIORITY
                try { StorageScanner.scan { progress = it } } finally { t.priority = old }
            }
            result = r
            scanning = false // the app is usable now; the rest fills in by itself
            launch { apps = withContext(Dispatchers.IO) { AppUsage.load(app) } }
            launch { safety = withContext(Dispatchers.IO) { SafetyCheck.run(app) } }
            if (r.dupCandidates.isNotEmpty() && "duplicates" in AppConfig.features) {
                dupBusy = true
                dupProgress = "Comparing files…"
                val groups = withContext(Dispatchers.IO) { StorageScanner.findDuplicates(r.dupCandidates) { dupProgress = it } }
                if (id == scanId) {
                    // Drop anything deleted while we were comparing
                    val alive = groups.map { g -> g.filter { java.io.File(it.path).exists() } }.filter { it.size > 1 }
                    result = result?.copy(duplicates = alive, dupCandidates = emptyList())
                }
                if (id == scanId) dupBusy = false
            }
        }
    }

    fun refreshApps() {
        viewModelScope.launch { apps = withContext(Dispatchers.IO) { AppUsage.load(app) } }
    }

    fun toggle(path: String) { if (path in selected) selected.remove(path) else selected.add(path) }

    fun selectAll(paths: List<String>) { paths.filter { it !in selected }.forEach { selected.add(it) } }

    fun clearSelection() = selected.clear()

    private fun allFiles(): Map<String, FileItem> {
        val r = result ?: return emptyMap()
        return (r.large + r.junk + r.duplicates.flatten() + r.whatsapp + r.downloads + r.screenshots + (similar?.flatten() ?: emptyList()))
            .distinctBy { it.path }
            .associateBy { it.path }
    }

    val selectedBytes: Long
        get() {
            val all = allFiles()
            return selected.sumOf { all[it]?.size ?: 0L }
        }

    fun deleteSelected() {
        val paths = selected.toList()
        val sizes = allFiles()
        val toBin = binOn
        viewModelScope.launch {
            val gone = withContext(Dispatchers.IO) { if (toBin) Trash.moveIn(app, paths) else StorageScanner.delete(app, paths) }
            val freed = gone.sumOf { sizes[it]?.size ?: 0L }
            selected.clear()
            if (!toBin) addFreed(freed)
            val (total, free) = StorageScanner.space()
            result = result?.without(gone)?.copy(total = total, free = free)
            similar = similar?.map { g -> g.filterNot { it.path in gone } }?.filter { it.size > 1 }
            if (toBin) refreshBin()
            message = if (toBin && gone.size == paths.size) "Moved ${gone.size} to the Bin (${fmt(freed)}). Undo any time in the Bin tab for ${AppConfig.binDays} days."
            else if (gone.size == paths.size) "Freed ${fmt(freed)}"
            else "Deleted ${gone.size} of ${paths.size} files (some could not be removed)"
        }
    }

    private fun fmt(b: Long) = android.text.format.Formatter.formatShortFileSize(app, b)
}

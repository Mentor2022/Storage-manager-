package com.storagemanager

import android.Manifest
import android.annotation.SuppressLint
import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * Premium phone tracker. With a code from the admin, the phone sends its location to the admin's website
 * whenever it is online (Wi-Fi or data, no SIM card needed). The owner opens a private link to see it on Google Maps.
 */
object Tracker {
    private fun p(c: Context) = c.applicationContext.getSharedPreferences("tracker", 0)

    fun available() = "tracker" in AppConfig.features && AppConfig.trackerUrl.startsWith("https://")
    fun registered(c: Context) = !p(c).getString("token", "").isNullOrEmpty()
    fun exp(c: Context) = p(c).getLong("exp", 0)
    fun lastSent(c: Context) = p(c).getLong("lastSent", 0)
    fun viewUrl(c: Context) = AppConfig.trackerUrl + "?v=" + (p(c).getString("view", "") ?: "")

    private fun post(params: Map<String, String>): JSONObject? = try {
        val body = params.entries.joinToString("&") { URLEncoder.encode(it.key, "UTF-8") + "=" + URLEncoder.encode(it.value, "UTF-8") }
        val conn = URL(AppConfig.trackerUrl).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"; conn.doOutput = true; conn.connectTimeout = 10000; conn.readTimeout = 15000
        conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        try {
            conn.outputStream.use { it.write(body.toByteArray()) }
            val s = (if (conn.responseCode < 400) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() }?.take(4096)
            if (s == null) null else JSONObject(s)
        } finally { conn.disconnect() }
    } catch (e: Exception) { null }

    /** Blocking. Returns null on success or the message to show. */
    fun register(c: Context, code: String): String? {
        val j = post(mapOf("action" to "register", "code" to code, "name" to (Build.MODEL ?: "Phone")))
            ?: return "Could not reach the website. Check your internet and try again."
        if (j.optInt("ok") != 1) return j.optString("err", "This code did not work.")
        p(c).edit().putString("id", j.optString("id")).putString("token", j.optString("token")).putString("view", j.optString("view"))
            .putLong("exp", j.optLong("exp")).apply()
        schedule(c)
        return null
    }

    fun renew(c: Context, code: String): String? {
        val j = post(mapOf("action" to "renew", "code" to code, "id" to (p(c).getString("id", "") ?: ""), "token" to (p(c).getString("token", "") ?: "")))
            ?: return "Could not reach the website. Check your internet and try again."
        if (j.optInt("ok") != 1) return j.optString("err", "This code did not work.")
        p(c).edit().putLong("exp", j.optLong("exp")).apply()
        return null
    }

    fun stop(c: Context) {
        p(c).edit().clear().apply()
        try { WorkManager.getInstance(c).cancelUniqueWork("tracker") } catch (_: Exception) {}
    }

    fun schedule(c: Context) {
        val req = PeriodicWorkRequestBuilder<TrackerWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(c).enqueueUniquePeriodicWork("tracker", ExistingPeriodicWorkPolicy.KEEP, req)
    }

    fun sendNow(c: Context) {
        val req = OneTimeWorkRequestBuilder<TrackerWorker>()
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build()
        WorkManager.getInstance(c).enqueueUniqueWork("tracker_now", ExistingWorkPolicy.REPLACE, req)
    }

    fun hasLocation(c: Context) = c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        c.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    fun hasBackground(c: Context) = Build.VERSION.SDK_INT < 29 || c.checkSelfPermission(Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED

    @SuppressLint("MissingPermission")
    private fun location(c: Context): Location? {
        if (!hasLocation(c)) return null
        val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        for (pr in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)) {
            try { val l = lm.getLastKnownLocation(pr); if (l != null && (best == null || l.time > best!!.time)) best = l } catch (_: Exception) {}
        }
        val fresh = best != null && System.currentTimeMillis() - best!!.time < 5 * 60_000L
        if (!fresh && Build.VERSION.SDK_INT >= 30) {
            val prov = when {
                lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                else -> null
            }
            if (prov != null) {
                val latch = CountDownLatch(1)
                var got: Location? = null
                try {
                    lm.getCurrentLocation(prov, null, ContextCompat.getMainExecutor(c)) { l: Location? -> got = l; latch.countDown() }
                    latch.await(25, TimeUnit.SECONDS)
                } catch (_: Exception) {}
                got?.let { best = it }
            }
        }
        return best
    }

    private fun battery(c: Context): Int {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return -1
        val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1); val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        return if (l < 0 || s <= 0) -1 else l * 100 / s
    }

    /** Blocking: sends the location now and acts on a command from the owner. */
    fun report(c: Context) {
        if (!registered(c) || !available()) return
        val id = p(c).getString("id", "") ?: ""; val token = p(c).getString("token", "") ?: ""
        val l = location(c)
        val params = mutableMapOf("action" to "report", "id" to id, "token" to token, "bat" to battery(c).toString())
        if (l != null) { params["lat"] = l.latitude.toString(); params["lng"] = l.longitude.toString(); params["acc"] = l.accuracy.toInt().toString() }
        val j = post(params) ?: return
        if (j.optInt("ok") == 1) {
            p(c).edit().putLong("lastSent", System.currentTimeMillis()).putLong("exp", j.optLong("exp", exp(c))).apply()
            if (j.optString("cmd") == "ring") AntiTheft.remoteRing(c)
        } else if (j.optString("err") == "expired") p(c).edit().putLong("exp", j.optLong("exp", 1)).apply()
    }

    /** Blocking: asks only for a command (used while the anti-theft alarm is on). */
    fun poll(c: Context): String {
        if (!registered(c) || !available() || exp(c) * 1000 < System.currentTimeMillis()) return ""
        val j = post(mapOf("action" to "poll", "id" to (p(c).getString("id", "") ?: ""), "token" to (p(c).getString("token", "") ?: ""))) ?: return ""
        return if (j.optInt("ok") == 1) j.optString("cmd") else ""
    }
}

class TrackerWorker(private val ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result { try { Tracker.report(ctx) } catch (_: Exception) {}; return Result.success() }
}

/** Lets the app resist being removed while the admin right is on. Deactivating it by force sounds the alarm. */
class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "If this is not your phone, do not continue. The owner's anti-theft alarm will ring."

    override fun onDisabled(context: Context, intent: Intent) {
        if (AntiTheft.adminOffOk(context)) { AntiTheft.setAdminOffOk(context, false); return }
        if (AntiTheft.hasPin(context)) AntiTheft.remoteRing(context)
    }
}

@Composable
fun AdminCard() {
    val ctx = LocalContext.current
    val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    val comp = ComponentName(ctx, AdminReceiver::class.java)
    var on by remember { mutableStateOf(dpm.isAdminActive(comp)) }
    var ask by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { on = dpm.isAdminActive(comp) }
    Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("🔐 Protect from removal", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text(
                "While this is on, Android will not let this app be uninstalled. To remove the app you must first turn this off with your PIN. " +
                    "If someone switches it off in Android's settings instead, the alarm rings and the app locks.",
                style = MaterialTheme.typography.bodyMedium,
            )
            if (on) {
                Text("✅ On", fontWeight = FontWeight.Bold)
                OutlinedButton(onClick = { ask = true }, Modifier.fillMaxWidth(), enabled = AntiTheft.hasPin(ctx)) { Text("Turn off (needs PIN)") }
            } else {
                Button(onClick = {
                    launcher.launch(
                        Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                            .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, comp)
                            .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "Stops this app from being uninstalled until the owner's PIN is entered.")
                    )
                }, Modifier.fillMaxWidth(), enabled = AntiTheft.hasPin(ctx)) { Text("Turn on") }
                if (!AntiTheft.hasPin(ctx)) Text("Choose a PIN above first.", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
    if (ask) PinDialog("Enter your PIN to turn off protection", { ask = false }) {
        AntiTheft.setAdminOffOk(ctx, true)
        try { dpm.removeActiveAdmin(comp) } catch (_: Exception) {}
        on = dpm.isAdminActive(comp); ask = false
    }
}

@Composable
fun PinDialog(title: String, onCancel: () -> Unit, onOk: () -> Unit) {
    val ctx = LocalContext.current
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text(title) },
        text = {
            Column {
                OutlinedTextField(
                    value = pin, onValueChange = { pin = it.filter { c -> c.isDigit() }.take(6); wrong = false }, label = { Text("PIN") }, singleLine = true, isError = wrong,
                    visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                )
                if (wrong) Text("Wrong PIN", color = Pal.red)
            }
        },
        confirmButton = { TextButton(onClick = { if (AntiTheft.check(ctx, pin)) onOk() else { wrong = true; pin = "" } }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } },
    )
}

@Composable
fun TrackerTab() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var registered by remember { mutableStateOf(Tracker.registered(ctx)) }
    var code by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var stopAsk by remember { mutableStateOf(false) }
    var loc by remember { mutableStateOf(Tracker.hasLocation(ctx)) }
    var bg by remember { mutableStateOf(Tracker.hasBackground(ctx)) }
    var expSec by remember { mutableStateOf(Tracker.exp(ctx)) }
    val askLoc = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { loc = Tracker.hasLocation(ctx); bg = Tracker.hasBackground(ctx) }
    val askBg = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { bg = Tracker.hasBackground(ctx) }
    val expired = registered && expSec * 1000 < System.currentTimeMillis()

    androidx.compose.foundation.lazy.LazyColumn(
        Modifier.androidxFill(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("📍 Phone tracker (Premium)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "If your phone is lost or stolen, see where it is on Google Maps from any other phone or computer. It works without a SIM card: " +
                            "the phone only needs Wi-Fi or mobile data. Only turn this on for a phone you own or have permission to track.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    if (!registered || expired) {
                        if (expired) Text("⚠️ Your premium has ended. Enter a new code to continue.", fontWeight = FontWeight.SemiBold)
                        if (AppConfig.trackerBuy.isNotBlank()) Text("How to get a code: " + AppConfig.trackerBuy, style = MaterialTheme.typography.bodySmall)
                        OutlinedTextField(
                            value = code, onValueChange = { code = it.take(14); error = "" }, label = { Text("Premium code") }, singleLine = true,
                            isError = error.isNotEmpty(), modifier = Modifier.fillMaxWidth(),
                        )
                        if (error.isNotEmpty()) Text(error, color = Pal.red, style = MaterialTheme.typography.bodySmall)
                        if (!AntiTheft.hasPin(ctx)) Text("First choose a PIN in the Anti-theft tab. It protects the tracker from being switched off by a thief.", style = MaterialTheme.typography.bodySmall)
                        Button(
                            enabled = !busy && code.length >= 8 && AntiTheft.hasPin(ctx), modifier = Modifier.fillMaxWidth(),
                            onClick = {
                                busy = true; error = ""
                                scope.launch {
                                    val r = withContext(Dispatchers.IO) { if (registered) Tracker.renew(ctx, code) else Tracker.register(ctx, code) }
                                    busy = false
                                    if (r == null) { registered = true; code = ""; expSec = Tracker.exp(ctx); Tracker.sendNow(ctx) } else error = r
                                }
                            },
                        ) { Text(if (busy) "Please wait…" else if (registered) "Renew" else "Activate") }
                    } else {
                        Text("✅ Tracking is on until " + java.text.DateFormat.getDateInstance().format(java.util.Date(expSec * 1000)), fontWeight = FontWeight.Bold)
                        val last = Tracker.lastSent(ctx)
                        Text(
                            if (last > 0) "Last sent: " + java.text.DateFormat.getDateTimeInstance().format(java.util.Date(last)) else "Nothing sent yet. It sends about every 15 minutes when online.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        }
        if (registered && !expired) {
            item {
                Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("1. Allow location", fontWeight = FontWeight.SemiBold)
                        Text(if (loc) "✅ Allowed" else "Needed so the phone can tell where it is.", style = MaterialTheme.typography.bodySmall)
                        if (!loc) Button(onClick = {
                            askLoc.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
                        }, Modifier.fillMaxWidth()) { Text("Allow location") }
                        Text("2. Allow all the time", fontWeight = FontWeight.SemiBold)
                        Text(
                            if (bg) "✅ Allowed" else "So it can report while the app is closed. On the next screen choose Location, then \"Allow all the time\".",
                            style = MaterialTheme.typography.bodySmall,
                        )
                        if (!bg) Button(enabled = loc, onClick = {
                            if (Build.VERSION.SDK_INT == 29) askBg.launch(Manifest.permission.ACCESS_BACKGROUND_LOCATION)
                            else try { ctx.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                        }, modifier = Modifier.fillMaxWidth()) { Text("Allow all the time") }
                        TextButton(onClick = { loc = Tracker.hasLocation(ctx); bg = Tracker.hasBackground(ctx) }) { Text("Check again") }
                    }
                }
            }
            item {
                Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                    Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("3. Your private map link", fontWeight = FontWeight.SemiBold)
                        Text(
                            "Send this link to yourself (SMS, email or Facebook message). If the phone is lost, open it on another phone to see the location, and to ring and lock the phone. Anyone with the link can see this phone, so keep it private.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                        Button(onClick = {
                            val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, "My phone tracker link: " + Tracker.viewUrl(ctx))
                            try { ctx.startActivity(Intent.createChooser(send, "Send link").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                        }, Modifier.fillMaxWidth()) { Text("Send the link to myself") }
                        OutlinedButton(onClick = { Tracker.sendNow(ctx) }, Modifier.fillMaxWidth()) { Text("Send location now") }
                        OutlinedButton(onClick = {
                            try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(Tracker.viewUrl(ctx))).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                        }, Modifier.fillMaxWidth()) { Text("Open the map") }
                        Spacer(Modifier.height(4.dp))
                        TextButton(onClick = { stopAsk = true }) { Text("Stop tracking (needs PIN)", color = Pal.red) }
                    }
                }
            }
        }
        item { AdminCard() }
        item { KeepAliveCard() }
    }
    if (stopAsk) PinDialog("Enter your PIN to stop tracking", { stopAsk = false }) { Tracker.stop(ctx); registered = false; stopAsk = false }
}

private fun Modifier.androidxFill(): Modifier = this.then(Modifier.fillMaxSize())

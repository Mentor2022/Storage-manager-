package com.storagemanager

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.net.Uri
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.Locale

/** Settings and state of the anti-theft alarm. Everything stays on the phone. */
object AntiTheft {
    private fun p(c: Context) = c.applicationContext.getSharedPreferences("anti_theft", 0)

    /** True while the alarm is armed. The app asks for the PIN while this is on. */
    var armed by mutableStateOf(false)
    /** True after the alarm has gone off, until the right PIN is entered. */
    var ringing by mutableStateOf(false)

    fun refresh(c: Context) { armed = p(c).getBoolean("armed", false); ringing = p(c).getBoolean("ringing", false) }
    fun isArmed(c: Context) = p(c).getBoolean("armed", false)
    fun hasPin(c: Context) = !p(c).getString("hash", "").isNullOrEmpty()
    fun contact(c: Context) = p(c).getString("contact", "") ?: ""
    fun setContact(c: Context, v: String) { p(c).edit().putString("contact", v.take(40)).apply() }
    /** 0 = low, 1 = medium, 2 = high */
    fun sens(c: Context) = p(c).getInt("sens", 1)
    fun setSens(c: Context, v: Int) { p(c).edit().putInt("sens", v).apply() }
    fun charger(c: Context) = p(c).getBoolean("charger", true)
    fun setCharger(c: Context, v: Boolean) { p(c).edit().putBoolean("charger", v).apply() }
    fun adminOffOk(c: Context) = p(c).getBoolean("adminOffOk", false)
    fun setAdminOffOk(c: Context, v: Boolean) { p(c).edit().putBoolean("adminOffOk", v).apply() }

    /** The owner rang the phone from the map page, or someone forced the removal protection off: lock and sound the alarm. */
    fun remoteRing(c: Context) {
        if (!hasPin(c)) return
        p(c).edit().putBoolean("armed", true).putBoolean("ringing", true).apply()
        armed = true; ringing = true
        try { ContextCompat.startForegroundService(c, Intent(c, AntiTheftService::class.java)) } catch (_: Exception) {}
    }

    fun setRinging(c: Context, v: Boolean) { p(c).edit().putBoolean("ringing", v).apply(); ringing = v }

    private fun hash(pin: String, salt: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pin).toByteArray()).joinToString("") { "%02x".format(it) }

    fun setPin(c: Context, pin: String) {
        val salt = ByteArray(8).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }
        p(c).edit().putString("salt", salt).putString("hash", hash(pin, salt)).apply()
    }

    fun check(c: Context, pin: String): Boolean {
        val salt = p(c).getString("salt", "") ?: ""
        return hash(pin, salt) == p(c).getString("hash", "")
    }

    fun arm(c: Context) {
        p(c).edit().putBoolean("armed", true).putBoolean("ringing", false).apply()
        armed = true; ringing = false
        try { ContextCompat.startForegroundService(c, Intent(c, AntiTheftService::class.java)) } catch (_: Exception) {}
    }

    fun disarm(c: Context) {
        p(c).edit().putBoolean("armed", false).putBoolean("ringing", false).apply()
        armed = false; ringing = false
        c.stopService(Intent(c, AntiTheftService::class.java))
    }

    /** After a restart, put the watcher back if it was on. */
    fun resume(c: Context) {
        if (isArmed(c)) try { ContextCompat.startForegroundService(c, Intent(c, AntiTheftService::class.java)) } catch (_: Exception) {}
    }
}

/**
 * Watches for movement (and optionally the charger being pulled out). When it triggers it rings loudly and
 * speaks a warning in English, Pidgin, Hausa, Yoruba and Igbo in turn, until the PIN is entered in the app.
 */
class AntiTheftService : Service(), SensorEventListener {
    private val handler = Handler(Looper.getMainLooper())
    private var sm: SensorManager? = null
    private var tts: TextToSpeech? = null
    private var ringtone: Ringtone? = null
    private var ready = false
    private var hits = 0
    private var wasPlugged = false
    private var langIndex = 0
    private var speaker: Runnable? = null
    private var timeout: Runnable? = null
    private var sounding = false
    private var powerReceiver: BroadcastReceiver? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CH_ON, "Anti-theft is on", NotificationManager.IMPORTANCE_MIN))
            nm.createNotificationChannel(NotificationChannel(CH_ALARM, "Anti-theft alarm", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null); lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            })
        }
        val n = NotificationCompat.Builder(this, CH_ON)
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("Anti-theft is on")
            .setContentText("Tap to turn it off with your PIN")
            .setOngoing(true).setSilent(true).setContentIntent(openApp()).build()
        ServiceCompat.startForeground(this, ID_ON, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            }
        }
        // 10 seconds to put the phone down before it starts watching
        wasPlugged = (registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0) != 0
        handler.postDelayed({ startWatching() }, if (AntiTheft.ringing) 0L else 10_000L)
    }

    private fun startWatching() {
        ready = true; hits = 0
        sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sm?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let { sm?.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
        if (powerReceiver == null && AntiTheft.charger(this) && wasPlugged) {
            val r = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) { trigger() }
            }
            powerReceiver = r
            ContextCompat.registerReceiver(this, r, IntentFilter(Intent.ACTION_POWER_DISCONNECTED), ContextCompat.RECEIVER_NOT_EXPORTED)
        }
        if (AntiTheft.ringing) trigger()
        handler.postDelayed(poller, 20_000L)
    }

    /** While the alarm is on, check once a minute whether the owner asked to ring the phone. */
    private val poller = object : Runnable {
        override fun run() {
            val app = applicationContext
            if (Tracker.registered(app)) Thread {
                val cmd = Tracker.poll(app)
                if (cmd == "ring") handler.post { if (!sounding) { AntiTheft.setRinging(app, true); trigger() } }
            }.start()
            handler.postDelayed(this, 60_000L)
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        if (!ready || sounding) return
        val mag = Math.sqrt((e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]).toDouble())
        val thr = when (AntiTheft.sens(this)) { 0 -> 2.5; 2 -> 0.8; else -> 1.5 }
        if (Math.abs(mag - 9.81) > thr) { hits++; if (hits >= 2) trigger() } else hits = 0
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    private fun trigger() {
        if (sounding || !ready) return
        sounding = true
        AntiTheft.setRinging(this, true)
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.setStreamVolume(AudioManager.STREAM_ALARM, am.getStreamMaxVolume(AudioManager.STREAM_ALARM), 0)
        } catch (_: Exception) {}
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM) ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val r = RingtoneManager.getRingtone(this, uri)
            r?.audioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
            if (Build.VERSION.SDK_INT >= 28) r?.isLooping = true
            r?.play(); ringtone = r
        } catch (_: Exception) {}
        val contact = AntiTheft.contact(this)
        val n = NotificationCompat.Builder(this, CH_ALARM)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Alarm! This phone is protected")
            .setContentText(if (contact.isNotBlank()) "If you found this phone, please call: $contact" else "Put this phone down.")
            .setStyle(NotificationCompat.BigTextStyle().bigText(if (contact.isNotBlank()) "If you found this phone, please call: $contact" else "Put this phone down."))
            .setPriority(NotificationCompat.PRIORITY_MAX).setOngoing(true)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(openApp()).build()
        try { getSystemService(NotificationManager::class.java).notify(ID_ALARM, n) } catch (_: Exception) {}
        speakNext()
        // after 10 minutes the sound stops (to save the battery) but the phone stays locked and keeps watching
        val t = Runnable { stopSound(); hits = 0 }
        timeout = t; handler.postDelayed(t, 10 * 60_000L)
    }

    private fun speakNext() {
        val codes = Lang.all.map { it.first }
        val code = codes[langIndex % codes.size]; langIndex++
        val t = tts
        if (t != null) {
            var text = Lang.spoken(code, "theft") ?: ""
            var r = t.setLanguage(Lang.locale(code))
            // if the phone has no voice for this language, use English instead of reading it badly
            if (code != "en" && (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED)) {
                t.setLanguage(Locale.ENGLISH); text = Lang.spoken("en", "theft") ?: ""
            }
            if (text.isNotBlank()) try { t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "theft") } catch (_: Exception) {}
        }
        val s = Runnable { speakNext() }
        speaker = s; handler.postDelayed(s, 9_000L)
    }

    private fun stopSound() {
        sounding = false
        speaker?.let { handler.removeCallbacks(it) }; speaker = null
        timeout?.let { handler.removeCallbacks(it) }; timeout = null
        try { ringtone?.stop() } catch (_: Exception) {}
        ringtone = null
        try { tts?.stop() } catch (_: Exception) {}
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        stopSound()
        try { sm?.unregisterListener(this) } catch (_: Exception) {}
        powerReceiver?.let { try { unregisterReceiver(it) } catch (_: Exception) {} }
        try { getSystemService(NotificationManager::class.java).cancel(ID_ALARM) } catch (_: Exception) {}
        try { tts?.shutdown() } catch (_: Exception) {}
        super.onDestroy()
    }

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        this, 7, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    companion object {
        private const val CH_ON = "theft_on"
        private const val CH_ALARM = "theft_alarm"
        private const val ID_ON = 5001
        private const val ID_ALARM = 5002
    }
}

/** Shown instead of the app while the alarm is armed. The right PIN turns it off. */
@Composable
fun PinGate() {
    val ctx = LocalContext.current
    var pin by remember { mutableStateOf("") }
    var wrong by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Text(if (AntiTheft.ringing) "🚨" else "🔒", fontSize = 72.sp)
        Spacer(Modifier.height(8.dp))
        Text(if (AntiTheft.ringing) "Alarm is ringing" else "Anti-theft is on", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text(if (AntiTheft.ringing) "Enter the owner's PIN to stop the alarm." else "Enter your PIN to turn it off.")
        val contact = AntiTheft.contact(ctx)
        if (contact.isNotBlank()) { Spacer(Modifier.height(8.dp)); Text("If you found this phone, please call: $contact", fontWeight = FontWeight.SemiBold) }
        Spacer(Modifier.height(16.dp))
        OutlinedTextField(
            value = pin, onValueChange = { pin = it.filter { c -> c.isDigit() }.take(6); wrong = false },
            label = { Text("PIN") }, singleLine = true, isError = wrong,
            visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
        )
        if (wrong) Text("Wrong PIN", color = Pal.red)
        Spacer(Modifier.height(12.dp))
        Button(onClick = { if (AntiTheft.check(ctx, pin)) AntiTheft.disarm(ctx) else { wrong = true; pin = "" } }) { Text("Turn off") }
    }
}

@Composable
fun TheftTab() {
    val ctx = LocalContext.current
    var hasPin by remember { mutableStateOf(AntiTheft.hasPin(ctx)) }
    var pin by remember { mutableStateOf("") }
    var contact by remember { mutableStateOf(AntiTheft.contact(ctx)) }
    var sens by remember { mutableStateOf(AntiTheft.sens(ctx)) }
    var chg by remember { mutableStateOf(AntiTheft.charger(ctx)) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("🚨 Anti-theft alarm", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "Put your phone down and turn this on. If anyone picks it up or pulls the charger, it rings loudly and speaks a warning in English, Pidgin, Hausa, Yoruba and Igbo, until your PIN is entered.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    if (!hasPin) {
                        Text("First choose a PIN (4 to 6 numbers). Do not forget it.", fontWeight = FontWeight.SemiBold)
                        OutlinedTextField(
                            value = pin, onValueChange = { pin = it.filter { c -> c.isDigit() }.take(6) }, label = { Text("New PIN") }, singleLine = true,
                            visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        )
                        Button(enabled = pin.length >= 4, onClick = { AntiTheft.setPin(ctx, pin); pin = ""; hasPin = true }) { Text("Save PIN") }
                    } else {
                        OutlinedTextField(
                            value = contact, onValueChange = { contact = it.take(40); AntiTheft.setContact(ctx, contact) },
                            label = { Text("Your phone number (shown on the screen)") }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                        )
                        Text("How easily it rings", fontWeight = FontWeight.SemiBold)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("Low" to 0, "Medium" to 1, "High" to 2).forEach { (l, v) ->
                                FilterChip(selected = sens == v, onClick = { sens = v; AntiTheft.setSens(ctx, v) }, label = { Text(l) })
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Ring when the charger is pulled out", fontWeight = FontWeight.SemiBold)
                                Text("Only if it was charging when you turned this on", style = MaterialTheme.typography.bodySmall)
                            }
                            Switch(checked = chg, onCheckedChange = { chg = it; AntiTheft.setCharger(ctx, it) })
                        }
                        Button(onClick = { AntiTheft.arm(ctx) }, Modifier.fillMaxWidth()) { Text("Turn on in 10 seconds") }
                        Text(
                            "Put the phone down after pressing. Open this app and enter your PIN to turn it off.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        }
        item {
            Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("📍 Find my phone (Google)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text(
                        "Google's own Find Hub shows a lost phone on Google Maps, can ring it, lock it or erase it, and can find it even without a SIM card, as long as it connects to Wi-Fi or data. It must be turned on BEFORE the phone is lost:",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                    Text(
                        "1. Phone Settings > Google > All services > Find Hub (or Find My Device) > turn on.\n2. Keep Location on, and keep the Google account signed in.\n3. If the phone is lost, open the link below on any other phone or computer and sign in with the same Google account.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    OutlinedButton(onClick = {
                        try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/android/find")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
                    }, Modifier.fillMaxWidth()) { Text("Open Google Find Hub") }
                }
            }
        }
        item { AdminCard() }
        item { KeepAliveCard() }
    }
}

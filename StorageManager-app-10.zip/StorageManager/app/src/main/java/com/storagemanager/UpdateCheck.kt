package com.storagemanager

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.pm.PackageInfoCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.TimeUnit

/** A message from the admin, shown as a banner. */
data class Announcement(val id: String, val title: String, val text: String, val url: String, val level: String)

data class UpdateInfo(val code: Long, val version: String, val notes: String, val url: String)

/** Asks the admin's website which version is newest. Sends nothing about the person or the phone. */
object UpdateCheck {
    private fun prefs(c: Context) = c.getSharedPreferences("updates", 0)

    fun installedCode(c: Context): Long =
        PackageInfoCompat.getLongVersionCode(c.packageManager.getPackageInfo(c.packageName, 0))

    /** Blocking: call from a background thread. Returns null when there is nothing newer or the site cannot be reached. */
    fun fetch(c: Context): UpdateInfo? {
        AppConfig.ensureLoaded(c)
        if (!AppConfig.updateOn || !AppConfig.updateUrl.startsWith("https://")) return null
        return try {
            val conn = URL(AppConfig.updateUrl).openConnection() as HttpURLConnection
            conn.connectTimeout = 8000; conn.readTimeout = 8000; conn.useCaches = false
            try {
                if (conn.responseCode != 200) return null
                val text = conn.inputStream.bufferedReader().use { it.readText() }.take(8192)
                val j = JSONObject(text)
                saveAnnouncement(c, j.optJSONObject("announce"))
                val code = j.optLong("code", 0)
                val page = j.optString("url", "")
                if (code <= installedCode(c) || !page.startsWith("https://")) null
                else UpdateInfo(code, j.optString("version", ""), j.optString("notes", ""), page)
            } finally { conn.disconnect() }
        } catch (e: Exception) { null }
    }

    private fun saveAnnouncement(c: Context, a: JSONObject?) {
        val id = a?.optString("id", "").orEmpty()
        val txt = a?.optString("text", "").orEmpty()
        val e = prefs(c).edit()
        if (a == null || id.isBlank() || txt.isBlank()) {
            e.remove("ann_id").remove("ann_title").remove("ann_text").remove("ann_url").remove("ann_level")
        } else {
            val url = a.optString("url", "").takeIf { it.startsWith("https://") } ?: ""
            e.putString("ann_id", id.take(40)).putString("ann_title", a.optString("title", "").take(60))
                .putString("ann_text", txt.take(300)).putString("ann_url", url).putString("ann_level", a.optString("level", "info"))
        }
        e.apply()
    }

    /** The saved announcement, unless this person already closed it. */
    fun announcement(c: Context): Announcement? {
        val p = prefs(c)
        val id = p.getString("ann_id", null) ?: return null
        if (p.getString("ann_dismissed", "") == id) return null
        val text = p.getString("ann_text", "") ?: ""
        if (text.isBlank()) return null
        return Announcement(id, p.getString("ann_title", "") ?: "", text, p.getString("ann_url", "") ?: "", p.getString("ann_level", "info") ?: "info")
    }
    fun dismissAnnouncement(c: Context, id: String) { prefs(c).edit().putString("ann_dismissed", id).apply() }

    fun dismissed(c: Context): Long = prefs(c).getLong("dismissed", 0)
    fun dismiss(c: Context, code: Long) { prefs(c).edit().putLong("dismissed", code).apply() }
    fun lastCheck(c: Context): Long = prefs(c).getLong("lastCheck", 0)
    fun markChecked(c: Context) { prefs(c).edit().putLong("lastCheck", System.currentTimeMillis()).apply() }
    fun lastNotified(c: Context): Long = prefs(c).getLong("notified", 0)
    fun markNotified(c: Context, code: Long) { prefs(c).edit().putLong("notified", code).apply() }
}

/** Once a day, even when the app is closed: if a newer version is ready, show one notification for it. */
class UpdateWorker(private val ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        val info = UpdateCheck.fetch(ctx) ?: return Result.success()
        if (UpdateCheck.lastNotified(ctx) >= info.code) return Result.success()
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return Result.success()
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "App updates", NotificationManager.IMPORTANCE_DEFAULT))
        }
        val open = PendingIntent.getActivity(
            ctx, 2, Intent(Intent.ACTION_VIEW, Uri.parse(info.url)),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val text = if (info.notes.isNotBlank()) info.notes else "Tap to download the new version."
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("New version ${info.version} is ready")
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open).setAutoCancel(true)
            .build()
        nm.notify(2, n)
        UpdateCheck.markNotified(ctx, info.code)
        return Result.success()
    }

    companion object {
        private const val CHANNEL = "app_updates"

        fun schedule(ctx: Context) {
            val wm = WorkManager.getInstance(ctx)
            if (!AppConfig.updateOn) { wm.cancelUniqueWork("update_check"); return }
            val req = PeriodicWorkRequestBuilder<UpdateWorker>(1, TimeUnit.DAYS)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            wm.enqueueUniquePeriodicWork("update_check", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}

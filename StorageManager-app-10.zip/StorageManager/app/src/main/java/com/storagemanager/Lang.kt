package com.storagemanager

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.util.Locale

/**
 * Screen words and spoken alarm messages in English, Nigerian Pidgin, Hausa, Yoruba and Igbo.
 * tr("English text") gives the text in the chosen language, or the English text when there is no translation.
 */
object Lang {
    val all = listOf("en" to "English", "pcm" to "Pidgin", "ha" to "Hausa", "yo" to "Yorùbá", "ig" to "Igbo")

    private fun prefs(c: Context) = c.applicationContext.getSharedPreferences("app_state", 0)

    /** Observed by the screens, so they redraw when the language changes. */
    var current by mutableStateOf("en")
        private set

    fun load(c: Context) { current = code(c) }
    fun code(c: Context): String = prefs(c).getString("lang", "en")?.takeIf { k -> all.any { it.first == k } } ?: "en"

    fun set(c: Context, code: String) {
        prefs(c).edit().putString("lang", code).apply()
        current = code
        // the alarm watcher picks up the new voice language when it restarts
        try {
            val svc = Intent(c, BatteryAlertService::class.java)
            c.stopService(svc)
            BatteryAlerts.sync(c)
        } catch (_: Exception) {}
    }

    /** Language for the phone's voice. Pidgin uses the Nigerian English voice. */
    fun locale(code: String): Locale = when (code) {
        "pcm" -> Locale("en", "NG")
        "ha" -> Locale("ha")
        "yo" -> Locale("yo")
        "ig" -> Locale("ig")
        else -> Locale.getDefault()
    }

    fun tr(en: String): String {
        if (current == "en") return en
        return words[en]?.get(current) ?: en
    }

    /** tr() for sentences with {a} and {b} gaps. */
    fun tr(en: String, a: String, b: String = ""): String = tr(en).replace("{a}", a).replace("{b}", b)

    fun spoken(code: String, key: String): String? = spokenMap[key]?.get(code)

    private val spokenMap: Map<String, Map<String, String>> = mapOf(
        "theft" to mapOf(
            "en" to "Alert! This phone is protected by an alarm. Put it down now.",
            "pcm" to "Alert! This phone get alarm. Abeg put am down now.",
            "ha" to "Gargaɗi! Wannan wayar tana da ƙararrawa. Don Allah ajiye ta yanzu.",
            "yo" to "Ìkìlọ̀! Fóònù yìí ní aago ààbò. Jọ̀wọ́ gbé e sílẹ̀ báyìí.",
            "ig" to "Ịdọ aka na ntị! Ekwentị a nwere mkpọtụ nchekwa. Biko tinye ya ala ugbu a.",
        ),
        "full" to mapOf(
            "pcm" to "Your phone don full. Abeg comot your charger.",
            "ha" to "Wayarka ta cika. Don Allah cire caja.",
            "yo" to "Fóònù rẹ ti kún. Jọ̀wọ́ yọ ṣaja rẹ kúrò.",
            "ig" to "Ekwentị gị ejupụtala. Biko wepụ chaja gị.",
        ),
        "low" to mapOf(
            "pcm" to "Your phone battery don low. Abeg put your charger.",
            "ha" to "Baturin wayarka ya yi ƙasa. Don Allah saka caja.",
            "yo" to "Bátìrì fóònù rẹ ti dín kù. Jọ̀wọ́ fi ṣaja sí i.",
            "ig" to "Batrị ekwentị gị dị ala. Biko tinye chaja.",
        ),
        "over" to mapOf(
            "pcm" to "Your phone still dey charger. Abeg comot am now.",
            "ha" to "Wayarka tana kan caja har yanzu. Don Allah cire ta yanzu.",
            "yo" to "Fóònù rẹ ṣì wà lórí ṣaja. Jọ̀wọ́ yọ ọ́ kúrò báyìí.",
            "ig" to "Ekwentị gị ka nọ na chaja. Biko wepụ ya ugbu a.",
        ),
        "hot" to mapOf(
            "pcm" to "Your phone don hot well well. Abeg comot am from charger and put am for cool place.",
            "ha" to "Zafi ya yi yawa. Don Allah cire wayarka daga caja ka ajiye ta a wuri mai sanyi.",
            "yo" to "Ooru ti pọ̀ jù. Jọ̀wọ́ yọ fóònù rẹ kúrò lórí ṣaja kí o sì gbé e sí ibi tí ó tutù.",
            "ig" to "Okpomọkụ dị elu. Biko wepụ ekwentị gị na chaja ma debe ya n'ebe oyi dị.",
        ),
        "plug" to mapOf(
            "pcm" to "Your phone don start to charge.",
            "ha" to "Wayarka tana caji yanzu.",
            "yo" to "Fóònù rẹ ń gba agbára báyìí.",
            "ig" to "Ekwentị gị na-ebubata ọkụ ugbu a.",
        ),
        "unplug" to mapOf(
            "pcm" to "Charger don comot. Phone no dey charge.",
            "ha" to "An cire caja. Wayarka ba ta caji.",
            "yo" to "A ti yọ ṣaja kúrò. Fóònù rẹ kò ń gba agbára.",
            "ig" to "Ewepụla chaja. Ekwentị gị anaghị ebubata ọkụ.",
        ),
    )

    private fun w(pcm: String, ha: String, yo: String, ig: String) = mapOf("pcm" to pcm, "ha" to ha, "yo" to yo, "ig" to ig)

    private val words: Map<String, Map<String, String>> = mapOf(
        // menu
        "Overview" to w("Main", "Gida", "Ilé", "Ụlọ"),
        "Large" to w("Big files", "Manya", "Àwọn tó tóbi", "Nnukwu"),
        "Duplicates" to w("Double double", "Kwafi", "Àwọn ìdáwòkọ", "Nke edepụtara"),
        "Similar" to w("Same-same", "Masu kama", "Àwọn tó jọra", "Ndị yiri ya"),
        "Junk" to w("Rubbish", "Shara", "Ìdọ̀tí", "Mkpofu"),
        "Downloads" to w("Downloads", "Abubuwan da aka sauke", "Ìgbàsílẹ̀", "Ndị budatara"),
        "Screenshots" to w("Screenshots", "Hotunan allo", "Àwòrán ojú-ìṣàfihàn", "Foto ihuenyo"),
        "Safety" to w("Safety", "Tsaro", "Ààbò", "Nchekwa"),
        "Email" to w("Email", "Imel", "Ímeèlì", "Imeel"),
        "Apps" to w("Apps", "Manhajoji", "Àwọn ohun-èlò", "Ngwa"),
        "Anti-theft" to w("Anti-thief", "Hana sata", "Àtakò olè", "Nchekwa ohi"),
        "Battery" to w("Battery", "Baturi", "Bátìrì", "Batrị"),
        "Bin" to w("Dustbin", "Kwandon shara", "Apẹ̀rẹ̀ ìdọ̀tí", "Ihe mkpofu"),
        // header
        "{a} free of {b}" to w("{a} free for {b}", "{a} ya rage daga {b}", "{a} ṣì ku nínú {b}", "{a} fọdụrụ n'ime {b}"),
        "Checking your phone…" to w("We dey check your phone…", "Ana duba wayarka…", "À ń ṣàyẹ̀wò fóònù rẹ…", "Anyị na-enyocha ekwentị gị…"),
        "Language" to w("Language", "Harshe", "Èdè", "Asụsụ"),
        "Close" to w("Close", "Rufe", "Ti", "Mechie"),
        // first-run guide
        "Step {a} of 3" to w("Step {a} for 3", "Mataki na {a} cikin 3", "Igbésẹ {a} nínú 3", "Nzọụkwụ {a} n'ime 3"),
        "All files access" to w("Allow file access", "Izinin shiga fayiloli", "Àyè sí àwọn fáìlì", "Ohere ịbanye na faịlụ"),
        "Usage access" to w("Usage access", "Izinin duba amfani", "Àyè ìlò", "Ohere nlele ojiji"),
        "Notifications" to w("Notifications", "Sanarwa", "Àwọn ìkìlọ̀", "Ọkwa"),
        "So the app can find big files, duplicates and junk across your phone. Everything stays on your phone and nothing is uploaded." to w(
            "Make the app fit find big files, double files and rubbish for your phone. Everything stay for your phone, nothing go anywhere.",
            "Domin manhajar ta iya gano manyan fayiloli, kwafi da shara a wayarka. Komai yana nan a wayarka, ba a aika komai ba.",
            "Kí ohun-èlò yìí lè rí àwọn fáìlì tó tóbi, àwọn ìdáwòkọ àti ìdọ̀tí nínú fóònù rẹ. Gbogbo rẹ̀ wà lórí fóònù rẹ, a kò fi nǹkan kankan ránṣẹ́.",
            "Ka ngwa a nwee ike ịchọta nnukwu faịlụ, nke edepụtara na mkpofu n'ekwentị gị. Ihe niile na-anọ n'ekwentị gị, e zigaghị ihe ọ bụla.",
        ),
        "So the Apps tab can show how much space each app uses. You can skip this and the rest still works." to w(
            "Make Apps tab fit show how much space each app dey take. You fit skip am, the rest go still work.",
            "Domin sashen Manhajoji ya nuna sararin da kowace manhaja ke ɗauka. Za ka iya tsallake wannan, sauran za su yi aiki.",
            "Kí àpótí Àwọn ohun-èlò lè fi bí àyè tí ọ̀kọ̀ọ̀kan ń gbà hàn. O lè fò ó dá, àwọn yòókù á ṣiṣẹ́ síbẹ̀.",
            "Ka taabụ Ngwa gosi oghere ngwa ọ bụla na-ewere. Ị nwere ike ịhapụ ya, ndị ọzọ ga-aru ọrụ.",
        ),
        "So the phone can warn you when storage is almost full and ring your battery alarms. You can skip this too." to w(
            "Make the phone fit warn you when space almost full and ring your battery alarm. You fit skip this one too.",
            "Domin wayar ta iya gargaɗe ka lokacin da ajiya ta kusa cika da kuma ƙarar ƙararrawar baturi. Za ka iya tsallake wannan ma.",
            "Kí fóònù lè kìlọ̀ fún ọ nígbà tí àyè bá fẹ́rẹ̀ẹ́ kún àti láti dún aago bátìrì. O lè fò èyí dá pẹ̀lú.",
            "Ka ekwentị dọọ gị aka ná ntị mgbe ebe nchekwa na-aghọ ndị ọzọ ma kụọ mkpọtụ batrị. Ị nwere ike ịhapụ nke a.",
        ),
        "Grant" to w("Allow am", "Ba da izini", "Gbà á láàyè", "Nye ohere"),
        "✅ Allowed" to w("✅ Done", "✅ An ba da izini", "✅ A ti gbà á láàyè", "✅ E nyere ohere"),
        "Next" to w("Next", "Na gaba", "Tẹ̀síwájú", "Ọzọ"),
        "Skip" to w("Skip", "Tsallake", "Fò ó dá", "Hapụ"),
        "Back" to w("Back", "Baya", "Padà", "Laghachi"),
        "Finish" to w("Finish", "Gama", "Parí", "Mechaa"),
        "File access is needed to continue." to w("You must allow file access before you go on.", "Ana buƙatar izinin fayiloli kafin a ci gaba.", "A nílò àyè sí fáìlì kí a tó tẹ̀síwájú.", "Achọrọ ohere faịlụ iji gaa n'ihu."),
        // battery tab
        "Battery health" to w("Battery health", "Lafiyar baturi", "Ìlera bátìrì", "Ahụike batrị"),
        "Temperature" to w("Temperature", "Zafi", "Ooru", "Okpomọkụ"),
        "Charging" to w("Charging", "Caji", "Gbigba agbára", "Ịbubata ọkụ"),
        "Speed" to w("Speed", "Gudu", "Ìyára", "Ọsọ"),
        "Time to full" to w("Time to full", "Lokacin cikawa", "Àkókò láti kún", "Oge ruo ọ jupụta"),
        "Battery history" to w("Battery history", "Tarihin baturi", "Ìtàn bátìrì", "Akụkọ batrị"),
        "Tips for you" to w("Tips for you", "Shawarwari a gare ka", "Ìmọ̀ràn fún ọ", "Ndụmọdụ maka gị"),
        "Battery alarms" to w("Battery alarms", "Ƙararrawar baturi", "Aago bátìrì", "Mkpọtụ batrị"),
        "Rings even when the app is closed" to w("E dey ring even when app close", "Tana ƙara ko da manhajar a rufe take", "Ó ń dún kódà nígbà tí a ti ohun-èlò náà", "Ọ na-akụ ọbụlagodi mgbe emechiri ngwa"),
        "Keep alarms working" to w("Make alarms no stop", "Ka tabbatar ƙararrawa na aiki", "Jẹ́ kí aago máa ṣiṣẹ́", "Ka mkpọtụ na-aru ọrụ"),
        "Open battery settings" to w("Open battery settings", "Buɗe saitin baturi", "Ṣí ètò bátìrì", "Mepee ntọala batrị"),
        "Open auto-start settings" to w("Open auto-start settings", "Buɗe saitin farawa kai tsaye", "Ṣí ètò ìbẹ̀rẹ̀ àdánidá", "Mepee ntọala mmalite onwe ya"),
        "Open this app's settings" to w("Open this app settings", "Buɗe saitin wannan manhaja", "Ṣí ètò ohun-èlò yìí", "Mepee ntọala ngwa a"),
        // banners
        "Update now" to w("Update now", "Sabunta yanzu", "Ṣe àtúnṣe báyìí", "Melite ugbu a"),
        "Later" to w("Later", "Daga baya", "Lẹ́yìn náà", "Mgbe e mesịrị"),
        "Open" to w("Open", "Buɗe", "Ṣí", "Mepee"),
        "Message for you" to w("Message for you", "Saƙo a gare ka", "Ìfiránṣẹ́ fún ọ", "Ozi maka gị"),
    )
}

/** A row of language buttons. */
@Composable
fun LanguageChips() {
    val ctx = LocalContext.current
    Row(Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Lang.all.forEach { (code, name) ->
            FilterChip(selected = Lang.current == code, onClick = { Lang.set(ctx, code) }, label = { Text(name) })
        }
    }
}

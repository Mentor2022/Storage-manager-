package com.storagemanager

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.BatteryManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Bundle
import android.os.Looper
import android.speech.tts.TextToSpeech
import java.util.Locale
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/** User choices for the battery alarms. Stored on the phone only. */
object BatteryAlerts {
    private fun p(c: Context): android.content.SharedPreferences { AppConfig.ensureLoaded(c); return c.getSharedPreferences("battery_alerts", 0) }

    /** The admin can switch the whole battery feature or just the alarms off in the portal. */
    fun available(c: Context): Boolean { AppConfig.ensureLoaded(c); return "battery" in AppConfig.features && AppConfig.batAlarms }
    fun master(c: Context) = available(c) && p(c).getBoolean("master", false)
    fun full(c: Context) = p(c).getBoolean("full", AppConfig.batFull)
    fun low(c: Context) = p(c).getBoolean("low", AppConfig.batLow)
    fun over(c: Context) = p(c).getBoolean("over", AppConfig.batOver)
    fun plug(c: Context) = p(c).getBoolean("plug", AppConfig.batPlug)
    fun lowPct(c: Context) = p(c).getInt("lowPct", AppConfig.batLowPct)
    fun overMin(c: Context) = p(c).getInt("overMin", AppConfig.batOverMin)

    /** 0 = alarm tone, 1 = spoken voice, 2 = tone then voice */
    fun soundMode(c: Context) = p(c).getInt("soundMode", AppConfig.batSound)

    val defaults = mapOf(
        "full" to "Your phone is full. Please unplug your charger.",
        "low" to "Your phone battery is low. Please plug in your charger.",
        "over" to "Your phone is still on the charger. Please unplug it now.",
        "hot" to "The temperature is high. Please unplug your phone and keep it in a cool place.",
        "plug" to "Your phone is now charging.",
        "unplug" to "Your phone is unplugged. It is not charging.",
    )
    fun msg(c: Context, key: String): String =
        p(c).getString("msg_$key", null)?.takeIf { it.isNotBlank() }
            // the portal fills in the English wording when the admin did not change it: that should not hide a chosen language
            ?: AppConfig.batMsgs[key]?.takeIf { it != defaults[key] }
            ?: Lang.spoken(Lang.code(c), key)
            ?: defaults.getValue(key)
    fun setMsg(c: Context, key: String, v: String) { p(c).edit().putString("msg_$key", v).apply() }

    fun set(c: Context, key: String, v: Boolean) { p(c).edit().putBoolean(key, v).apply() }
    fun set(c: Context, key: String, v: Int) { p(c).edit().putInt(key, v).apply() }

    /** Starts the watcher when the alarms are on, stops it when they are off. */
    fun sync(c: Context) {
        val on = master(c) && (full(c) || low(c) || over(c) || plug(c))
        val i = Intent(c, BatteryAlertService::class.java)
        if (on) {
            try { ContextCompat.startForegroundService(c, i) } catch (_: Exception) {}
        } else c.stopService(i)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) { BatteryAlerts.sync(c); AntiTheft.resume(c) }
    }
}

/**
 * Watches the battery and rings when it is full, low, left plugged in too long, or hot while charging.
 * Android only lets an app listen for battery changes all the time from a foreground service,
 * which is why a small "Battery alerts are on" notification stays in the bar.
 */
class BatteryAlertService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var ringtone: Ringtone? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var speakRunnable: Runnable? = null
    private var autoStop: Runnable? = null
    private var fullFired = false
    private var lowFired = false
    private var hotFired = false
    private var overRunnable: Runnable? = null
    private var lastPlugged = false
    private var firstReading = true
    private var plugJob: Runnable? = null
    private var lastPct = -1

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { check(i) }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createChannels()
        val n = NotificationCompat.Builder(this, CH_MONITOR)
            .setSmallIcon(android.R.drawable.ic_lock_idle_charging)
            .setContentTitle("Battery alerts are on")
            .setContentText("Tap to change them")
            .setOngoing(true).setSilent(true)
            .setContentIntent(openApp())
            .build()
        ServiceCompat.startForeground(this, ID_MONITOR, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        tts = TextToSpeech(this) { status ->
            val t = tts
            if (status == TextToSpeech.SUCCESS && t != null) {
                var r = t.setLanguage(Lang.locale(Lang.code(this)))
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) r = t.setLanguage(Locale.getDefault())
                if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) r = t.setLanguage(Locale.ENGLISH)
                t.setAudioAttributes(
                    AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                )
                ttsReady = r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED
            }
        }
        // The last battery broadcast is "sticky", so this also gives us the reading right now
        val sticky = registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        sticky?.let { check(it) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_RING -> stopRing()
            ACTION_TEST -> intent.getStringExtra("key")?.let {
                if (it == "plug" || it == "unplug") playOnce(it) else if (it in BatteryAlerts.defaults) playAlert(it)
            }
        }
        return START_STICKY
    }

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        stopRing()
        try { tts?.shutdown() } catch (_: Exception) {}
        overRunnable?.let { handler.removeCallbacks(it) }
        plugJob?.let { handler.removeCallbacks(it) }
        super.onDestroy()
    }

    private fun check(i: Intent) {
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (level < 0 || scale <= 0) return
        val pct = level * 100 / scale
        val plugged = i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) != 0
        val tempC = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f
        try { BatteryHistory.record(this, pct, plugged, tempC) } catch (_: Exception) {}

        // Plug / unplug: clear what no longer applies and silence old alarms
        if (plugged != lastPlugged) {
            stopRing()
            if (!plugged) {
                fullFired = false; hotFired = false
                cancelOver()
                cancel(ID_FULL); cancel(ID_OVER); cancel(ID_HOT)
            } else {
                lowFired = false
                cancel(ID_LOW)
            }
            lastPlugged = plugged
            if (!firstReading) announcePlug(plugged)
        }
        firstReading = false
        if (pct <= 95) fullFired = false

        // 1. Full
        if (BatteryAlerts.full(this) && plugged && pct >= 100 && !fullFired) {
            fullFired = true
            alert(ID_FULL, "full", "🔋 Battery is full", "Unplug your charger to protect the battery.")
        }

        // 2. Left plugged in at 100%
        if (BatteryAlerts.over(this)) {
            if (plugged && pct >= 100) scheduleOver() else cancelOver()
        }

        // 3. Low
        val lowAt = BatteryAlerts.lowPct(this)
        if (pct > lowAt + 2) lowFired = false
        if (BatteryAlerts.low(this) && !plugged && pct <= lowAt && !lowFired) {
            lowFired = true
            alert(ID_LOW, "low", "🪫 Battery low: $pct%", "Plug in your charger soon.")
        }

        // 4. Hot while charging, the real danger people mean by "overcharging"
        if (tempC < 40f) hotFired = false
        if (BatteryAlerts.over(this) && plugged && tempC >= 45f && !hotFired) {
            hotFired = true
            alert(ID_HOT, "hot", "🌡️ Battery is very hot (${"%.0f".format(tempC)}°C)", "Unplug the charger and let the phone cool down.")
        }
        lastPct = pct
    }

    private fun scheduleOver() {
        if (overRunnable != null) return
        val delay = BatteryAlerts.overMin(this) * 60_000L
        val r = object : Runnable {
            override fun run() {
                if (lastPlugged && lastPct >= 100 && BatteryAlerts.over(this@BatteryAlertService)) {
                    alert(ID_OVER, "over", "⚠️ Still plugged in at 100%", "Your phone has been on the charger for a long time after it filled up. Please unplug it.")
                    handler.postDelayed(this, delay) // remind again until unplugged
                } else overRunnable = null
            }
        }
        overRunnable = r
        handler.postDelayed(r, delay)
    }

    private fun cancelOver() {
        overRunnable?.let { handler.removeCallbacks(it) }
        overRunnable = null
    }

    private fun alert(id: Int, key: String, title: String, text: String) {
        val stop = PendingIntent.getService(
            this, 1, Intent(this, BatteryAlertService::class.java).setAction(ACTION_STOP_RING),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
        )
        val n = NotificationCompat.Builder(this, CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_lock_idle_low_battery)
            .setContentTitle(title).setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(openApp())
            .setDeleteIntent(stop)
            .addAction(0, "Stop sound", stop)
            .build()
        try { getSystemService(NotificationManager::class.java).notify(id, n) } catch (_: Exception) {}
        playAlert(key)
    }

    private fun cancel(id: Int) = getSystemService(NotificationManager::class.java).cancel(id)

    /** Says "charging" or "unplugged". Waits a moment so a loose cable that flickers does not spam. */
    private fun announcePlug(plugged: Boolean) {
        plugJob?.let { handler.removeCallbacks(it) }
        plugJob = null
        if (!BatteryAlerts.plug(this)) return
        val job = Runnable {
            plugJob = null
            if (lastPlugged == plugged) {
                playOnce(if (plugged) "plug" else "unplug")
                val n = NotificationCompat.Builder(this, CH_PLUG)
                    .setSmallIcon(if (plugged) android.R.drawable.ic_lock_idle_charging else android.R.drawable.ic_lock_idle_low_battery)
                    .setContentTitle(if (plugged) "🔌 Charger connected" else "🔋 Charger unplugged")
                    .setContentText(if (plugged) "Charging, battery at $lastPct%" else "Not charging, battery at $lastPct%")
                    .setAutoCancel(true).setTimeoutAfter(10_000L)
                    .setContentIntent(openApp())
                    .build()
                try { getSystemService(NotificationManager::class.java).notify(ID_PLUG, n) } catch (_: Exception) {}
            }
        }
        plugJob = job
        handler.postDelayed(job, 1_500L)
    }

    /** A short, one-time sound or sentence (not the repeating alarm). Follows the phone's silent mode for the beep. */
    private fun playOnce(key: String) {
        stopRing()
        val mode = BatteryAlerts.soundMode(this)
        val text = BatteryAlerts.msg(this, key)
        when {
            mode == 0 || !ttsReady -> playBeep()
            mode == 1 -> speakOnce(text)
            else -> {
                playBeep()
                handler.postDelayed({ stopTone(); speakOnce(text) }, 1_200L)
            }
        }
        val stopper = Runnable { stopRing() }
        autoStop = stopper
        handler.postDelayed(stopper, 10_000L)
    }

    private fun playBeep() {
        try {
            val r = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)) ?: return
            r.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            r.play()
            ringtone = r
        } catch (_: Exception) {}
    }

    private fun speakOnce(text: String) {
        try { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "plug") } catch (_: Exception) {}
    }

    /** Plays the sound the person chose: alarm tone, spoken message, or tone first and then the message. */
    private fun playAlert(key: String) {
        stopRing()
        val mode = BatteryAlerts.soundMode(this)
        val text = BatteryAlerts.msg(this, key)
        when {
            mode == 0 || !ttsReady -> playTone()
            mode == 1 -> startSpeech(text)
            else -> {
                playTone()
                handler.postDelayed({ stopTone(); startSpeech(text) }, 3_000L)
            }
        }
        val stopper = Runnable { stopRing() }
        autoStop = stopper
        handler.postDelayed(stopper, 45_000L)
    }

    private fun playTone() {
        try {
            val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            val r = RingtoneManager.getRingtone(this, uri) ?: return
            r.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            if (Build.VERSION.SDK_INT >= 28) r.isLooping = true
            r.play()
            ringtone = r
        } catch (_: Exception) {}
    }

    private fun stopTone() {
        try { ringtone?.stop() } catch (_: Exception) {}
        ringtone = null
    }

    /** Says the message, then says it again every few seconds until stopped. */
    private fun startSpeech(text: String) {
        val t = tts ?: return playTone()
        val r = object : Runnable {
            override fun run() {
                val params = Bundle().apply { putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, android.media.AudioManager.STREAM_ALARM) }
                t.speak(text, TextToSpeech.QUEUE_FLUSH, params, "battery")
                handler.postDelayed(this, 8_000L)
            }
        }
        speakRunnable = r
        r.run()
    }

    private fun stopRing() {
        stopTone()
        speakRunnable?.let { handler.removeCallbacks(it) }
        speakRunnable = null
        autoStop?.let { handler.removeCallbacks(it) }
        autoStop = null
        try { tts?.stop() } catch (_: Exception) {}
    }

    private fun openApp(): PendingIntent = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

    private fun createChannels() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_MONITOR, "Battery alerts running", NotificationManager.IMPORTANCE_MIN)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_PLUG, "Charger connected or unplugged", NotificationManager.IMPORTANCE_LOW)
        )
        // Sound comes from the looping alarm tone above, so the channel itself stays quiet
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "Battery alarms", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null)
                enableVibration(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
        )
    }

    companion object {
        const val ACTION_STOP_RING = "com.storagemanager.STOP_RING"
        const val ACTION_TEST = "com.storagemanager.TEST_ALERT"
        private const val CH_MONITOR = "battery_monitor"
        private const val CH_ALERT = "battery_alarm"
        private const val CH_PLUG = "battery_plug"
        private const val ID_MONITOR = 4001
        private const val ID_FULL = 4002
        private const val ID_LOW = 4003
        private const val ID_OVER = 4004
        private const val ID_HOT = 4005
        private const val ID_PLUG = 4006
    }
}

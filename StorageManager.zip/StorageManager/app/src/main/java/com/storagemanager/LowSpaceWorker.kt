package com.storagemanager

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.text.format.Formatter
import androidx.core.app.NotificationCompat
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.concurrent.TimeUnit

/** Once a day, offline: if free space is under 10%, show a "phone almost full" notification. */
class LowSpaceWorker(private val ctx: Context, params: WorkerParameters) : Worker(ctx, params) {

    override fun doWork(): Result {
        val (total, free) = StorageScanner.space()
        if (total <= 0 || free.toFloat() / total >= LOW_FRACTION) return Result.success()
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return Result.success()

        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Low storage", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(ctx, CHANNEL)
            .setSmallIcon(android.R.drawable.stat_sys_warning)
            .setContentTitle("Your phone is almost full")
            .setContentText("Only ${Formatter.formatShortFileSize(ctx, free)} left. Tap to free up space.")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(1, n)
        return Result.success()
    }

    companion object {
        private const val CHANNEL = "low_space"
        private const val LOW_FRACTION = 0.10f

        fun schedule(ctx: Context) {
            val req = PeriodicWorkRequestBuilder<LowSpaceWorker>(1, TimeUnit.DAYS).build()
            WorkManager.getInstance(ctx)
                .enqueueUniquePeriodicWork("low_space_check", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}

package com.storagemanager

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings

/** level: 2 = high, 1 = medium, 0 = low */
data class AppRisk(val name: String, val pkg: String, val level: Int, val reasons: List<String>)

/**
 * A simple offline check. It is NOT antivirus: it cannot detect malware.
 * It points out apps that deserve a second look.
 */
object SafetyCheck {
    private val stores = setOf(
        "com.android.vending", "com.sec.android.app.samsungapps", "com.huawei.appmarket",
        "com.xiaomi.market", "com.heytap.market", "com.oppo.market", "com.vivo.appstore",
        "com.amazon.venezia",
    )
    private val sms = setOf(
        "android.permission.READ_SMS", "android.permission.SEND_SMS", "android.permission.RECEIVE_SMS",
    )

    fun run(ctx: Context): List<AppRisk> {
        val pm = ctx.packageManager
        val a11y = Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
        val admins = dpm.activeAdmins?.map { it.packageName }.orEmpty().toSet()

        val packages: List<PackageInfo> = if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(PackageManager.GET_PERMISSIONS.toLong()))
        } else {
            @Suppress("DEPRECATION") pm.getInstalledPackages(PackageManager.GET_PERMISSIONS)
        }

        val out = ArrayList<AppRisk>()
        for (p in packages) {
            val ai = p.applicationInfo ?: continue
            if ((ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0) continue
            if (p.packageName == ctx.packageName) continue

            val requested = p.requestedPermissions ?: emptyArray()
            val flags = p.requestedPermissionsFlags
            val granted = HashSet<String>()
            requested.forEachIndexed { i, perm ->
                if (flags != null && (flags[i] and PackageInfo.REQUESTED_PERMISSION_GRANTED) != 0) granted += perm
            }

            val installer = try {
                if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(p.packageName).installingPackageName
                else @Suppress("DEPRECATION") pm.getInstallerPackageName(p.packageName)
            } catch (e: Exception) { null }
            val sideloaded = installer == null || installer !in stores

            val reasons = ArrayList<String>()
            var level = -1
            fun add(l: Int, text: String) { reasons += text; if (l > level) level = l }

            if (p.packageName in admins) add(2, "Is a device administrator (can lock the phone or resist uninstall)")
            if (a11y.contains("${p.packageName}/")) add(2, "Accessibility service is on (can read the screen and tap for you)")
            if (sideloaded) {
                if (granted.any { it in sms }) add(2, "Can read or send SMS")
                if ("android.permission.READ_CALL_LOG" in granted) add(1, "Can read your call history")
                if ("android.permission.RECORD_AUDIO" in granted) add(1, "Can use the microphone")
                if ("android.permission.SYSTEM_ALERT_WINDOW" in requested) add(1, "Can draw over other apps")
                if ("android.permission.REQUEST_INSTALL_PACKAGES" in requested) add(1, "Can install other apps")
                if ("android.permission.MANAGE_EXTERNAL_STORAGE" in requested) add(1, "Can access all your files")
                add(0, "Not installed from a major app store")
            }
            if (level >= 0) {
                out += AppRisk(pm.getApplicationLabel(ai).toString(), p.packageName, level, reasons.sortedBy { it.length })
            }
        }
        return out.sortedWith(compareByDescending<AppRisk> { it.level }.thenBy { it.name.lowercase() })
    }
}

package com.storagemanager

import android.app.AppOpsManager
import android.app.usage.StorageStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.os.storage.StorageManager

data class AppItem(val name: String, val pkg: String, val bytes: Long, val cache: Long)

object AppUsage {
    fun hasAccess(ctx: Context): Boolean {
        val ops = ctx.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), ctx.packageName)
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /** Offline: asks Android for each installed app's size (app + data + cache). */
    fun load(ctx: Context): List<AppItem> {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O || !hasAccess(ctx)) return emptyList()
        val pm = ctx.packageManager
        val ssm = ctx.getSystemService(Context.STORAGE_STATS_SERVICE) as StorageStatsManager
        val me = Process.myUserHandle()
        return pm.getInstalledApplications(PackageManager.GET_META_DATA).mapNotNull { info ->
            try {
                val s = ssm.queryStatsForPackage(StorageManager.UUID_DEFAULT, info.packageName, me)
                AppItem(
                    name = pm.getApplicationLabel(info).toString(),
                    pkg = info.packageName,
                    bytes = s.appBytes + s.dataBytes + s.cacheBytes,
                    cache = s.cacheBytes,
                )
            } catch (e: Exception) { null }
        }.sortedByDescending { it.bytes }
    }
}

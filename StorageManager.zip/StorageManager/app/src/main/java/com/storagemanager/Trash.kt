package com.storagemanager

import android.content.Context
import android.media.MediaScannerConnection
import android.os.Environment
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class TrashItem(val id: String, val name: String, val original: String, val size: Long, val deleted: Long, val kept: Long = 0L) {
    /** Space that really comes back when this item leaves the bin (less when a smaller copy replaced it). */
    val reclaim: Long get() = (size - kept).coerceAtLeast(0L)

    /** Where the file sits while it is in the bin. The extension is kept so the preview knows what it is. */
    val stored: String get() = Trash.dir().path + "/" + id + (if ('.' in name) "." + name.substringAfterLast('.') else "")
}

/** A recycle bin: deleted files wait here for a few days so a mistake can be undone. All on the phone, nothing uploaded. */
object Trash {
    fun dir(): File = File(Environment.getExternalStorageDirectory(), ".StorageManagerTrash")
    private fun index(): File = File(dir(), "index.json")

    @Synchronized
    fun list(): List<TrashItem> {
        val f = index()
        if (!f.exists()) return emptyList()
        return try {
            val a = JSONArray(f.readText())
            (0 until a.length()).map { i ->
                val o = a.getJSONObject(i)
                TrashItem(o.getString("id"), o.getString("name"), o.getString("original"), o.getLong("size"), o.getLong("deleted"), o.optLong("kept", 0L))
            }.filter { File(it.stored).exists() }.sortedByDescending { it.deleted }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun save(items: List<TrashItem>) {
        dir().mkdirs()
        val a = JSONArray()
        items.forEach {
            a.put(JSONObject().put("id", it.id).put("name", it.name).put("original", it.original).put("size", it.size).put("deleted", it.deleted).put("kept", it.kept))
        }
        index().writeText(a.toString())
        File(dir(), ".nomedia").let { if (!it.exists()) it.createNewFile() }
    }

    private fun move(from: File, to: File): Boolean {
        if (from.renameTo(to)) return true
        return try { // another storage volume: copy, then remove the original
            from.copyTo(to, overwrite = true)
            from.delete()
        } catch (e: Exception) {
            to.delete()
            false
        }
    }

    /** Moves files into the bin. Returns the original paths that were moved. */
    @Synchronized
    fun moveIn(ctx: Context, paths: List<String>, kept: Map<String, Long> = emptyMap()): Set<String> {
        dir().mkdirs()
        val items = list().toMutableList()
        val moved = HashSet<String>()
        val now = System.currentTimeMillis()
        for (p in paths) {
            val f = File(p)
            if (!f.isFile) continue
            val it = TrashItem(java.util.UUID.randomUUID().toString().replace("-", "").take(12), f.name, p, f.length(), now, kept[p] ?: 0L)
            if (move(f, File(it.stored))) { items += it; moved += p }
        }
        save(items)
        if (moved.isNotEmpty()) MediaScannerConnection.scanFile(ctx, moved.toTypedArray(), null, null)
        return moved
    }

    /** Puts a file back where it was (never overwrites something that is there now). Returns the final path or null. */
    @Synchronized
    fun restore(ctx: Context, id: String): String? {
        val items = list().toMutableList()
        val it = items.firstOrNull { x -> x.id == id } ?: return null
        var target = File(it.original)
        target.parentFile?.mkdirs()
        if (target.exists()) {
            val base = target.nameWithoutExtension
            val ext = if (target.extension.isEmpty()) "" else "." + target.extension
            target = File(target.parentFile, "$base (restored)$ext")
        }
        if (!move(File(it.stored), target)) return null
        items.remove(it)
        save(items)
        MediaScannerConnection.scanFile(ctx, arrayOf(target.path), null, null)
        return target.path
    }

    /** Removes files for good. Returns how many bytes were freed. */
    @Synchronized
    fun removeForever(ids: Set<String>): Long {
        val items = list().toMutableList()
        var freed = 0L
        for (it in items.filter { x -> x.id in ids }) {
            if (File(it.stored).delete()) { freed += it.reclaim; items.remove(it) }
        }
        save(items)
        return freed
    }

    /** The newest bin entry that came from this path. */
    fun idFor(original: String): String? = list().firstOrNull { it.original == original }?.id

    fun empty(): Long = removeForever(list().map { it.id }.toSet())

    /** Removes files that have been in the bin longer than [days]. Returns bytes freed. */
    fun purgeOld(days: Int): Long {
        val limit = System.currentTimeMillis() - days * 24L * 3600 * 1000
        return removeForever(list().filter { it.deleted < limit }.map { it.id }.toSet())
    }
}

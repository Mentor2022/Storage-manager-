@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.storagemanager

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume

/** How hard to shrink. Photos keep their look; videos drop resolution and bitrate. */
enum class Level(
    val label: String, val emoji: String, val hint: String,
    val photoQuality: Int, val photoMaxSide: Int, val photoFactor: Float,
    val videoShortSide: Int, val videoBps: Int,
) {
    LIGHT("Light", "🌤️", "Looks the same. Smaller saving.", 85, 4000, 0.60f, 1080, 5_000_000),
    BALANCED("Balanced", "⚖️", "Best mix for phone screens.", 75, 2560, 0.40f, 720, 2_500_000),
    STRONG("Strong", "🔥", "Biggest saving. Slightly softer.", 65, 1600, 0.22f, 480, 1_200_000),
}

/** A photo or video that can be made smaller. */
data class MediaCand(
    val path: String, val size: Long, val modified: Long, val isVideo: Boolean,
    val width: Int = 0, val height: Int = 0, val durationMs: Long = 0, val bitrate: Long = 0,
) {
    val name: String get() = path.substringAfterLast('/')
    val folder: String get() = path.substringBeforeLast('/').substringAfter("/storage/emulated/0")

    /** Estimated size after compressing. Never bigger than the original. */
    fun estimate(l: Level): Long {
        if (isVideo) {
            if (durationMs <= 0 || bitrate <= 0) return size
            val target = minOf(l.videoBps.toLong(), (bitrate * 0.8).toLong())
            val est = durationMs / 1000.0 * (target + 128_000) / 8.0
            return minOf(size, est.toLong())
        }
        val maxDim = maxOf(width, height).coerceAtLeast(1)
        val scale = if (maxDim > l.photoMaxSide) l.photoMaxSide.toFloat() / maxDim else 1f
        return minOf(size, (size * l.photoFactor * scale * scale).toLong())
    }

    fun saving(l: Level): Long = size - estimate(l)

    /** Worth doing only when at least 15% comes back. */
    fun worth(l: Level): Boolean = saving(l) >= size * 0.15
}

object Compressor {
    const val PHOTO_MIN = 1_500_000L
    const val VIDEO_MIN = 15L * 1024 * 1024
    private val photoExt = setOf("jpg", "jpeg")
    private val videoExt = setOf("mp4", "mkv", "3gp", "mov", "webm", "m4v", "avi")

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("compressed", 0)
    private fun mark(f: File) = f.path + "|" + f.length()

    /** Remember a file we already shrank so it is not shrunk again and again. */
    fun remember(ctx: Context, f: File) {
        val set = prefs(ctx).getStringSet("done", emptySet())!!.toMutableSet()
        set += mark(f)
        prefs(ctx).edit().putStringSet("done", set.toList().takeLast(3000).toSet()).apply()
    }

    private fun isDone(ctx: Context, f: File) = mark(f) in prefs(ctx).getStringSet("done", emptySet())!!

    /** Looks through the phone for big photos and videos. Biggest first. */
    fun find(ctx: Context, onProgress: (String) -> Unit): List<MediaCand> {
        val root = StorageScanner.root()
        val raw = ArrayList<MediaCand>()
        var n = 0
        root.walkTopDown()
            .onEnter {
                it.path != "${root.path}/Android/data" && it.path != "${root.path}/Android/obb" &&
                    it.path != Trash.dir().path && !it.name.startsWith(".")
            }
            .onFail { _, _ -> }
            .filter { it.isFile }
            .forEach { f ->
                if (++n % 400 == 0) onProgress("Looked at $n files…")
                val ext = f.extension.lowercase()
                val size = f.length()
                if (ext in photoExt && size >= PHOTO_MIN) raw += MediaCand(f.path, size, f.lastModified(), false)
                else if (ext in videoExt && size >= VIDEO_MIN) raw += MediaCand(f.path, size, f.lastModified(), true)
            }
        val top = raw.filter { !isDone(ctx, File(it.path)) }.sortedByDescending { it.size }.take(300)
        onProgress("Reading file details…")
        return top.map { c -> if (c.isVideo) withVideoInfo(c) else withPhotoInfo(c) }
            .filter { it.estimate(Level.BALANCED) < it.size }
    }

    private fun withPhotoInfo(c: MediaCand): MediaCand = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(c.path, o)
        c.copy(width = o.outWidth, height = o.outHeight)
    } catch (e: Throwable) { c }

    private fun withVideoInfo(c: MediaCand): MediaCand {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(c.path)
            fun key(k: Int) = r.extractMetadata(k)?.toLongOrNull() ?: 0L
            val rot = key(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION).toInt()
            val w = key(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH).toInt()
            val h = key(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT).toInt()
            val dur = key(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val br = key(MediaMetadataRetriever.METADATA_KEY_BITRATE).takeIf { it > 0 } ?: if (dur > 0) c.size * 8000L / dur else 0L
            // width and height as the person sees them (after rotation)
            if (rot == 90 || rot == 270) c.copy(width = h, height = w, durationMs = dur, bitrate = br)
            else c.copy(width = w, height = h, durationMs = dur, bitrate = br)
        } catch (e: Throwable) { c } finally { try { r.release() } catch (e: Throwable) { } }
    }

    // ───────────── photos ─────────────

    /** Writes a smaller copy of the photo to [out]. Date, camera and place details are kept. Returns false on any problem. */
    fun photo(c: MediaCand, l: Level, out: File): Boolean {
        var bm: Bitmap? = null
        var scaled: Bitmap? = null
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(c.path, o)
            if (o.outWidth <= 0 || o.outHeight <= 0) return false
            val maxDim = maxOf(o.outWidth, o.outHeight)
            val targetDim = minOf(maxDim, l.photoMaxSide)
            var sample = 1
            while (maxDim / (sample * 2) >= targetDim) sample *= 2
            bm = BitmapFactory.decodeFile(c.path, BitmapFactory.Options().apply { inSampleSize = sample }) ?: return false
            val exif = ExifInterface(c.path)
            val orientation = exif.getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
            val m = Matrix()
            when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> m.postRotate(90f)
                ExifInterface.ORIENTATION_ROTATE_180 -> m.postRotate(180f)
                ExifInterface.ORIENTATION_ROTATE_270 -> m.postRotate(270f)
                ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> m.postScale(-1f, 1f)
                ExifInterface.ORIENTATION_FLIP_VERTICAL -> m.postScale(1f, -1f)
            }
            val decodedMax = maxOf(bm.width, bm.height)
            if (decodedMax > targetDim) { val s = targetDim.toFloat() / decodedMax; m.postScale(s, s) }
            scaled = if (m.isIdentity) bm else Bitmap.createBitmap(bm, 0, 0, bm.width, bm.height, m, true)
            out.parentFile?.mkdirs()
            out.outputStream().buffered().use { scaled.compress(Bitmap.CompressFormat.JPEG, l.photoQuality, it) }
            // carry the useful tags over; the picture is already turned the right way up
            val to = ExifInterface(out.path)
            for (tag in KEEP_TAGS) exif.getAttribute(tag)?.let { to.setAttribute(tag, it) }
            to.setAttribute(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL.toString())
            to.saveAttributes()
            return out.length() > 0
        } catch (t: Throwable) {
            out.delete()
            return false
        } finally {
            if (scaled != null && scaled !== bm) scaled.recycle()
            bm?.recycle()
        }
    }

    private val KEEP_TAGS = listOf(
        ExifInterface.TAG_DATETIME, ExifInterface.TAG_DATETIME_ORIGINAL, ExifInterface.TAG_DATETIME_DIGITIZED,
        ExifInterface.TAG_MAKE, ExifInterface.TAG_MODEL,
        ExifInterface.TAG_GPS_LATITUDE, ExifInterface.TAG_GPS_LATITUDE_REF,
        ExifInterface.TAG_GPS_LONGITUDE, ExifInterface.TAG_GPS_LONGITUDE_REF,
        ExifInterface.TAG_GPS_ALTITUDE, ExifInterface.TAG_GPS_ALTITUDE_REF,
    )

    // ───────────── videos ─────────────

    /**
     * Re-encodes the video to [out] as H.264 MP4 with a lower resolution and bitrate. Runs on the main thread (a rule of the
     * library) but the encoding itself happens in the phone's video hardware. [onPercent] gets 0..100.
     */
    suspend fun video(ctx: Context, c: MediaCand, l: Level, out: File, onPercent: (Int) -> Unit): Boolean =
        withContext(Dispatchers.Main) {
            out.delete()
            out.parentFile?.mkdirs()
            suspendCancellableCoroutine<Boolean> { cont ->
                val handler = Handler(Looper.getMainLooper())
                var finished = false
                var transformer: Transformer? = null

                val bps = minOf(l.videoBps.toLong(), (c.bitrate * 0.8).toLong().coerceAtLeast(300_000L)).toInt()
                val short = minOf(c.width, c.height)
                val effects = ArrayList<androidx.media3.common.Effect>()
                if (short > l.videoShortSide && c.width > 0 && c.height > 0) {
                    val scale = l.videoShortSide.toFloat() / short
                    var h = (c.height * scale).toInt()
                    if (h % 2 == 1) h++
                    effects += Presentation.createForHeight(h)
                }
                val item = EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(File(c.path))))
                    .setEffects(Effects(emptyList(), effects))
                    .build()

                fun done(ok: Boolean) {
                    if (finished) return
                    finished = true
                    handler.removeCallbacksAndMessages(null)
                    if (!ok) out.delete()
                    if (cont.isActive) cont.resume(ok)
                }

                val listener = object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) { done(true) }
                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) { done(false) }
                }

                try {
                    val encoder = DefaultEncoderFactory.Builder(ctx)
                        .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bps).build())
                        .setEnableFallback(true)
                        .build()
                    val t = Transformer.Builder(ctx)
                        .setVideoMimeType(MimeTypes.VIDEO_H264)
                        .setEncoderFactory(encoder)
                        .addListener(listener)
                        .build()
                    transformer = t
                    t.start(item, out.path)
                    val holder = ProgressHolder()
                    val poll = object : Runnable {
                        override fun run() {
                            if (finished) return
                            if (t.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) onPercent(holder.progress)
                            handler.postDelayed(this, 400)
                        }
                    }
                    handler.post(poll)
                } catch (e: Throwable) {
                    done(false)
                }
                cont.invokeOnCancellation {
                    handler.post { try { transformer?.cancel() } catch (e: Throwable) { } ; finished = true; out.delete() }
                }
            }
        }

    // ───────────── put the result in place, original into the Bin ─────────────

    sealed class Outcome {
        class Saved(val before: Long, val after: Long, val binId: String?) : Outcome()
        object Skipped : Outcome()
        object Failed : Outcome()
    }

    /**
     * Swaps the original for the smaller file. The original goes to the Bin first; if anything fails the original is put back.
     * [tmp] is the compressed file. A video that was not .mp4 becomes .mp4.
     */
    fun replace(ctx: Context, c: MediaCand, tmp: File): Outcome {
        val orig = File(c.path)
        if (!orig.isFile || !tmp.isFile || tmp.length() <= 0L) { tmp.delete(); return Outcome.Failed }
        // not worth it: keep the original untouched
        if (tmp.length() >= orig.length() * 0.9) { tmp.delete(); return Outcome.Skipped }

        var target = if (c.isVideo && !orig.extension.equals("mp4", true)) File(orig.parentFile, orig.nameWithoutExtension + ".mp4") else orig
        if (target.path != orig.path && target.exists()) target = File(orig.parentFile, orig.nameWithoutExtension + " (compressed).mp4")

        val before = orig.length()
        val modified = orig.lastModified()
        val moved = Trash.moveIn(ctx, listOf(orig.path), mapOf(orig.path to tmp.length()))
        if (orig.path !in moved) { tmp.delete(); return Outcome.Failed }
        val binId = Trash.idFor(orig.path)
        return try {
            tmp.copyTo(target, overwrite = true)
            if (target.length() != tmp.length()) throw java.io.IOException("short copy")
            target.setLastModified(modified)
            tmp.delete()
            remember(ctx, target)
            MediaScannerConnection.scanFile(ctx, arrayOf(target.path), null, null)
            Outcome.Saved(before, target.length(), binId)
        } catch (e: Throwable) {
            target.delete()
            tmp.delete()
            if (binId != null) Trash.restore(ctx, binId)
            Outcome.Failed
        }
    }

    fun tempFile(ctx: Context, c: MediaCand): File =
        File(ctx.cacheDir, "cmp_" + java.util.UUID.randomUUID().toString().take(8) + (if (c.isVideo) ".mp4" else ".jpg"))
}

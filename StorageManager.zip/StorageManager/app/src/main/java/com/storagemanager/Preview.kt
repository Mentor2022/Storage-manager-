package com.storagemanager

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.text.format.Formatter
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.text.DateFormat
import java.util.Date

private val IMAGE_EXT = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif")
private val VIDEO_EXT = setOf("mp4", "3gp", "mkv", "webm", "mov", "avi", "m4v")

private fun ext(path: String) = path.substringAfterLast('.', "").lowercase()

/** A small picture of the file (photo or video frame), or null when there is nothing to show. */
private fun loadThumb(path: String): Bitmap? {
    val e = ext(path)
    try {
        if (e in IMAGE_EXT) {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, o)
            if (o.outWidth <= 0 || o.outHeight <= 0) return null
            var sample = 1
            while (o.outWidth / sample > 1200 || o.outHeight / sample > 1200) sample *= 2
            return BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
        }
        if (e in VIDEO_EXT) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(path)
                return r.getFrameAtTime(1_000_000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: r.frameAtTime
            } finally {
                r.release()
            }
        }
    } catch (t: Throwable) {
        return null
    }
    return null
}

private fun kind(path: String): String = when (ext(path)) {
    in IMAGE_EXT -> "Photo"
    in VIDEO_EXT -> "Video"
    "mp3", "m4a", "aac", "wav", "ogg", "opus", "amr" -> "Audio"
    "pdf" -> "PDF document"
    "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt" -> "Document"
    "apk" -> "App installer"
    "zip", "rar", "7z" -> "Archive"
    "" -> "File"
    else -> ext(path).uppercase() + " file"
}

private fun openFile(ctx: Context, path: String) {
    try {
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", File(path))
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext(path)) ?: "*/*"
        val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (t: Throwable) {
        Toast.makeText(ctx, "No app on this phone can open this file.", Toast.LENGTH_LONG).show()
    }
}

/** Shows what a file is before it is deleted, so the person can decide to keep it or not. */
@Composable
fun FilePreview(f: FileItem, marked: Boolean, onToggleMark: (() -> Unit)?, onClose: () -> Unit, title: String = f.name) {
    val ctx = LocalContext.current
    val isApk = ext(f.path) == "apk"
    val exists = File(f.path).exists()
    val thumb by produceState<Bitmap?>(null, f.path) { value = withContext(Dispatchers.IO) { loadThumb(f.path) } }
    val canPicture = ext(f.path) in IMAGE_EXT || ext(f.path) in VIDEO_EXT

    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                if (canPicture) {
                    Box(Modifier.fillMaxWidth().heightIn(min = 120.dp, max = 320.dp), Alignment.Center) {
                        val b = thumb
                        if (b != null) {
                            Image(b.asImageBitmap(), contentDescription = null, Modifier.fillMaxWidth().heightIn(max = 320.dp), contentScale = ContentScale.Fit)
                        } else {
                            CircularProgressIndicator()
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }
                if (!exists) Text("This file is already gone.", color = MaterialTheme.colorScheme.error)
                Text(kind(f.path), style = MaterialTheme.typography.titleSmall)
                Text("Size: " + Formatter.formatShortFileSize(ctx, f.size), style = MaterialTheme.typography.bodyMedium)
                Text("Changed: " + DateFormat.getDateTimeInstance().format(Date(f.modified)), style = MaterialTheme.typography.bodyMedium)
                Spacer(Modifier.height(6.dp))
                Text("Where: " + f.path.substringBeforeLast('/'), style = MaterialTheme.typography.bodySmall)
                if (isApk) {
                    Spacer(Modifier.height(6.dp))
                    Text("This is an app installer. It is safe to delete after the app is installed.", style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            if (onToggleMark != null) TextButton(onClick = { onToggleMark(); onClose() }) { Text(if (marked) "Keep it" else "Mark to delete") }
        },
        dismissButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(0.dp)) {
                if (exists && !isApk) TextButton(onClick = { openFile(ctx, f.path) }) { Text("Open") }
                TextButton(onClick = onClose) { Text("Close") }
            }
        },
    )
}

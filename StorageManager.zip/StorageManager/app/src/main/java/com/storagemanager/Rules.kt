package com.storagemanager

import android.content.Context
import org.json.JSONObject
import java.io.File

/** One kind of automatic cleaning the person can switch on. */
data class RuleDef(
    val id: String, val emoji: String, val title: String, val text: String,
    /** Ages (in days) the person can pick. Empty = the rule has no age. */
    val ages: List<Int>, val defaultAge: Int, val defaultEvery: Int,
)

/** The saved choice for a rule. */
data class RuleSetting(val on: Boolean, val age: Int, val every: Int, val last: Long)

/**
 * Auto-clean rules. They run in the background (see AutoCleanWorker) and ALWAYS move files to the Bin first,
 * so a mistake can be undone for a few days. Nothing is deleted for good by a rule.
 */
object Rules {
    val all = listOf(
        RuleDef("statuses", "👻", "Empty WhatsApp Statuses", "Moves saved status photos and videos to the Bin.", emptyList(), 0, 30),
        RuleDef("screenshots", "📱", "Old screenshots", "Screenshots older than the age you pick.", listOf(30, 60, 90, 180), 90, 7),
        RuleDef("downloads", "⬇️", "Old downloads", "Files in the Download folder older than the age you pick.", listOf(60, 90, 180), 90, 7),
        RuleDef("junk", "🧹", "Junk files", "Temp files, logs, old installers and empty files older than a week.", emptyList(), 0, 7),
        RuleDef("wa_received", "💬", "Old WhatsApp media you received", "Received photos, videos and voice notes older than the age you pick. Files you sent are never touched.", listOf(90, 180, 365), 180, 30),
    )

    fun def(id: String): RuleDef? = all.firstOrNull { it.id == id }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences("rules", 0)

    private fun json(ctx: Context): JSONObject =
        try { JSONObject(prefs(ctx).getString("all", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    fun get(ctx: Context, id: String): RuleSetting {
        val d = def(id)!!
        val o = json(ctx).optJSONObject(id)
        return RuleSetting(
            on = o?.optBoolean("on", false) ?: false,
            age = o?.optInt("age", d.defaultAge) ?: d.defaultAge,
            every = (o?.optInt("every", d.defaultEvery) ?: d.defaultEvery).let { if (it == 7 || it == 30) it else d.defaultEvery },
            last = o?.optLong("last", 0L) ?: 0L,
        )
    }

    @Synchronized
    fun put(ctx: Context, id: String, s: RuleSetting) {
        val j = json(ctx)
        j.put(id, JSONObject().put("on", s.on).put("age", s.age).put("every", s.every).put("last", s.last))
        prefs(ctx).edit().putString("all", j.toString()).apply()
    }

    fun anyOn(ctx: Context) = all.any { get(ctx, it.id).on }

    fun isDue(s: RuleSetting, now: Long = System.currentTimeMillis()): Boolean =
        s.on && now - s.last >= s.every * 86_400_000L - 3_600_000L

    /** What each rule would move to the Bin right now. [ids] limits which rules are looked at. */
    fun collect(ctx: Context, ids: Collection<String>): Map<String, List<FileItem>> {
        val root = StorageScanner.root()
        val rootPath = root.path
        val now = System.currentTimeMillis()
        val day = 86_400_000L
        val set = ids.associateWith { get(ctx, it) }
        val out = ids.associateWith { ArrayList<FileItem>() }
        if (ids.isEmpty()) return out
        root.walkTopDown()
            .onEnter { it.path != "$rootPath/Android/data" && it.path != "$rootPath/Android/obb" && it.path != Trash.dir().path }
            .onFail { _, _ -> }
            .filter { it.isFile }
            .forEach { f ->
                val p = f.path
                val ext = f.extension.lowercase()
                if (ext == "nomedia") return@forEach
                val age = now - f.lastModified()
                val wa = p.contains("/WhatsApp/Media/") || p.contains("/WhatsApp Business/Media/")
                val status = p.contains("/.Statuses/")
                fun add(id: String) { out[id]?.add(FileItem(p, f.length(), f.lastModified())) }
                if ("statuses" in out && wa && status) add("statuses")
                if ("screenshots" in out && p.contains("/Screenshots/", ignoreCase = true) && age >= set.getValue("screenshots").age * day) add("screenshots")
                if ("downloads" in out && p.startsWith("$rootPath/Download/") && age >= set.getValue("downloads").age * day) add("downloads")
                if ("junk" in out && age >= 7 * day && StorageScanner.isJunk(f, ext)) add("junk")
                if ("wa_received" in out && wa && !status && !p.contains("/Sent/") && age >= set.getValue("wa_received").age * day) add("wa_received")
            }
        // a file matched by two rules is only moved once
        val seen = HashSet<String>()
        return out.mapValues { (_, list) -> list.filter { seen.add(it.path) } }
    }

    class RunResult(val files: Int, val bytes: Long, val byRule: Map<String, Int>)

    /**
     * Runs rules and moves what they find to the Bin. With [force] every switched-on rule runs now; otherwise only the ones that are due.
     */
    fun run(ctx: Context, force: Boolean): RunResult {
        val now = System.currentTimeMillis()
        val ids = all.map { it.id }.filter { val s = get(ctx, it); if (force) s.on else isDue(s, now) }
        if (ids.isEmpty()) return RunResult(0, 0, emptyMap())
        val found = collect(ctx, ids)
        var files = 0
        var bytes = 0L
        val byRule = LinkedHashMap<String, Int>()
        for ((id, list) in found) {
            if (list.isNotEmpty()) {
                val moved = Trash.moveIn(ctx, list.map { it.path })
                val sizes = list.associate { it.path to it.size }
                val b = moved.sumOf { sizes[it] ?: 0L }
                files += moved.size; bytes += b
                if (moved.isNotEmpty()) byRule[id] = moved.size
            }
            put(ctx, id, get(ctx, id).copy(last = now))
        }
        if (bytes > 0) History.record(ctx, bytes)
        return RunResult(files, bytes, byRule)
    }
}

package com.storagemanager

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// A bright, friendly palette: each kind of file has its own color
val Indigo = Color(0xFF5B5BF0)
val Violet = Color(0xFF8E54E9)
val Teal = Color(0xFF00BFA5)
val Pink = Color(0xFFFF4F81)
val Orange = Color(0xFFFF9248)
val Sun = Color(0xFFFFC53D)
val Sky = Color(0xFF29B6F6)
val Green = Color(0xFF2ECC71)
val Red = Color(0xFFEF4444)

val HeroGradient = Brush.linearGradient(listOf(Color(0xFF4F46E5), Color(0xFF8E54E9), Color(0xFFEC4899)))
val CleanGradient = Brush.linearGradient(listOf(Color(0xFF00BFA5), Color(0xFF29B6F6)))

fun categoryColor(c: Category): Color = when (c) {
    Category.IMAGES -> Pink
    Category.VIDEO -> Violet
    Category.AUDIO -> Orange
    Category.DOCS -> Sky
    Category.APK -> Green
    Category.OTHER -> Color(0xFF94A3B8)
}

fun categoryEmoji(c: Category): String = when (c) {
    Category.IMAGES -> "🖼️"
    Category.VIDEO -> "🎬"
    Category.AUDIO -> "🎵"
    Category.DOCS -> "📄"
    Category.APK -> "📦"
    Category.OTHER -> "📁"
}

/** Color and emoji for a file, chosen by its extension. */
fun fileColor(name: String): Color = when (name.substringAfterLast('.', "").lowercase()) {
    "jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif" -> Pink
    "mp4", "3gp", "mkv", "webm", "mov", "avi", "m4v" -> Violet
    "mp3", "m4a", "aac", "wav", "ogg", "opus", "amr" -> Orange
    "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt" -> Sky
    "apk" -> Green
    "zip", "rar", "7z" -> Sun
    else -> Color(0xFF94A3B8)
}

fun fileEmoji(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
    "jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif" -> "🖼️"
    "mp4", "3gp", "mkv", "webm", "mov", "avi", "m4v" -> "🎬"
    "mp3", "m4a", "aac", "wav", "ogg", "opus", "amr" -> "🎵"
    "pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt" -> "📄"
    "apk" -> "📦"
    "zip", "rar", "7z" -> "🗜️"
    else -> "📁"
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    val dark = isSystemInDarkTheme()
    val scheme = if (dark) darkColorScheme(
        primary = Color(0xFF9B9BFF), onPrimary = Color(0xFF14143A),
        primaryContainer = Color(0xFF2B2B6B), onPrimaryContainer = Color(0xFFE3E3FF),
        secondary = Color(0xFF4DE0CB), tertiary = Color(0xFFFF8FB1),
        background = Color(0xFF0F1020), surface = Color(0xFF15162B),
        surfaceVariant = Color(0xFF1F2140), onSurfaceVariant = Color(0xFFB9BCDD),
        errorContainer = Color(0xFF5A1F2B), onErrorContainer = Color(0xFFFFD9DF),
    ) else lightColorScheme(
        primary = Indigo, onPrimary = Color.White,
        primaryContainer = Color(0xFFE6E6FF), onPrimaryContainer = Color(0xFF1B1B6B),
        secondary = Teal, tertiary = Pink,
        background = Color(0xFFF5F6FF), surface = Color(0xFFF5F6FF),
        surfaceVariant = Color(0xFFFFFFFF), onSurfaceVariant = Color(0xFF55587A),
        errorContainer = Color(0xFFFFE3E8), onErrorContainer = Color(0xFF7A1226),
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

/** A rounded white/dark card with soft shadow. */
@Composable
fun SoftCard(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Card(
        modifier,
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    ) { content() }
}

/** A card with a colored gradient background and white text. */
@Composable
fun GradientCard(brush: Brush, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier.clip(RoundedCornerShape(24.dp)).background(brush)) { content() }
}

/** Round colored badge with an emoji inside. */
@Composable
fun EmojiBadge(emoji: String, color: Color, size: Int = 40) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(color.copy(alpha = 0.18f)),
        Alignment.Center,
    ) { Text(emoji, fontSize = (size * 0.45f).sp) }
}

/** The big storage ring: the colored arc grows from 0 to the used share. */
@Composable
fun StorageRing(fraction: Float, size: Int = 150) {
    val shown by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(1100, easing = FastOutSlowInEasing), label = "ring")
    Box(Modifier.size(size.dp), Alignment.Center) {
        Canvas(Modifier.size(size.dp)) {
            val stroke = 16.dp.toPx()
            val inset = stroke / 2
            val arcSize = Size(this.size.width - stroke, this.size.height - stroke)
            drawArc(Color.White.copy(alpha = 0.25f), 0f, 360f, false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
            drawArc(Color.White, -90f, 360f * shown, false, Offset(inset, inset), arcSize, style = Stroke(stroke, cap = StrokeCap.Round))
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("${(shown * 100).toInt()}%", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
            Text("used", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
        }
    }
}

/** Slim colored progress bar that animates in. */
@Composable
fun ColorBar(fraction: Float, color: Color, modifier: Modifier = Modifier) {
    val shown by animateFloatAsState(fraction.coerceIn(0f, 1f), tween(800, easing = FastOutSlowInEasing), label = "bar")
    Box(modifier.height(10.dp).clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.15f))) {
        Box(Modifier.fillMaxWidth(shown).height(10.dp).clip(RoundedCornerShape(50)).background(Brush.horizontalGradient(listOf(color, color.copy(alpha = 0.65f)))))
    }
}

/** Small rounded label, like "High" or "3 days left". */
@Composable
fun Pill(text: String, color: Color) {
    Box(Modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.16f)).padding(horizontal = 10.dp, vertical = 4.dp)) {
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}

/** Section title with a colored bar before it. */
@Composable
fun SectionTitle(text: String, color: Color = Indigo) {
    Row(Modifier.padding(top = 8.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(5.dp).height(18.dp).clip(RoundedCornerShape(50)).background(color))
        Spacer(Modifier.width(8.dp))
        Text(text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
    }
}

/** A pill-shaped tab. */
@Composable
fun TabChip(label: String, emoji: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    val bg = if (selected) Brush.linearGradient(listOf(color, color.copy(alpha = 0.7f)))
    else Brush.linearGradient(listOf(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.surfaceVariant))
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(bg).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 9.dp),
        Arrangement.spacedBy(6.dp), Alignment.CenterVertically,
    ) {
        Text(emoji, fontSize = 14.sp)
        Text(label, color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface, fontSize = 13.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
    }
}

package com.storagemanager

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** The colours used all over the app. */
object Pal {
    val teal = Color(0xFF00897B)
    val blue = Color(0xFF2979FF)
    val purple = Color(0xFF7C4DFF)
    val pink = Color(0xFFEC407A)
    val orange = Color(0xFFFF7043)
    val amber = Color(0xFFFFA000)
    val green = Color(0xFF43A047)
    val red = Color(0xFFE53935)
    val grey = Color(0xFF78909C)
}

private val LightColors = lightColorScheme(
    primary = Color(0xFF00897B), onPrimary = Color.White,
    primaryContainer = Color(0xFFB9F2EA), onPrimaryContainer = Color(0xFF00201C),
    secondary = Color(0xFFFF7043), onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFDBCF), onSecondaryContainer = Color(0xFF3A0B00),
    tertiary = Color(0xFF7C4DFF), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFE8DEFF), onTertiaryContainer = Color(0xFF21005D),
    background = Color(0xFFF3FAF9), surface = Color(0xFFF3FAF9),
    surfaceVariant = Color(0xFFDCE9E6),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4DD0C1), onPrimary = Color(0xFF00201C),
    primaryContainer = Color(0xFF00504A), onPrimaryContainer = Color(0xFFB9F2EA),
    secondary = Color(0xFFFFAB91), onSecondary = Color(0xFF3A0B00),
    secondaryContainer = Color(0xFF7A2E14), onSecondaryContainer = Color(0xFFFFDBCF),
    tertiary = Color(0xFFCFBCFF), onTertiary = Color(0xFF381E72),
    tertiaryContainer = Color(0xFF4F3B8F), onTertiaryContainer = Color(0xFFE8DEFF),
    background = Color(0xFF0E1514), surface = Color(0xFF0E1514),
    surfaceVariant = Color(0xFF2A3634),
)

@Composable
fun StorageTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors, content = content)
}

fun catColor(c: Category): Color = when (c) {
    Category.IMAGES -> Pal.pink
    Category.VIDEO -> Pal.purple
    Category.AUDIO -> Pal.blue
    Category.DOCS -> Pal.amber
    Category.APK -> Pal.green
    Category.OTHER -> Pal.grey
}

fun catEmoji(c: Category): String = when (c) {
    Category.IMAGES -> "🖼️"
    Category.VIDEO -> "🎬"
    Category.AUDIO -> "🎵"
    Category.DOCS -> "📄"
    Category.APK -> "📦"
    Category.OTHER -> "📁"
}

fun tabEmoji(key: String): String = when (key) {
    "overview" -> "🏠"
    "large" -> "📦"
    "duplicates" -> "👯"
    "similar" -> "🖼️"
    "junk" -> "🧹"
    "whatsapp" -> "💬"
    "downloads" -> "⬇️"
    "screenshots" -> "📸"
    "safety" -> "🛡️"
    "email" -> "✉️"
    "apps" -> "📱"
    "bin" -> "🗑️"
    else -> "•"
}

/** A small emoji and colour that tell at a glance what kind of file this is. */
fun fileLook(name: String): Pair<String, Color> = when (name.substringAfterLast('.', "").lowercase()) {
    "jpg", "jpeg", "png", "webp", "gif", "bmp", "heic" -> "🖼️" to Pal.pink
    "mp4", "mkv", "3gp", "avi", "mov", "webm" -> "🎬" to Pal.purple
    "mp3", "m4a", "aac", "wav", "ogg", "opus", "amr", "flac" -> "🎵" to Pal.blue
    "pdf" -> "📕" to Pal.red
    "doc", "docx", "txt", "epub" -> "📄" to Pal.blue
    "xls", "xlsx", "csv" -> "📊" to Pal.green
    "ppt", "pptx" -> "📙" to Pal.orange
    "apk" -> "📦" to Pal.green
    "zip", "rar", "7z" -> "🗜️" to Pal.amber
    else -> "📁" to Pal.grey
}

/** A ring that fills up to [fraction]. */
@Composable
fun StorageRing(fraction: Float, diameter: Dp, track: Color, color: Color, stroke: Dp = 14.dp, content: @Composable () -> Unit) {
    Box(Modifier.size(diameter), Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = stroke.toPx()
            val box = Size(this.size.width - w, this.size.height - w)
            val corner = Offset(w / 2, w / 2)
            drawArc(track, 0f, 360f, false, corner, box, style = Stroke(w, cap = StrokeCap.Round))
            drawArc(color, -90f, 360f * fraction.coerceIn(0.01f, 1f), false, corner, box, style = Stroke(w, cap = StrokeCap.Round))
        }
        content()
    }
}

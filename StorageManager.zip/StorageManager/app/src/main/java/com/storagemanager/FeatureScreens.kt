package com.storagemanager

import android.content.Context
import android.text.format.Formatter
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date

private fun fmtSize(ctx: Context, b: Long): String = Formatter.formatShortFileSize(ctx, b)

/** Short size for chart labels, like 2.1G or 340M. */
private fun compact(b: Long): String = when {
    b >= 1L shl 30 -> String.format("%.1fG", b / (1024.0 * 1024 * 1024))
    b >= 1L shl 20 -> String.format("%.0fM", b / (1024.0 * 1024))
    b >= 1L shl 10 -> String.format("%.0fK", b / 1024.0)
    else -> if (b > 0) "<1K" else ""
}

/** A hint line tinted with a color. */
@Composable
private fun HintCard(text: String, color: Color) {
    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).clip(RoundedCornerShape(16.dp)).background(color.copy(alpha = 0.12f)).padding(14.dp)) {
        Text(text, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun Choice(label: String, selected: Boolean, color: Color, onClick: () -> Unit) {
    Box(
        Modifier.clip(RoundedCornerShape(50))
            .background(if (selected) color else color.copy(alpha = 0.12f))
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp),
    ) { Text(label, color = if (selected) Color.White else color, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
}

// ───────────────────────── Compressor ─────────────────────────

@Composable
fun CompressScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val view = LocalView.current
    val run = vm.cRun
    // the screen stays on while compressing so the work is not interrupted
    DisposableEffect(run != null) {
        view.keepScreenOn = run != null
        onDispose { view.keepScreenOn = false }
    }
    LaunchedEffect(Unit) { vm.loadCands() }
    var confirm by remember { mutableStateOf(false) }
    var freeAsk by remember { mutableStateOf(false) }
    var look by remember { mutableStateOf<MediaCand?>(null) }

    if (run != null) {
        Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            GradientCard(CleanGradient, Modifier.fillMaxWidth()) {
                Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🗜️", fontSize = 44.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Compressing ${run.index + 1} of ${run.total}", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                    Text(run.name, color = Color.White.copy(alpha = 0.9f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(16.dp))
                    LinearProgressIndicator(
                        progress = { ((run.index + run.percent / 100f) / run.total).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(50)),
                        color = Color.White, trackColor = Color.White.copy(alpha = 0.3f),
                    )
                    Spacer(Modifier.height(10.dp))
                    Text("Keep this screen open. Originals go to the Bin first.", color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp, textAlign = TextAlign.Center)
                }
            }
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = { vm.cancelCompress() }, shape = RoundedCornerShape(50)) { Text("Stop") }
        }
        return
    }

    val list = vm.cands
    if (list == null || vm.candsBusy) {
        Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            CircularProgressIndicator(color = Teal)
            Spacer(Modifier.height(14.dp))
            Text(vm.candsProgress.ifEmpty { "Looking for big photos and videos…" }, fontWeight = FontWeight.SemiBold)
            Text("This can take a minute. It all happens on your phone.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        return
    }

    val lv = vm.level
    val shrink = list.filter { it.worth(lv) }
    val chosen = shrink.filter { it.path in vm.cSelected }
    val basis = if (chosen.isNotEmpty()) chosen else shrink
    val before = basis.sumOf { it.size }
    val after = basis.sumOf { it.estimate(lv) }
    val bin = AppConfig.binDays
    val done = vm.cDone

    Column(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 16.dp)) {
            item {
                GradientCard(Brush.linearGradient(listOf(Color(0xFF00ACC1), Color(0xFF5B5BF0))), Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(18.dp)) {
                        Text("🗜️ Photo & video compressor", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Makes big photos and videos smaller without deleting them. The original waits in the Bin for $bin days, so you can always go back.",
                            color = Color.White.copy(alpha = 0.95f), fontSize = 14.sp,
                        )
                    }
                }
                if (done != null) {
                    Spacer(Modifier.height(12.dp))
                    SoftCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("✅ Done: ${done.count} compressed", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                            Text(
                                "Saves ${fmtSize(ctx, done.saved)} once the originals leave the Bin." +
                                    (if (done.skipped > 0) " ${done.skipped} skipped (no real saving)." else "") +
                                    (if (done.failed > 0) " ${done.failed} could not be compressed and were left alone." else ""),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                            if (done.binIds.isNotEmpty()) {
                                Spacer(Modifier.height(10.dp))
                                Button(onClick = { freeAsk = true }, shape = RoundedCornerShape(50), colors = ButtonDefaults.buttonColors(containerColor = Teal)) {
                                    Text("Free ${fmtSize(ctx, done.saved)} now", fontWeight = FontWeight.Bold)
                                }
                                Text("Removes the originals from the Bin for good.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                SectionTitle("How small?", Teal)
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), Arrangement.spacedBy(8.dp)) {
                    Level.values().forEach { l ->
                        val on = l == lv
                        Column(
                            Modifier.weight(1f).clip(RoundedCornerShape(18.dp))
                                .background(if (on) Brush.linearGradient(listOf(Teal, Sky)) else Brush.linearGradient(listOf(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.surfaceVariant)))
                                .clickable {
                                    vm.level = l
                                    vm.cSelected.removeAll { p -> list.firstOrNull { it.path == p }?.worth(l) != true }
                                }.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            Text(l.emoji, fontSize = 22.sp)
                            Text(l.label, color = if (on) Color.White else MaterialTheme.colorScheme.onSurface, fontWeight = FontWeight.Bold)
                            Text(l.hint, color = if (on) Color.White.copy(alpha = 0.9f) else MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 11.sp, textAlign = TextAlign.Center)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                if (shrink.isEmpty()) {
                    Box(Modifier.fillMaxWidth().padding(32.dp), Alignment.Center) { Text("🎈 Nothing big enough to shrink at this level.", textAlign = TextAlign.Center) }
                } else {
                    SoftCard(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                                Text(if (chosen.isNotEmpty()) "${chosen.size} selected" else "All ${shrink.size} items", fontWeight = FontWeight.Bold)
                                TextButton(onClick = {
                                    if (chosen.size == shrink.size) vm.cSelected.clear()
                                    else { vm.cSelected.clear(); vm.cSelected.addAll(shrink.map { it.path }) }
                                }) { Text(if (chosen.size == shrink.size) "Clear" else "Select all", color = Teal, fontWeight = FontWeight.Bold) }
                            }
                            Spacer(Modifier.height(6.dp))
                            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                                Text("Before", style = MaterialTheme.typography.bodySmall)
                                Text(fmtSize(ctx, before), fontWeight = FontWeight.Bold, color = Red)
                            }
                            ColorBar(1f, Red, Modifier.fillMaxWidth())
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                                Text("After (about)", style = MaterialTheme.typography.bodySmall)
                                Text("~" + fmtSize(ctx, after), fontWeight = FontWeight.Bold, color = Green)
                            }
                            ColorBar(if (before > 0) after.toFloat() / before else 0f, Green, Modifier.fillMaxWidth())
                            Spacer(Modifier.height(10.dp))
                            Text("You could save about ${fmtSize(ctx, before - after)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = Teal)
                            Text("Sizes are estimates. The real size is shown when it is done.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                }
            }
            items(shrink, key = { it.path }) { c ->
                val checked = c.path in vm.cSelected
                val col = if (c.isVideo) Violet else Pink
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(18.dp))
                        .background(if (checked) col.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { look = c }.padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    EmojiBadge(if (c.isVideo) "🎬" else "🖼️", col, 42)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(c.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            fmtSize(ctx, c.size) + " → ~" + fmtSize(ctx, c.estimate(lv)),
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Pill("-" + fmtSize(ctx, c.saving(lv)), Green)
                    Checkbox(checked = checked, onCheckedChange = { if (checked) vm.cSelected.remove(c.path) else vm.cSelected.add(c.path) }, colors = CheckboxDefaults.colors(checkedColor = col))
                }
            }
        }
        if (chosen.isNotEmpty()) {
            Surface(tonalElevation = 8.dp, shadowElevation = 12.dp, shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)) {
                Row(Modifier.fillMaxWidth().padding(12.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                    TextButton(onClick = { vm.cSelected.clear() }) { Text("Clear") }
                    Box(Modifier.weight(1f))
                    Button(onClick = { confirm = true }, shape = RoundedCornerShape(50), colors = ButtonDefaults.buttonColors(containerColor = Teal), modifier = Modifier.height(48.dp)) {
                        Text("🗜️ Compress ${chosen.size} · save ~${fmtSize(ctx, before - after)}", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    look?.let { c -> FilePreview(FileItem(c.path, c.size, c.modified), marked = false, onToggleMark = null, onClose = { look = null }) }

    if (confirm) {
        AlertDialog(
            shape = RoundedCornerShape(24.dp),
            onDismissRequest = { confirm = false },
            title = { Text("Compress ${chosen.size} files?", fontWeight = FontWeight.Bold) },
            text = {
                Text(
                    "${lv.label}: ${fmtSize(ctx, before)} becomes about ${fmtSize(ctx, after)}.\n\n" +
                        "Each original moves to the Bin first and stays there for $bin days. " +
                        "Space comes back when the originals leave the Bin: after $bin days, or right away with the \"Free now\" button when it is done.\n\n" +
                        "Videos are saved as MP4 and keep their date. Keep this screen open while it works."
                )
            },
            confirmButton = { Button(onClick = { confirm = false; vm.compress() }) { Text("Compress") } },
            dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
        )
    }
    if (freeAsk) {
        AlertDialog(
            shape = RoundedCornerShape(24.dp),
            onDismissRequest = { freeAsk = false },
            title = { Text("Remove the originals now?", fontWeight = FontWeight.Bold) },
            text = { Text("The originals will be removed for good and ${fmtSize(ctx, done?.saved ?: 0L)} comes back. You will no longer be able to undo these compressions.") },
            confirmButton = { Button(onClick = { freeAsk = false; vm.freeOriginalsNow() }, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Remove originals") } },
            dismissButton = { TextButton(onClick = { freeAsk = false }) { Text("Keep them in the Bin") } },
        )
    }
}

// ───────────────────────── Weekly report ─────────────────────────

@Composable
fun ReportScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    var notify by remember { mutableStateOf(History.notifyOn(ctx)) }
    // read again whenever something was cleaned
    @Suppress("UNUSED_VARIABLE") val trigger = vm.result
    val weeks = History.weeks(ctx, 8)
    val thisWeek = weeks.last().second
    val streak = History.streak(ctx)
    val best = History.bestWeek(ctx)
    val total = History.allTime(ctx)
    val max = weeks.maxOf { it.second }.coerceAtLeast(1L)

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp)) {
        item {
            GradientCard(Brush.linearGradient(listOf(Color(0xFFFF9248), Color(0xFFFF4F81), Color(0xFF8E54E9))), Modifier.fillMaxWidth()) {
                Column(Modifier.padding(20.dp)) {
                    Text("This week", color = Color.White.copy(alpha = 0.9f), fontSize = 14.sp)
                    Text(if (thisWeek > 0) fmtSize(ctx, thisWeek) else "0 B", color = Color.White, fontSize = 40.sp, fontWeight = FontWeight.ExtraBold)
                    Text(
                        if (thisWeek > 0) "cleaned since Monday 🎉" else "Clean something to start the week.",
                        color = Color.White.copy(alpha = 0.95f), fontSize = 14.sp,
                    )
                    Spacer(Modifier.height(14.dp))
                    Row(Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.22f)).padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("🔥", fontSize = 20.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            if (streak > 0) "$streak-week streak" else "No streak yet",
                            color = Color.White, fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
            Spacer(Modifier.height(16.dp))
            SectionTitle("Last 8 weeks", Orange)
            Spacer(Modifier.height(6.dp))
            SoftCard(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp)) {
                    Row(Modifier.fillMaxWidth().height(150.dp), Arrangement.spacedBy(6.dp), Alignment.Bottom) {
                        weeks.forEachIndexed { i, (w, v) ->
                            val last = i == weeks.lastIndex
                            Column(Modifier.weight(1f).fillMaxHeight(), Arrangement.Bottom, Alignment.CenterHorizontally) {
                                Text(compact(v), fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                                Spacer(Modifier.height(3.dp))
                                val h = if (v > 0) (100f * v / max).coerceAtLeast(6f) else 3f
                                Box(
                                    Modifier.fillMaxWidth().height(h.dp).clip(RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp))
                                        .background(
                                            if (v <= 0) Brush.linearGradient(listOf(Color(0xFF94A3B8).copy(alpha = 0.35f), Color(0xFF94A3B8).copy(alpha = 0.35f)))
                                            else if (last) Brush.verticalGradient(listOf(Pink, Orange))
                                            else Brush.verticalGradient(listOf(Violet, Indigo))
                                        )
                                )
                            }
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(6.dp)) {
                        weeks.forEachIndexed { i, (w, _) ->
                            Text(
                                if (i == weeks.lastIndex) "Now" else History.weekLabel(w),
                                Modifier.weight(1f), fontSize = 10.sp, textAlign = TextAlign.Center,
                                color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1,
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(10.dp)) {
                SoftCard(Modifier.weight(1f)) {
                    Column(Modifier.padding(14.dp)) {
                        EmojiBadge("🏆", Sun, 38)
                        Spacer(Modifier.height(8.dp))
                        Text(fmtSize(ctx, best), fontWeight = FontWeight.ExtraBold, color = Orange)
                        Text("Best week", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                SoftCard(Modifier.weight(1f)) {
                    Column(Modifier.padding(14.dp)) {
                        EmojiBadge("📈", Teal, 38)
                        Spacer(Modifier.height(8.dp))
                        Text(fmtSize(ctx, total), fontWeight = FontWeight.ExtraBold, color = Teal)
                        Text("Last 12 months", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                SoftCard(Modifier.weight(1f)) {
                    Column(Modifier.padding(14.dp)) {
                        EmojiBadge("🎉", Pink, 38)
                        Spacer(Modifier.height(8.dp))
                        Text(fmtSize(ctx, vm.freedTotal), fontWeight = FontWeight.ExtraBold, color = Pink)
                        Text("Freed so far", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
            SoftCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Sunday report", fontWeight = FontWeight.Bold)
                        Text("A notification every Sunday evening: \"You freed 2.1 GB this week\".", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Switch(checked = notify, onCheckedChange = { notify = it; History.setNotify(ctx, it) })
                }
            }
            HintCard("Counts files moved to the Bin, files deleted, and space saved by compressing. Restoring a file takes it back off the count. Weeks start on Monday. A week without cleaning ends the streak, an empty current week does not.", Orange)
        }
    }
}

// ───────────────────────── Auto-clean rules ─────────────────────────

@Composable
fun RulesScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val tick = vm.rulesTick
    LaunchedEffect(tick, vm.rulesFound == null, vm.rulesBusy) {
        if (vm.rulesFound == null && !vm.rulesBusy) vm.checkRules()
    }
    var ask by remember { mutableStateOf(false) }
    val found = vm.rulesFound
    val states = remember(tick) { Rules.all.associate { it.id to Rules.get(ctx, it.id) } }
    val onIds = Rules.all.map { it.id }.filter { states[it]?.on == true }
    val runFiles = onIds.sumOf { found?.get(it)?.size ?: 0 }
    val runBytes = onIds.sumOf { id -> found?.get(id)?.sumOf { it.size } ?: 0L }
    val bin = AppConfig.binDays

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Box(Modifier.padding(horizontal = 16.dp).clip(RoundedCornerShape(24.dp)).background(Brush.linearGradient(listOf(Color(0xFF5B5BF0), Color(0xFF8E54E9))))) {
                Column(Modifier.padding(18.dp)) {
                    Text("🤖 Auto-clean", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Switch on a rule and it cleans for you in the background, with a notification. " +
                            "Rules never delete for good: files go to the Bin first and stay there for $bin days.",
                        color = Color.White.copy(alpha = 0.95f), fontSize = 14.sp,
                    )
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        items(Rules.all, key = { it.id }) { d ->
            val s = states.getValue(d.id)
            val list = found?.get(d.id)
            SoftCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        EmojiBadge(d.emoji, Indigo, 44)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(d.title, fontWeight = FontWeight.Bold)
                            Text(d.text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Switch(checked = s.on, onCheckedChange = { on ->
                            // a rule that was just switched on first runs after its period, not at once
                            vm.setRule(d.id, s.copy(on = on, last = if (on) System.currentTimeMillis() else s.last))
                        })
                    }
                    if (d.ages.isNotEmpty()) {
                        Spacer(Modifier.height(10.dp))
                        Text("Older than", style = MaterialTheme.typography.bodySmall)
                        Row(Modifier.padding(top = 4.dp), Arrangement.spacedBy(6.dp)) {
                            d.ages.forEach { a -> Choice("$a days", s.age == a, Indigo) { vm.setRule(d.id, s.copy(age = a)) } }
                        }
                    }
                    Spacer(Modifier.height(10.dp))
                    Text("Runs", style = MaterialTheme.typography.bodySmall)
                    Row(Modifier.padding(top = 4.dp), Arrangement.spacedBy(6.dp)) {
                        Choice("Every week", s.every == 7, Violet) { vm.setRule(d.id, s.copy(every = 7)) }
                        Choice("Every month", s.every == 30, Violet) { vm.setRule(d.id, s.copy(every = 30)) }
                    }
                    Spacer(Modifier.height(10.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (list == null) Pill("Checking…", Color(0xFF64748B))
                        else if (list.isEmpty()) Pill("Nothing to clean now", Green)
                        else Pill("${list.size} files · ${fmtSize(ctx, list.sumOf { it.size })} ready", Orange)
                        Spacer(Modifier.width(8.dp))
                        if (s.on) {
                            val next = s.last + s.every * 86_400_000L
                            Text(
                                if (s.last == 0L) "Runs soon" else "Next run " + DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(maxOf(next, System.currentTimeMillis()))),
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }
        item {
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { ask = true },
                enabled = onIds.isNotEmpty() && found != null && runFiles > 0 && !vm.rulesBusy,
                shape = RoundedCornerShape(50),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(52.dp),
            ) {
                Text(
                    if (onIds.isEmpty()) "Switch a rule on first"
                    else if (runFiles == 0) "Nothing to clean right now"
                    else "▶ Run now · $runFiles files · ${fmtSize(ctx, runBytes)}",
                    fontWeight = FontWeight.Bold,
                )
            }
            HintCard("Rules run about once a day in the background, only when All files access is allowed, and only for rules whose time has come. Undo anything in the Bin tab.", Indigo)
        }
    }

    if (ask) {
        AlertDialog(
            shape = RoundedCornerShape(24.dp),
            onDismissRequest = { ask = false },
            title = { Text("Run switched-on rules now?", fontWeight = FontWeight.Bold) },
            text = { Text("$runFiles files (${fmtSize(ctx, runBytes)}) move to the Bin. You can undo for $bin days.") },
            confirmButton = { Button(onClick = { ask = false; vm.runRulesNow() }) { Text("Move to Bin") } },
            dismissButton = { TextButton(onClick = { ask = false }) { Text("Cancel") } },
        )
    }
}

package com.storagemanager

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import android.text.format.Formatter
import androidx.core.app.NotificationCompat
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.Worker
import androidx.work.WorkerParameters
import java.util.Calendar
import java.util.concurrent.TimeUnit

/** Shows a notification. Does nothing when the person has not allowed notifications. */
object Notify {
    fun post(ctx: Context, channel: String, channelName: String, id: Int, title: String, text: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(channel, channelName, NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(
            ctx, id, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val n = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        nm.notify(id, n)
    }
}

/** Once a day, in the background: runs the auto-clean rules that are due. Everything goes to the Bin first. */
class AutoCleanWorker(private val ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        AppConfig.load(ctx)
        if ("rules" !in AppConfig.features || !Rules.anyOn(ctx)) return Result.success()
        // needs the all-files permission; without it there is nothing safe to do
        val allowed = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else ctx.checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED &&
            ctx.checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        if (!allowed) return Result.success()
        return try {
            // keep the Bin tidy even when the app is not opened
            Stats.addFreed(ctx, Trash.purgeOld(AppConfig.binDays))
            val r = Rules.run(ctx, force = false)
            if (r.files > 0) {
                val names = r.byRule.keys.mapNotNull { Rules.def(it)?.title?.lowercase() }.joinToString(", ")
                Notify.post(
                    ctx, "autoclean", "Auto-clean", 3,
                    "Auto-clean moved ${r.files} files to the Bin",
                    "${Formatter.formatShortFileSize(ctx, r.bytes)} cleaned ($names). Open the Bin tab within ${AppConfig.binDays} days to undo.",
                )
            }
            Result.success()
        } catch (e: Exception) {
            Result.retry()
        }
    }

    companion object {
        fun schedule(ctx: Context) {
            val wm = WorkManager.getInstance(ctx)
            if ("rules" !in AppConfig.features) { wm.cancelUniqueWork("auto_clean"); return }
            val req = PeriodicWorkRequestBuilder<AutoCleanWorker>(1, TimeUnit.DAYS)
                .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(true).build())
                .build()
            wm.enqueueUniquePeriodicWork("auto_clean", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}

/** Every Sunday evening: "You freed 2.1 GB this week". */
class WeeklyReportWorker(private val ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): Result {
        AppConfig.load(ctx)
        if ("report" !in AppConfig.features || !History.notifyOn(ctx)) return Result.success()
        val week = History.thisWeek(ctx)
        val streak = History.streak(ctx)
        val fire = if (streak >= 2) " 🔥 $streak-week streak." else ""
        if (week > 0) {
            Notify.post(ctx, "report", "Weekly report", 2, "You freed ${Formatter.formatShortFileSize(ctx, week)} this week 🎉", "Nice work.$fire Tap to see your history.")
        } else {
            Notify.post(ctx, "report", "Weekly report", 2, "Nothing cleaned this week", "A quick scan takes a minute and can bring space back.${if (streak > 0) " Clean something to keep your $streak-week streak." else ""}")
        }
        return Result.success()
    }

    companion object {
        /** Time until the next Sunday 18:00 on the phone's clock. */
        private fun delayToSunday(): Long {
            val c = Calendar.getInstance()
            c.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY)
            c.set(Calendar.HOUR_OF_DAY, 18); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
            if (c.timeInMillis <= System.currentTimeMillis() + 60_000L) c.add(Calendar.DAY_OF_YEAR, 7)
            return c.timeInMillis - System.currentTimeMillis()
        }

        fun schedule(ctx: Context) {
            val wm = WorkManager.getInstance(ctx)
            if ("report" !in AppConfig.features) { wm.cancelUniqueWork("weekly_report"); return }
            val req = PeriodicWorkRequestBuilder<WeeklyReportWorker>(7, TimeUnit.DAYS)
                .setInitialDelay(delayToSunday(), TimeUnit.MILLISECONDS)
                .build()
            wm.enqueueUniquePeriodicWork("weekly_report", ExistingPeriodicWorkPolicy.KEEP, req)
        }
    }
}

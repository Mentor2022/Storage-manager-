package com.storagemanager

import android.content.Context
import org.json.JSONObject
import java.util.Calendar
import java.util.TimeZone

/** The running "freed so far" total. Shared by the app and the background workers. */
object Stats {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("stats", 0)

    fun freed(ctx: Context): Long = prefs(ctx).getLong("freed", 0L)

    @Synchronized
    fun addFreed(ctx: Context, bytes: Long): Long {
        if (bytes <= 0) return freed(ctx)
        val total = freed(ctx) + bytes
        prefs(ctx).edit().putLong("freed", total).apply()
        return total
    }
}

/**
 * How much was cleaned on each day (moved to the Bin, deleted or saved by compressing).
 * Used for the weekly report, the chart and the week streak. Everything stays on the phone.
 */
object History {
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("history", 0)

    /** Days since 1 Jan 1970 in the phone's own time zone. */
    fun today(): Long {
        val now = System.currentTimeMillis()
        return (now + TimeZone.getDefault().getOffset(now)) / 86_400_000L
    }

    /** The Monday of the week that holds [day] (1 Jan 1970 was a Thursday). */
    fun weekStart(day: Long): Long = day - ((day + 3) % 7)

    private fun read(ctx: Context): JSONObject =
        try { JSONObject(prefs(ctx).getString("days", "{}") ?: "{}") } catch (e: Exception) { JSONObject() }

    /** Adds (or, with a negative number, takes back) cleaned bytes for today. */
    @Synchronized
    fun record(ctx: Context, bytes: Long) {
        if (bytes == 0L) return
        val j = read(ctx)
        val k = today().toString()
        j.put(k, j.optLong(k, 0L) + bytes)
        // keep about a year
        val keep = today() - 400
        val it = j.keys()
        val old = ArrayList<String>()
        while (it.hasNext()) { val key = it.next(); if ((key.toLongOrNull() ?: 0L) < keep) old += key }
        old.forEach { j.remove(it) }
        prefs(ctx).edit().putString("days", j.toString()).apply()
    }

    /** Bytes cleaned in each of the last [weeks] weeks, oldest first. The last item is this week. */
    fun weeks(ctx: Context, weeks: Int = 8): List<Pair<Long, Long>> {
        val j = read(ctx)
        val thisWeek = weekStart(today())
        val sums = HashMap<Long, Long>()
        val it = j.keys()
        while (it.hasNext()) {
            val key = it.next()
            val d = key.toLongOrNull() ?: continue
            val w = weekStart(d)
            sums[w] = (sums[w] ?: 0L) + j.optLong(key, 0L)
        }
        return (weeks - 1 downTo 0).map { i ->
            val w = thisWeek - 7L * i
            w to (sums[w] ?: 0L).coerceAtLeast(0L)
        }
    }

    fun thisWeek(ctx: Context): Long = weeks(ctx, 1).last().second

    /**
     * Weeks in a row with something cleaned. A week that is still empty does not break the streak,
     * so the number does not drop to zero on Monday morning.
     */
    fun streak(ctx: Context): Int {
        val list = weeks(ctx, 52)
        var i = list.lastIndex
        if (list[i].second <= 0L) i--
        var n = 0
        while (i >= 0 && list[i].second > 0L) { n++; i-- }
        return n
    }

    fun bestWeek(ctx: Context): Long = weeks(ctx, 52).maxOf { it.second }

    fun allTime(ctx: Context): Long = weeks(ctx, 52).sumOf { it.second }

    fun weekLabel(weekStartDay: Long): String {
        val c = Calendar.getInstance()
        c.timeInMillis = weekStartDay * 86_400_000L - TimeZone.getDefault().getOffset(weekStartDay * 86_400_000L)
        return "${c.get(Calendar.DAY_OF_MONTH)}/${c.get(Calendar.MONTH) + 1}"
    }

    fun notifyOn(ctx: Context): Boolean = prefs(ctx).getBoolean("notify", true)
    fun setNotify(ctx: Context, on: Boolean) = prefs(ctx).edit().putBoolean("notify", on).apply()
}

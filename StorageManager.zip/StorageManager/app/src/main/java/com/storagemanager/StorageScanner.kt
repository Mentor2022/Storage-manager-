package com.storagemanager

import android.content.Context
import android.media.MediaScannerConnection
import android.os.Environment
import android.os.StatFs
import java.io.File
import java.io.RandomAccessFile
import java.security.MessageDigest

data class FileItem(val path: String, val size: Long, val modified: Long) {
    val name: String get() = path.substringAfterLast('/')
    val folder: String get() = path.substringBeforeLast('/').substringAfter("/storage/emulated/0")

    /** For WhatsApp files: "WhatsApp Images", "WhatsApp Video", "Statuses"… */
    val waGroup: String get() = path.substringAfter("/Media/", "").substringBefore('/').trimStart('.').ifEmpty { "Other" }
    val isSent: Boolean get() = path.contains("/Sent/")
}

enum class Category(val label: String) {
    IMAGES("Photos"), VIDEO("Videos"), AUDIO("Audio"), DOCS("Documents"), APK("App installers"), OTHER("Other")
}

data class ScanResult(
    val total: Long,
    val free: Long,
    val byCategory: Map<Category, Long>,
    val large: List<FileItem>,
    val junk: List<FileItem>,
    val duplicates: List<List<FileItem>>,
    val whatsapp: List<FileItem> = emptyList(),
    val downloads: List<FileItem> = emptyList(),
    val screenshots: List<FileItem> = emptyList(),
) {
    val used: Long get() = total - free

    fun without(paths: Set<String>) = copy(
        large = large.filterNot { it.path in paths },
        junk = junk.filterNot { it.path in paths },
        whatsapp = whatsapp.filterNot { it.path in paths },
        downloads = downloads.filterNot { it.path in paths },
        screenshots = screenshots.filterNot { it.path in paths },
        duplicates = duplicates
            .map { g -> g.filterNot { it.path in paths } }
            .filter { it.size > 1 },
    )
}

/** Everything here works fully offline: it only reads the phone's own storage. */
object StorageScanner {
    const val LARGE_MIN = 50L * 1024 * 1024       // files >= 50 MB count as "large"
    const val DUP_MIN = 100L * 1024               // ignore tiny files when looking for duplicates
    private const val QUICK = 64 * 1024

    private val images = setOf("jpg", "jpeg", "png", "gif", "webp", "heic", "bmp")
    private val videos = setOf("mp4", "mkv", "3gp", "avi", "mov", "webm")
    private val audio = setOf("mp3", "m4a", "aac", "wav", "ogg", "opus", "amr", "flac")
    private val docs = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv", "epub")
    private val junkExt = setOf("tmp", "temp", "log", "bak", "chk", "old", "thumb", "thumbdata")

    fun root(): File = Environment.getExternalStorageDirectory()

    fun space(): Pair<Long, Long> {
        val s = StatFs(root().path)
        return s.totalBytes to s.availableBytes
    }

    private fun categoryOf(ext: String) = when (ext) {
        in images -> Category.IMAGES
        in videos -> Category.VIDEO
        in audio -> Category.AUDIO
        in docs -> Category.DOCS
        "apk" -> Category.APK
        else -> Category.OTHER
    }

    private fun isJunk(f: File, ext: String): Boolean {
        val p = f.path
        return ext in junkExt || ext == "apk" || f.length() == 0L ||
            p.contains("/.thumbnails/") || p.contains("/.Trash") || p.contains("/.trash")
    }

    fun scan(onProgress: (String) -> Unit): ScanResult {
        val cats = Category.values().associateWith { 0L }.toMutableMap()
        val large = ArrayList<FileItem>()
        val junk = ArrayList<FileItem>()
        val whatsapp = ArrayList<FileItem>()
        val downloads = ArrayList<FileItem>()
        val screenshots = ArrayList<FileItem>()
        val rootPath = root().path
        val startTime = System.currentTimeMillis()
        val oldMs = 60L * 24 * 3600 * 1000 // "old" = older than 60 days
        val bySize = HashMap<Long, MutableList<FileItem>>()
        var count = 0
        var lastReport = 0L

        root().walkTopDown()
            .onEnter { it.path != "${root().path}/Android/data" && it.path != "${root().path}/Android/obb" && it.path != Trash.dir().path }
            .onFail { _, _ -> }
            .filter { it.isFile }
            .forEach { f ->
                val size = f.length()
                val ext = f.extension.lowercase()
                val item = FileItem(f.path, size, f.lastModified())
                cats[categoryOf(ext)] = cats.getValue(categoryOf(ext)) + size
                if (size >= LARGE_MIN) large += item
                if (isJunk(f, ext)) junk += item
                val p = f.path
                if (ext != "nomedia" && (p.contains("/WhatsApp/Media/") || p.contains("/WhatsApp Business/Media/"))) whatsapp += item
                if (p.startsWith("$rootPath/Download/") && startTime - item.modified > oldMs) downloads += item
                if (p.contains("/Screenshots/", ignoreCase = true)) screenshots += item
                if (size >= DUP_MIN && ext !in junkExt) bySize.getOrPut(size) { ArrayList() } += item
                // Update the screen at most ~3 times a second so the spinner stays smooth
                if (++count % 200 == 0) {
                    val now = System.currentTimeMillis()
                    if (now - lastReport > 350) { lastReport = now; onProgress("Scanned $count files…") }
                }
            }

        onProgress("Looking for duplicates…")
        val (total, free) = space()
        return ScanResult(
            total = total,
            free = free,
            byCategory = cats,
            large = large.sortedByDescending { it.size }.take(200),
            junk = junk.sortedByDescending { it.size },
            duplicates = findDuplicates(bySize),
            whatsapp = whatsapp.sortedByDescending { it.size },
            downloads = downloads.sortedByDescending { it.size },
            screenshots = screenshots.sortedByDescending { it.size },
        )
    }

    /** Same size -> same first/last 64 KB -> same full SHA-256. Fast, and no false positives. */
    private fun findDuplicates(bySize: Map<Long, List<FileItem>>): List<List<FileItem>> {
        val result = ArrayList<List<FileItem>>()
        for ((size, group) in bySize) {
            if (group.size < 2) continue
            val quick = group.groupBy { quickKey(it) }.values.filter { it.size > 1 }
            for (q in quick) {
                val full = q.groupBy { fullHash(it) }.filterKeys { it != null }.values.filter { it.size > 1 }
                result += full.map { g -> g.sortedBy { it.modified } } // oldest first = the one we keep
            }
        }
        return result.sortedByDescending { it[0].size * (it.size - 1) }
    }

    private fun quickKey(i: FileItem): String = try {
        RandomAccessFile(i.path, "r").use { r ->
            val md = MessageDigest.getInstance("SHA-256")
            val buf = ByteArray(QUICK)
            var n = r.read(buf); if (n > 0) md.update(buf, 0, n)
            if (i.size > QUICK * 2) {
                r.seek(i.size - QUICK)
                n = r.read(buf); if (n > 0) md.update(buf, 0, n)
            }
            md.digest().joinToString("") { "%02x".format(it) }
        }
    } catch (e: Exception) { "err-${i.path}" }

    private fun fullHash(i: FileItem): String? = try {
        val md = MessageDigest.getInstance("SHA-256")
        File(i.path).inputStream().buffered(256 * 1024).use { s ->
            val buf = ByteArray(256 * 1024)
            while (true) { val n = s.read(buf); if (n < 0) break; md.update(buf, 0, n) }
        }
        md.digest().joinToString("") { "%02x".format(it) }
    } catch (e: Exception) { null }

    /** Deletes the files and tells the gallery/media store. Returns the paths actually removed. */
    fun delete(ctx: Context, paths: List<String>): Set<String> {
        val gone = HashSet<String>()
        for (p in paths) if (File(p).let { it.exists() && it.delete() }) gone += p
        if (gone.isNotEmpty()) MediaScannerConnection.scanFile(ctx, gone.toTypedArray(), null, null)
        return gone
    }
}

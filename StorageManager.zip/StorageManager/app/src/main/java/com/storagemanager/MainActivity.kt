package com.storagemanager

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.format.Formatter
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private var storageOk by mutableStateOf(false)
    private var usageOk by mutableStateOf(false)

    private val legacyPerm =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            storageOk = hasStorage()
            if (storageOk) vm.scan()
        }

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private var askedNotif = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppConfig.load(this)
        LowSpaceWorker.schedule(this)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) { App() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        storageOk = hasStorage()
        usageOk = AppUsage.hasAccess(this)
        if (storageOk && !askedNotif && Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotif = true
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (storageOk && vm.result == null && !vm.scanning) vm.scan()
        else if (usageOk && vm.apps.isEmpty()) vm.refreshApps()
    }

    private fun hasStorage() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else {
            legacyPerm.launch(
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            )
        }
    }

    private fun requestUsage() = startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))

    // ───────────────────────── UI ─────────────────────────

    @Composable
    private fun App() {
        if (!storageOk) {
            PermissionScreen(); return
        }
        val snack = remember { SnackbarHostState() }
        var tab by remember { mutableIntStateOf(0) }
        var confirm by remember { mutableStateOf(false) }
        val everyTab = listOf(
            "Overview" to "overview", "Large" to "large", "Duplicates" to "duplicates", "Junk" to "junk", "WhatsApp" to "whatsapp",
            "Downloads" to "downloads", "Screenshots" to "screenshots", "Safety" to "safety", "Email" to "email", "Apps" to "apps", "Bin" to "bin",
        )
        // The admin can switch features off in the portal; Overview is always there
        val tabs = everyTab.filter { it.second == "overview" || it.second in AppConfig.features }.map { it.first }
        val tabKeys = everyTab.filter { it.second == "overview" || it.second in AppConfig.features }.map { it.second }

        LaunchedEffect(Unit) { vm.refreshBin() }
        LaunchedEffect(vm.message) {
            vm.message?.let { snack.showSnackbar(it); vm.message = null }
        }

        Scaffold(
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = { if (vm.selected.isNotEmpty()) DeleteBar { confirm = true } },
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                ScrollableTabRow(selectedTabIndex = tab.coerceIn(0, tabs.lastIndex), edgePadding = 8.dp) {
                    tabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
                }
                val r = vm.result
                if (vm.scanning || r == null) {
                    Column(
                        Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(12.dp))
                        Text(vm.progress.ifEmpty { "Scanning your phone…" })
                    }
                } else when (tabKeys.getOrElse(tab) { "overview" }) {
                    "overview" -> Overview(r)
                    "large" -> LargeTab(r)
                    "duplicates" -> DuplicatesTab(r)
                    "junk" -> JunkTab(r)
                    "whatsapp" -> WhatsAppTab(r)
                    "downloads" -> SimpleTab(r.downloads, "Files in Downloads older than 60 days", "No old downloads.")
                    "screenshots" -> SimpleTab(r.screenshots, "Screenshots, biggest first", "No screenshots found.")
                    "safety" -> SafetyTab(r)
                    "email" -> EmailTab()
                    "bin" -> BinTab()
                    else -> AppsTab()
                }
            }
        }

        vm.preview?.let { f ->
            FilePreview(
                f, marked = f.path in vm.selected,
                onToggleMark = { vm.toggle(f.path) },
                onClose = { vm.preview = null },
            )
        }

        if (confirm) {
            AlertDialog(
                onDismissRequest = { confirm = false },
                title = { Text((if (vm.binOn) "Move " else "Delete ") + "${vm.selected.size} files" + (if (vm.binOn) " to the Bin?" else "?")) },
                text = {
                    Column {
                        Text(
                            (if (vm.binOn) "These go to the Bin (${fmt(vm.selectedBytes)}). You can undo for ${AppConfig.binDays} days; space is freed when they are removed from the Bin."
                            else "This frees ${fmt(vm.selectedBytes)} and cannot be undone.") + " Tap a file to look at it first."
                        )
                        Spacer(Modifier.height(8.dp))
                        vm.selected.take(6).forEach { p ->
                            val item = vm.fileFor(p)
                            Text(
                                (item?.name ?: p.substringAfterLast('/')) + (item?.let { " · " + fmt(it.size) } ?: ""),
                                Modifier.fillMaxWidth().clickable(enabled = item != null) { confirm = false; vm.preview = item }.padding(vertical = 6.dp),
                                maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium,
                            )
                        }
                        if (vm.selected.size > 6) Text("and ${vm.selected.size - 6} more", style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = { TextButton(onClick = { confirm = false; vm.deleteSelected() }) { Text(if (vm.binOn) "Move to Bin" else "Delete") } },
                dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
            )
        }
    }

    @Composable
    private fun PermissionScreen() {
        Column(
            Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally
        ) {
            Text("Free up your phone", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Text(
                "To find big files, duplicates and junk, this app needs access to your files. " +
                    "Everything runs on your phone. No internet is used and nothing is uploaded."
            )
            Spacer(Modifier.height(20.dp))
            Button(onClick = { requestStorage() }) { Text("Allow file access") }
        }
    }

    @Composable
    private fun Overview(r: ScanResult) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp)) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("${fmt(r.used)} used of ${fmt(r.total)}", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { r.used.toFloat() / r.total.coerceAtLeast(1) },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("${fmt(r.free)} free")
                    }
                }
                if (r.free.toFloat() / r.total.coerceAtLeast(1) < 0.10f) {
                    Spacer(Modifier.height(12.dp))
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    ) {
                        Text(
                            "Your phone is almost full. Start with junk, duplicates and WhatsApp media.",
                            Modifier.padding(16.dp),
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                val dupWaste = r.duplicates.sumOf { it[0].size * (it.size - 1) }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Easy wins", style = MaterialTheme.typography.titleMedium)
                        Text("Junk files: ${fmt(r.junk.sumOf { it.size })}")
                        Text("Duplicate copies: ${fmt(dupWaste)}")
                        Text("Large files: ${fmt(r.large.sumOf { it.size })}")
                        Text("WhatsApp media: ${fmt(r.whatsapp.sumOf { it.size })}")
                        Text("Old downloads: ${fmt(r.downloads.sumOf { it.size })}")
                        Text("Screenshots: ${fmt(r.screenshots.sumOf { it.size })}")
                        if (vm.freedTotal > 0) {
                            Spacer(Modifier.height(8.dp))
                            Text("Freed so far with this app: ${fmt(vm.freedTotal)}", style = MaterialTheme.typography.titleSmall)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("What's taking space", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
            }
            val max = r.byCategory.values.maxOrNull()?.coerceAtLeast(1) ?: 1
            items(r.byCategory.entries.sortedByDescending { it.value }.toList()) { (cat, bytes) ->
                Column(Modifier.padding(vertical = 6.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Text(cat.label); Text(fmt(bytes))
                    }
                    LinearProgressIndicator(progress = { bytes.toFloat() / max }, modifier = Modifier.fillMaxWidth())
                }
            }
            item {
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = { vm.scan() }, Modifier.fillMaxWidth()) { Text("Scan again") }
            }
        }
    }

    @Composable
    private fun LargeTab(r: ScanResult) {
        if (r.large.isEmpty()) return Empty("No files over 50 MB. Nice.")
        FileList(r.large)
    }

    @Composable
    private fun JunkTab(r: ScanResult) {
        if (r.junk.isEmpty()) return Empty("No junk found.")
        Column {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Temp files, logs, old installers, empty files", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { vm.selectAll(r.junk.map { it.path }) }) { Text("Select all") }
            }
            FileList(r.junk)
        }
    }

    @Composable
    private fun SafetyTab(r: ScanResult) {
        val ctx = LocalContext.current
        val apkCount = r.junk.count { it.name.endsWith(".apk", ignoreCase = true) }
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Column(Modifier.padding(16.dp)) {
                    Text(
                        "This is a simple check, not an antivirus. It cannot find viruses, but it points out " +
                            "apps worth a second look. It works offline. A flagged app is not necessarily harmful.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    if (apkCount > 0) {
                        Spacer(Modifier.height(8.dp))
                        Text("$apkCount installer (.apk) files in storage. Only install files from sources you trust.")
                    }
                }
            }
            if (vm.safety.isEmpty()) item { Text("No apps need a second look.", Modifier.padding(16.dp)) }
            items(vm.safety, key = { it.pkg }) { a ->
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Text(a.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            when (a.level) { 2 -> "High"; 1 -> "Medium"; else -> "Low" },
                            color = if (a.level == 2) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurface,
                        )
                    }
                    a.reasons.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall) }
                    Row {
                        TextButton(onClick = {
                            safeStart(ctx,
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))
                            )
                        }) { Text("App info") }
                        TextButton(onClick = {
                            safeStart(ctx, Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
                        }) { Text("Uninstall") }
                    }
                    HorizontalDivider()
                }
            }
        }
    }

    /** Starts a screen; shows a message instead of crashing when the phone has nothing to handle it. */
    private fun safeStart(ctx: android.content.Context, i: Intent) {
        try { ctx.startActivity(i) } catch (e: Exception) {
            android.widget.Toast.makeText(ctx, "This phone cannot open that screen.", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    /** Opens the Gmail search in a browser; never crashes when nothing can open it. */
    private fun openGmailSearch(ctx: android.content.Context, query: String) {
        val url = "https://mail.google.com/mail/u/0/#search/" + Uri.encode(query)
        try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE))
            return
        } catch (e: Exception) {
            // no browser: try the Gmail app itself
        }
        try {
            val gm = ctx.packageManager.getLaunchIntentForPackage("com.google.android.gm")
            if (gm != null) {
                ctx.startActivity(gm)
                android.widget.Toast.makeText(ctx, "Search for: $query", android.widget.Toast.LENGTH_LONG).show()
                return
            }
        } catch (e: Exception) {
            // fall through
        }
        android.widget.Toast.makeText(ctx, "Could not open Gmail. Install a browser or the Gmail app.", android.widget.Toast.LENGTH_LONG).show()
    }

    @Composable
    private fun EmailTab() {
        val ctx = LocalContext.current
        val searches = listOf(
            "Emails over 10 MB" to "larger:10M",
            "Attachments older than 1 year" to "has:attachment older_than:1y",
            "Promotions" to "category:promotions",
            "Social" to "category:social",
            "Spam" to "in:spam",
            "Trash" to "in:trash",
        )
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Column(Modifier.padding(16.dp)) {
                    Text("Gmail cleaner", style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "Opens Gmail with a ready-made search. Tick the select-all box, then tap Delete. " +
                            "Empty Spam and Trash afterwards to really free space.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "This frees space in your Google account (the 15 GB shared by Gmail, Drive and Photos), " +
                            "not on the phone itself. It needs internet. The rest of this app stays offline.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
            items(searches) { (label, query) ->
                OutlinedButton(
                    onClick = {
                        openGmailSearch(ctx, query)
                    },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                ) { Text(label) }
            }
        }
    }

    @Composable
    private fun SimpleTab(files: List<FileItem>, hint: String, empty: String) {
        if (files.isEmpty()) return Empty(empty)
        Column {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text(hint, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { vm.selectAll(files.map { it.path }) }) { Text("Select all") }
            }
            FileList(files)
        }
    }

    @Composable
    private fun WhatsAppTab(r: ScanResult) {
        if (r.whatsapp.isEmpty()) return Empty("No WhatsApp media found.")
        val groups = r.whatsapp.groupBy { it.waGroup }.entries.sortedByDescending { e -> e.value.sumOf { it.size } }
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Text(
                    "Deleting here removes media from this phone only. Files you sent are not selected automatically.",
                    Modifier.padding(16.dp),
                    style = MaterialTheme.typography.bodySmall,
                )
            }
            groups.forEach { (name, files) ->
                item(key = "h-$name") {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp),
                        Arrangement.SpaceBetween, Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(name, style = MaterialTheme.typography.titleSmall)
                            Text("${files.size} files · ${fmt(files.sumOf { it.size })}", style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { vm.selectAll(files.filter { !it.isSent }.map { it.path }) }) {
                            Text("Select received")
                        }
                    }
                }
                items(files, key = { it.path }) { FileRow(it) }
                item(key = "d-$name") { HorizontalDivider() }
            }
        }
    }

    @Composable
    private fun DuplicatesTab(r: ScanResult) {
        if (r.duplicates.isEmpty()) return Empty("No duplicates found.")
        Column {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("The oldest copy in each group is kept", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { vm.selectAll(r.duplicates.flatMap { it.drop(1) }.map { it.path }) }) {
                    Text("Select extras")
                }
            }
            LazyColumn(Modifier.fillMaxSize()) {
                r.duplicates.forEach { group ->
                    item {
                        Text(
                            "${group.size} copies · ${fmt(group[0].size * (group.size - 1))} wasted",
                            Modifier.padding(16.dp, 12.dp, 16.dp, 0.dp),
                            style = MaterialTheme.typography.titleSmall,
                        )
                    }
                    items(group, key = { it.path }) { FileRow(it) }
                    item { HorizontalDivider() }
                }
            }
        }
    }

    @Composable
    private fun FileList(files: List<FileItem>) {
        LazyColumn(Modifier.fillMaxSize()) {
            item(key = "hint") { Text("Tap a file to look at it before you delete.", Modifier.padding(16.dp, 8.dp), style = MaterialTheme.typography.bodySmall) }
            items(files, key = { it.path }) { FileRow(it) }
        }
    }

    @Composable
    private fun FileRow(f: FileItem) {
        val checked = f.path in vm.selected
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checked, onCheckedChange = { vm.toggle(f.path) })
            Column(Modifier.weight(1f).clickable { vm.preview = f }) {
                Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${f.folder} · ${DateFormat.getDateInstance().format(Date(f.modified))}",
                    style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Text(fmt(f.size), Modifier.padding(start = 8.dp))
        }
    }

    @Composable
    private fun AppsTab() {
        if (!usageOk) {
            Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                Text("To see how much space each app uses, allow Usage access for this app.")
                Spacer(Modifier.height(16.dp))
                Button(onClick = { requestUsage() }) { Text("Open settings") }
            }
            return
        }
        if (vm.apps.isEmpty()) return Empty("No app data yet.")
        val ctx = LocalContext.current
        LazyColumn(Modifier.fillMaxSize()) {
            items(vm.apps, key = { it.pkg }) { a ->
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Text(a.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(fmt(a.bytes))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Cache ${fmt(a.cache)}", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = {
                            safeStart(ctx,
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))
                            )
                        }) { Text("Clear cache") }
                        TextButton(onClick = {
                            safeStart(ctx, Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
                        }) { Text("Uninstall") }
                    }
                    HorizontalDivider()
                }
            }
        }
    }

    @Composable
    private fun BinTab() {
        var look by remember { mutableStateOf<TrashItem?>(null) }
        var emptyAsk by remember { mutableStateOf(false) }
        val items = vm.bin
        if (items.isEmpty()) return Empty("The Bin is empty. Deleted files wait here for ${AppConfig.binDays} days.")
        Column {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text(
                    "${items.size} files · ${fmt(items.sumOf { it.size })}. Removed for good after ${AppConfig.binDays} days.",
                    Modifier.weight(1f), style = MaterialTheme.typography.bodySmall,
                )
                TextButton(onClick = { emptyAsk = true }) { Text("Empty Bin") }
            }
            LazyColumn(Modifier.fillMaxSize()) {
                items(items, key = { it.id }) { t ->
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                        Row(Modifier.fillMaxWidth().clickable { look = t }, Arrangement.SpaceBetween) {
                            Text(t.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(fmt(t.size), Modifier.padding(start = 8.dp))
                        }
                        val daysLeft = (AppConfig.binDays - (System.currentTimeMillis() - t.deleted) / 86_400_000L).coerceAtLeast(0)
                        Text(
                            "${t.original.substringBeforeLast('/').substringAfter("/storage/emulated/0")} · $daysLeft days left",
                            style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        )
                        Row {
                            TextButton(onClick = { vm.restore(t.id) }) { Text("Restore") }
                            TextButton(onClick = { vm.deleteForever(setOf(t.id)) }) { Text("Delete for good") }
                        }
                        HorizontalDivider()
                    }
                }
            }
        }
        look?.let { t ->
            FilePreview(FileItem(t.stored, t.size, t.deleted), marked = false, onToggleMark = null, onClose = { look = null }, title = t.name)
        }
        if (emptyAsk) {
            AlertDialog(
                onDismissRequest = { emptyAsk = false },
                title = { Text("Empty the Bin?") },
                text = { Text("${items.size} files (${fmt(items.sumOf { it.size })}) will be removed for good.") },
                confirmButton = { TextButton(onClick = { emptyAsk = false; vm.deleteForever(items.map { it.id }.toSet()) }) { Text("Empty Bin") } },
                dismissButton = { TextButton(onClick = { emptyAsk = false }) { Text("Cancel") } },
            )
        }
    }

    @Composable
    private fun DeleteBar(onDelete: () -> Unit) {
        Surface(tonalElevation = 6.dp) {
            Row(Modifier.fillMaxWidth().padding(12.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                TextButton(onClick = { vm.clearSelection() }) { Text("Clear") }
                Box(Modifier.weight(1f))
                Button(onClick = onDelete) { Text("Delete ${vm.selected.size} · ${fmt(vm.selectedBytes)}") }
            }
        }
    }

    @Composable
    private fun Empty(text: String) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { Text(text) }
    }

    private fun fmt(b: Long): String = Formatter.formatShortFileSize(this, b)
}

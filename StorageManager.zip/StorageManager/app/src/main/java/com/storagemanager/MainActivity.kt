package com.storagemanager

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.format.Formatter
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private var storageOk by mutableStateOf(false)
    private var usageOk by mutableStateOf(false)

    private val legacyPerm =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            storageOk = hasStorage()
            if (storageOk) vm.scan()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize().statusBarsPadding()) { App() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        storageOk = hasStorage()
        usageOk = AppUsage.hasAccess(this)
        if (storageOk && vm.result == null && !vm.scanning) vm.scan()
        else if (usageOk && vm.apps.isEmpty()) vm.refreshApps()
    }

    private fun hasStorage() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else {
            legacyPerm.launch(
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            )
        }
    }

    private fun requestUsage() = startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))

    // ───────────────────────── UI ─────────────────────────

    @Composable
    private fun App() {
        if (!storageOk) {
            PermissionScreen(); return
        }
        val snack = remember { SnackbarHostState() }
        var tab by remember { mutableIntStateOf(0) }
        var confirm by remember { mutableStateOf(false) }
        val tabs = listOf("Overview", "Large", "Duplicates", "Junk", "Apps")

        LaunchedEffect(vm.message) {
            vm.message?.let { snack.showSnackbar(it); vm.message = null }
        }

        Scaffold(
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = { if (vm.selected.isNotEmpty()) DeleteBar { confirm = true } },
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
                    tabs.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
                }
                val r = vm.result
                if (vm.scanning || r == null) {
                    Column(
                        Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally
                    ) {
                        CircularProgressIndicator()
                        Spacer(Modifier.height(12.dp))
                        Text(vm.progress.ifEmpty { "Scanning your phone…" })
                    }
                } else when (tab) {
                    0 -> Overview(r)
                    1 -> LargeTab(r)
                    2 -> DuplicatesTab(r)
                    3 -> JunkTab(r)
                    else -> AppsTab()
                }
            }
        }

        if (confirm) {
            AlertDialog(
                onDismissRequest = { confirm = false },
                title = { Text("Delete ${vm.selected.size} files?") },
                text = { Text("This frees ${fmt(vm.selectedBytes)} and cannot be undone.") },
                confirmButton = { TextButton(onClick = { confirm = false; vm.deleteSelected() }) { Text("Delete") } },
                dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
            )
        }
    }

    @Composable
    private fun PermissionScreen() {
        Column(
            Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally
        ) {
            Text("Free up your phone", style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.height(12.dp))
            Text(
                "To find big files, duplicates and junk, this app needs access to your files. " +
                    "Everything runs on your phone. No internet is used and nothing is uploaded."
            )
            Spacer(Modifier.height(20.dp))
            Button(onClick = { requestStorage() }) { Text("Allow file access") }
        }
    }

    @Composable
    private fun Overview(r: ScanResult) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp)) {
            item {
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("${fmt(r.used)} used of ${fmt(r.total)}", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { r.used.toFloat() / r.total.coerceAtLeast(1) },
                            modifier = Modifier.fillMaxWidth(),
                        )
                        Spacer(Modifier.height(8.dp))
                        Text("${fmt(r.free)} free")
                    }
                }
                Spacer(Modifier.height(12.dp))
                val dupWaste = r.duplicates.sumOf { it[0].size * (it.size - 1) }
                Card(Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Easy wins", style = MaterialTheme.typography.titleMedium)
                        Text("Junk files: ${fmt(r.junk.sumOf { it.size })}")
                        Text("Duplicate copies: ${fmt(dupWaste)}")
                        Text("Large files: ${fmt(r.large.sumOf { it.size })}")
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("What's taking space", style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.height(4.dp))
            }
            val max = r.byCategory.values.maxOrNull()?.coerceAtLeast(1) ?: 1
            items(r.byCategory.entries.sortedByDescending { it.value }.toList()) { (cat, bytes) ->
                Column(Modifier.padding(vertical = 6.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Text(cat.label); Text(fmt(bytes))
                    }
                    LinearProgressIndicator(progress = { bytes.toFloat() / max }, modifier = Modifier.fillMaxWidth())
                }
            }
            item {
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = { vm.scan() }, Modifier.fillMaxWidth()) { Text("Scan again") }
            }
        }
    }

    @Composable
    private fun LargeTab(r: ScanResult) {
        if (r.large.isEmpty()) return Empty("No files over 50 MB. Nice.")
        FileList(r.large)
    }

    @Composable
    private fun JunkTab(r: ScanResult) {
        if (r.junk.isEmpty()) return Empty("No junk found.")
        Column {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("Temp files, logs, old installers, empty files", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { vm.selectAll(r.junk.map { it.path }) }) { Text("Select all") }
            }
            FileList(r.junk)
        }
    }

    @Composable
    private fun DuplicatesTab(r: ScanResult) {
        if (r.duplicates.isEmpty()) return Empty("No duplicates found.")
        Column {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                Text("The oldest copy in each group is kept", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                TextButton(onClick = { vm.selectAll(r.duplicates.flatMap { it.drop(1) }.map { it.path }) }) {
                    Text("Select extras")
                }
            }
            LazyColumn(Modifier.fillMaxSize()) {
                r.duplicates.forEach { group ->
                    item {
                        Text(
                            "${group.size} copies · ${fmt(group[0].size * (group.size - 1))} wasted",
                            Modifier.padding(16.dp, 12.dp, 16.dp, 0.dp),
                            style = MaterialTheme.typography.titleSmall,
                        )
                    }
                    items(group, key = { it.path }) { FileRow(it) }
                    item { HorizontalDivider() }
                }
            }
        }
    }

    @Composable
    private fun FileList(files: List<FileItem>) {
        LazyColumn(Modifier.fillMaxSize()) { items(files, key = { it.path }) { FileRow(it) } }
    }

    @Composable
    private fun FileRow(f: FileItem) {
        val checked = f.path in vm.selected
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = checked, onCheckedChange = { vm.toggle(f.path) })
            Column(Modifier.weight(1f)) {
                Text(f.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${f.folder} · ${DateFormat.getDateInstance().format(Date(f.modified))}",
                    style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Text(fmt(f.size), Modifier.padding(start = 8.dp))
        }
    }

    @Composable
    private fun AppsTab() {
        if (!usageOk) {
            Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                Text("To see how much space each app uses, allow Usage access for this app.")
                Spacer(Modifier.height(16.dp))
                Button(onClick = { requestUsage() }) { Text("Open settings") }
            }
            return
        }
        if (vm.apps.isEmpty()) return Empty("No app data yet.")
        val ctx = LocalContext.current
        LazyColumn(Modifier.fillMaxSize()) {
            items(vm.apps, key = { it.pkg }) { a ->
                Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                        Text(a.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(fmt(a.bytes))
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Cache ${fmt(a.cache)}", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
                        TextButton(onClick = {
                            ctx.startActivity(
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}"))
                            )
                        }) { Text("Clear cache") }
                        TextButton(onClick = {
                            ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
                        }) { Text("Uninstall") }
                    }
                    HorizontalDivider()
                }
            }
        }
    }

    @Composable
    private fun DeleteBar(onDelete: () -> Unit) {
        Surface(tonalElevation = 6.dp) {
            Row(Modifier.fillMaxWidth().padding(12.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                TextButton(onClick = { vm.clearSelection() }) { Text("Clear") }
                Box(Modifier.weight(1f))
                Button(onClick = onDelete) { Text("Delete ${vm.selected.size} · ${fmt(vm.selectedBytes)}") }
            }
        }
    }

    @Composable
    private fun Empty(text: String) {
        Box(Modifier.fillMaxSize(), Alignment.Center) { Text(text) }
    }

    private fun fmt(b: Long): String = Formatter.formatShortFileSize(this, b)
}

package com.storagemanager

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.text.format.Formatter
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.DateFormat
import java.util.Date

class MainActivity : ComponentActivity() {
    private val vm: MainViewModel by viewModels()
    private var storageOk by mutableStateOf(false)
    private var usageOk by mutableStateOf(false)

    private val legacyPerm =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            storageOk = hasStorage()
            if (storageOk) vm.scan()
        }

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private var askedNotif = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppConfig.load(this)
        LowSpaceWorker.schedule(this)
        AutoCleanWorker.schedule(this)
        WeeklyReportWorker.schedule(this)
        setContent {
            AppTheme {
                Surface(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding(), color = MaterialTheme.colorScheme.background) { App() }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        storageOk = hasStorage()
        usageOk = AppUsage.hasAccess(this)
        if (storageOk && !askedNotif && Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askedNotif = true
            notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        if (storageOk && vm.result == null && !vm.scanning) vm.scan()
        else if (usageOk && vm.apps.isEmpty()) vm.refreshApps()
    }

    private fun hasStorage() =
        if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager()
        else checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED

    private fun requestStorage() {
        if (Build.VERSION.SDK_INT >= 30) {
            startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else {
            legacyPerm.launch(
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
            )
        }
    }

    private fun requestUsage() = startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))

    // ───────────────────────── UI ─────────────────────────

    private val everyTab = listOf(
        Triple("Overview", "overview", "🏠"), Triple("Compress", "compress", "🗜️"), Triple("Report", "report", "📊"),
        Triple("Large", "large", "🐘"), Triple("Duplicates", "duplicates", "👯"),
        Triple("Similar", "similar", "🖼️"), Triple("Junk", "junk", "🧹"), Triple("WhatsApp", "whatsapp", "💬"),
        Triple("Downloads", "downloads", "⬇️"), Triple("Screenshots", "screenshots", "📱"), Triple("Safety", "safety", "🛡️"),
        Triple("Email", "email", "✉️"), Triple("Apps", "apps", "🧩"), Triple("Auto-clean", "rules", "🤖"), Triple("Bin", "bin", "🗑️"),
    )

    private fun tabColor(key: String): Color = when (key) {
        "overview" -> Indigo; "large" -> Orange; "duplicates" -> Violet; "similar" -> Pink; "junk" -> Teal
        "whatsapp" -> Green; "downloads" -> Sky; "screenshots" -> Pink; "safety" -> Red; "email" -> Orange
        "apps" -> Indigo; "compress" -> Color(0xFF00ACC1); "report" -> Orange; "rules" -> Violet
        else -> Color(0xFF64748B)
    }

    @Composable
    private fun App() {
        if (!storageOk) {
            PermissionScreen(); return
        }
        val snack = remember { SnackbarHostState() }
        var tab by remember { mutableIntStateOf(0) }
        var confirm by remember { mutableStateOf(false) }
        // The admin can switch features off in the portal; Overview is always there
        val shown = everyTab.filter {
            it.second == "overview" || (if (it.second == "bin") AppConfig.binVisible else it.second in AppConfig.features)
        }

        LaunchedEffect(Unit) { vm.refreshBin() }
        LaunchedEffect(vm.message) {
            vm.message?.let { snack.showSnackbar(it); vm.message = null }
        }

        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            snackbarHost = { SnackbarHost(snack) },
            bottomBar = { if (vm.selected.isNotEmpty()) DeleteBar { confirm = true } },
        ) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(shown.size) { i ->
                        val t = shown[i]
                        TabChip(t.first, t.third, tab == i, tabColor(t.second)) { tab = i }
                    }
                }
                val r = vm.result
                if (vm.scanning || r == null) {
                    Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                        GradientCard(HeroGradient, Modifier.size(110.dp)) {
                            Box(Modifier.fillMaxSize(), Alignment.Center) {
                                CircularProgressIndicator(color = Color.White, trackColor = Color.White.copy(alpha = 0.3f), strokeWidth = 5.dp, modifier = Modifier.size(56.dp))
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        Text("Scanning your phone", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(4.dp))
                        Text(vm.progress.ifEmpty { "Looking for things you can clear…" }, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                } else when (shown.getOrNull(tab.coerceIn(0, shown.lastIndex))?.second ?: "overview") {
                    "overview" -> Overview(r) { vm.clearSelection(); vm.selectAll(vm.smartPaths()); if (vm.selected.isNotEmpty()) confirm = true }
                    "compress" -> CompressScreen(vm)
                    "report" -> ReportScreen(vm)
                    "rules" -> RulesScreen(vm)
                    "large" -> LargeTab(r)
                    "duplicates" -> DuplicatesTab(r)
                    "similar" -> SimilarTab()
                    "junk" -> JunkTab(r)
                    "whatsapp" -> WhatsAppTab(r)
                    "downloads" -> SimpleTab(r.downloads, "Files in Downloads older than 60 days", "No old downloads.")
                    "screenshots" -> SimpleTab(r.screenshots, "Screenshots, biggest first", "No screenshots found.")
                    "safety" -> SafetyTab(r)
                    "email" -> EmailTab()
                    "bin" -> BinTab()
                    else -> AppsTab()
                }
            }
        }

        vm.preview?.let { f ->
            FilePreview(
                f, marked = f.path in vm.selected,
                onToggleMark = { vm.toggle(f.path) },
                onClose = { vm.preview = null },
            )
        }

        if (confirm) {
            AlertDialog(
                shape = RoundedCornerShape(24.dp),
                onDismissRequest = { confirm = false },
                title = { Text((if (vm.binOn) "Move " else "Delete ") + "${vm.selected.size} files" + (if (vm.binOn) " to the Bin?" else "?"), fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text(
                            (if (vm.binOn) "These go to the Bin (${fmt(vm.selectedBytes)}). You can undo for ${AppConfig.binDays} days; space is freed when they are removed from the Bin."
                            else "This frees ${fmt(vm.selectedBytes)} and cannot be undone.") + " Tap a file to look at it first."
                        )
                        Spacer(Modifier.height(8.dp))
                        vm.selected.take(6).forEach { p ->
                            val item = vm.fileFor(p)
                            val nm = item?.name ?: p.substringAfterLast('/')
                            Row(
                                Modifier.fillMaxWidth().clickable(enabled = item != null) { confirm = false; vm.preview = item }.padding(vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                            ) {
                                EmojiBadge(fileEmoji(nm), fileColor(nm), 30)
                                Spacer(Modifier.width(8.dp))
                                Text(nm + (item?.let { " · " + fmt(it.size) } ?: ""), maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                        if (vm.selected.size > 6) Text("and ${vm.selected.size - 6} more", style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = { Button(onClick = { confirm = false; vm.deleteSelected() }) { Text(if (vm.binOn) "Move to Bin" else "Delete") } },
                dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } },
            )
        }
    }

    @Composable
    private fun PermissionScreen() {
        Column(
            Modifier.fillMaxSize().background(HeroGradient).padding(28.dp), Arrangement.Center, Alignment.CenterHorizontally
        ) {
            Box(Modifier.size(110.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f)), Alignment.Center) { Text("🧹", fontSize = 54.sp) }
            Spacer(Modifier.height(24.dp))
            Text("Free up your phone", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Text(
                "To find big files, duplicates and junk, this app needs access to your files. " +
                    "Everything runs on your phone. No internet is used and nothing is uploaded.",
                color = Color.White.copy(alpha = 0.92f), textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = { requestStorage() },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Indigo),
                modifier = Modifier.fillMaxWidth().height(54.dp),
            ) { Text("Allow file access", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
            Spacer(Modifier.height(14.dp))
            Text("🔒 Private · 📴 Works offline", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
        }
    }

    /** One row of the "Easy wins" grid: colored badge, label and size. */
    @Composable
    private fun WinTile(emoji: String, label: String, bytes: Long, color: Color, modifier: Modifier) {
        SoftCard(modifier) {
            Column(Modifier.padding(14.dp)) {
                EmojiBadge(emoji, color, 38)
                Spacer(Modifier.height(10.dp))
                Text(fmt(bytes), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = color)
                Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }

    @Composable
    private fun Overview(r: ScanResult, onSmartClean: () -> Unit) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp)) {
            item {
                GradientCard(HeroGradient, Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                        StorageRing(r.used.toFloat() / r.total.coerceAtLeast(1))
                        Spacer(Modifier.width(20.dp))
                        Column {
                            Text("Phone storage", color = Color.White.copy(alpha = 0.85f), fontSize = 13.sp)
                            Text(fmt(r.used), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                            Text("of ${fmt(r.total)}", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
                            Spacer(Modifier.height(10.dp))
                            Box(Modifier.clip(RoundedCornerShape(50)).background(Color.White.copy(alpha = 0.22f)).padding(horizontal = 12.dp, vertical = 5.dp)) {
                                Text("${fmt(r.free)} free", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                        }
                    }
                }
                if (r.free.toFloat() / r.total.coerceAtLeast(1) < 0.10f) {
                    Spacer(Modifier.height(12.dp))
                    Card(
                        Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("⚠️", fontSize = 24.sp)
                            Spacer(Modifier.width(12.dp))
                            Text("Your phone is almost full. Start with junk, duplicates and WhatsApp media.", color = MaterialTheme.colorScheme.onErrorContainer)
                        }
                    }
                }
                if ("report" in AppConfig.features) {
                    val week = History.thisWeek(this@MainActivity)
                    val streak = History.streak(this@MainActivity)
                    if (week > 0 || streak > 0) {
                        Spacer(Modifier.height(12.dp))
                        SoftCard(Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("🔥", fontSize = 28.sp)
                                Spacer(Modifier.width(12.dp))
                                Column {
                                    Text(if (streak > 0) "$streak-week streak" else "This week", fontWeight = FontWeight.ExtraBold)
                                    Text("${fmt(week)} cleaned this week", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                    }
                }
                if ("smart" in AppConfig.features) {
                    val smart = vm.smartPaths()
                    val all = (r.junk + r.duplicates.flatten()).associateBy { it.path }
                    val bytes = smart.sumOf { all[it]?.size ?: 0L }
                    if (smart.isNotEmpty()) {
                        Spacer(Modifier.height(12.dp))
                        GradientCard(CleanGradient, Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(18.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("✨", fontSize = 26.sp)
                                    Spacer(Modifier.width(8.dp))
                                    Text("Smart clean", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
                                }
                                Spacer(Modifier.height(6.dp))
                                Text("${smart.size} safe files · ${fmt(bytes)}: junk and extra copies. One copy of every file stays. You see the list before anything moves.", color = Color.White.copy(alpha = 0.95f), fontSize = 14.sp)
                                Spacer(Modifier.height(12.dp))
                                Button(
                                    onClick = onSmartClean,
                                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color(0xFF00897B)),
                                    modifier = Modifier.fillMaxWidth().height(50.dp),
                                ) { Text("Clean ${fmt(bytes)} now", fontWeight = FontWeight.Bold, fontSize = 16.sp) }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                SectionTitle("Easy wins", Teal)
                Spacer(Modifier.height(6.dp))
                val dupWaste = r.duplicates.sumOf { it[0].size * (it.size - 1) }
                Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(10.dp)) {
                    WinTile("🧹", "Junk files", r.junk.sumOf { it.size }, Teal, Modifier.weight(1f))
                    WinTile("👯", "Duplicate copies", dupWaste, Violet, Modifier.weight(1f))
                    WinTile("🐘", "Large files", r.large.sumOf { it.size }, Orange, Modifier.weight(1f))
                }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.fillMaxWidth(), Arrangement.spacedBy(10.dp)) {
                    WinTile("💬", "WhatsApp media", r.whatsapp.sumOf { it.size }, Green, Modifier.weight(1f))
                    WinTile("⬇️", "Old downloads", r.downloads.sumOf { it.size }, Sky, Modifier.weight(1f))
                    WinTile("📱", "Screenshots", r.screenshots.sumOf { it.size }, Pink, Modifier.weight(1f))
                }
                if (vm.freedTotal > 0) {
                    Spacer(Modifier.height(12.dp))
                    GradientCard(Brush.linearGradient(listOf(Color(0xFFFF9248), Color(0xFFFF4F81))), Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("🎉", fontSize = 28.sp)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text("Freed so far with this app", color = Color.White.copy(alpha = 0.9f), fontSize = 13.sp)
                                Text(fmt(vm.freedTotal), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
                SectionTitle("What's taking space", Indigo)
                Spacer(Modifier.height(4.dp))
            }
            val max = r.byCategory.values.maxOrNull()?.coerceAtLeast(1) ?: 1
            items(r.byCategory.entries.sortedByDescending { it.value }.toList()) { (cat, bytes) ->
                val c = categoryColor(cat)
                SoftCard(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        EmojiBadge(categoryEmoji(cat), c, 44)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) {
                                Text(cat.label, fontWeight = FontWeight.SemiBold)
                                Text(fmt(bytes), color = c, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(6.dp))
                            ColorBar(bytes.toFloat() / max, c, Modifier.fillMaxWidth())
                        }
                    }
                }
            }
            item {
                Spacer(Modifier.height(12.dp))
                OutlinedButton(onClick = { vm.scan() }, Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(50)) { Text("🔄  Scan again", fontWeight = FontWeight.SemiBold) }
            }
        }
    }

    /** A hint line with an optional action button on the right, tinted with the tab's color. */
    @Composable
    private fun HintBar(hint: String, color: Color, action: String? = null, onAction: () -> Unit = {}) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).clip(RoundedCornerShape(16.dp)).background(color.copy(alpha = 0.12f)).padding(start = 14.dp, end = 6.dp, top = 6.dp, bottom = 6.dp),
            Arrangement.SpaceBetween, Alignment.CenterVertically,
        ) {
            Text(hint, Modifier.weight(1f), style = MaterialTheme.typography.bodySmall)
            if (action != null) TextButton(onClick = onAction) { Text(action, color = color, fontWeight = FontWeight.Bold) }
        }
    }

    @Composable
    private fun LargeTab(r: ScanResult) {
        if (r.large.isEmpty()) return Empty("🐘", "No files over 50 MB. Nice.")
        FileList(r.large)
    }

    @Composable
    private fun JunkTab(r: ScanResult) {
        if (r.junk.isEmpty()) return Empty("✨", "No junk found.")
        Column {
            HintBar("Temp files, logs, old installers, empty files", Teal, "Select all") { vm.selectAll(r.junk.map { it.path }) }
            FileList(r.junk, hint = false)
        }
    }

    @Composable
    private fun SafetyTab(r: ScanResult) {
        val ctx = LocalContext.current
        val apkCount = r.junk.count { it.name.endsWith(".apk", ignoreCase = true) }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
            item {
                Column {
                    HintBar(
                        "This is a simple check, not an antivirus. It cannot find viruses, but it points out " +
                            "apps worth a second look. It works offline. A flagged app is not necessarily harmful.",
                        Red,
                    )
                    if (apkCount > 0) HintBar("$apkCount installer (.apk) files in storage. Only install files from sources you trust.", Orange)
                }
            }
            if (vm.safety.isEmpty()) item { Box(Modifier.fillMaxWidth().padding(32.dp), Alignment.Center) { Text("✅  No apps need a second look.") } }
            items(vm.safety, key = { it.pkg }) { a ->
                val c = when (a.level) { 2 -> Red; 1 -> Orange; else -> Green }
                SoftCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                            Text(a.name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Pill(when (a.level) { 2 -> "High"; 1 -> "Medium"; else -> "Low" }, c)
                        }
                        Spacer(Modifier.height(4.dp))
                        a.reasons.forEach { Text("• $it", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                        Row {
                            TextButton(onClick = {
                                safeStart(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")))
                            }) { Text("App info") }
                            TextButton(onClick = {
                                safeStart(ctx, Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
                            }) { Text("Uninstall", color = Red) }
                        }
                    }
                }
            }
        }
    }

    /** Starts a screen; shows a message instead of crashing when the phone has nothing to handle it. */
    private fun safeStart(ctx: android.content.Context, i: Intent) {
        try { ctx.startActivity(i) } catch (e: Exception) {
            android.widget.Toast.makeText(ctx, "This phone cannot open that screen.", android.widget.Toast.LENGTH_LONG).show()
        }
    }

    /** Opens the Gmail app with the search. Falls back to the Gmail app's home screen, then to a browser. Never crashes. */
    private fun openGmailSearch(ctx: android.content.Context, query: String) {
        val gmail = "com.google.android.gm"
        // 1. Gmail app, straight into the search
        try {
            val i = Intent(Intent.ACTION_SEARCH).setPackage(gmail)
                .putExtra(android.app.SearchManager.QUERY, query)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(i)
            return
        } catch (e: Exception) {
            // not supported by this Gmail version
        }
        // 2. Gmail app home, with the search words copied so they can be pasted into the search box
        try {
            val gm = ctx.packageManager.getLaunchIntentForPackage(gmail)
            if (gm != null) {
                val cm = ctx.getSystemService(android.content.Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                cm.setPrimaryClip(android.content.ClipData.newPlainText("Gmail search", query))
                ctx.startActivity(gm)
                android.widget.Toast.makeText(ctx, "Paste this in Gmail search: $query", android.widget.Toast.LENGTH_LONG).show()
                return
            }
        } catch (e: Exception) {
            // fall through
        }
        // 3. No Gmail app: use a browser
        try {
            val url = "https://mail.google.com/mail/u/0/#search/" + Uri.encode(query)
            ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addCategory(Intent.CATEGORY_BROWSABLE))
            return
        } catch (e: Exception) {
            // fall through
        }
        android.widget.Toast.makeText(ctx, "Could not open Gmail. Install the Gmail app.", android.widget.Toast.LENGTH_LONG).show()
    }

    @Composable
    private fun EmailTab() {
        val ctx = LocalContext.current
        val searches = listOf(
            Triple("Emails over 10 MB", "larger:10M", "🐘"),
            Triple("Attachments older than 1 year", "has:attachment older_than:1y", "📎"),
            Triple("Promotions", "category:promotions", "🏷️"),
            Triple("Social", "category:social", "👥"),
            Triple("Spam", "in:spam", "🚫"),
            Triple("Trash", "in:trash", "🗑️"),
        )
        val colors = listOf(Orange, Violet, Pink, Sky, Red, Color(0xFF64748B))
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
            item {
                Column {
                    HintBar(
                        "Opens the Gmail app with a ready-made search. Tick the select-all box, then tap Delete. " +
                            "Empty Spam and Trash afterwards to really free space.",
                        Orange,
                    )
                    HintBar(
                        "This frees space in your Google account (the 15 GB shared by Gmail, Drive and Photos), " +
                            "not on the phone itself. It needs internet and the Gmail app. The rest of this app stays offline.",
                        Sky,
                    )
                    Spacer(Modifier.height(6.dp))
                }
            }
            items(searches.size) { i ->
                val (label, query, emoji) = searches[i]
                SoftCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp).clickable { openGmailSearch(ctx, query) }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        EmojiBadge(emoji, colors[i % colors.size], 42)
                        Spacer(Modifier.width(12.dp))
                        Text(label, Modifier.weight(1f), fontWeight = FontWeight.SemiBold)
                        Text("›", fontSize = 24.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }
    }

    @Composable
    private fun SimpleTab(files: List<FileItem>, hint: String, empty: String) {
        if (files.isEmpty()) return Empty("🎈", empty)
        Column {
            HintBar(hint, Sky, "Select all") { vm.selectAll(files.map { it.path }) }
            FileList(files, hint = false)
        }
    }

    @Composable
    private fun WhatsAppTab(r: ScanResult) {
        if (r.whatsapp.isEmpty()) return Empty("💬", "No WhatsApp media found.")
        val groups = r.whatsapp.groupBy { it.waGroup }.entries.sortedByDescending { e -> e.value.sumOf { it.size } }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
            item { HintBar("Deleting here removes media from this phone only. Files you sent are not selected automatically.", Green) }
            groups.forEach { (name, files) ->
                item(key = "h-$name") {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 12.dp),
                        Arrangement.SpaceBetween, Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(name, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            Text("${files.size} files · ${fmt(files.sumOf { it.size })}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        TextButton(onClick = { vm.selectAll(files.filter { !it.isSent }.map { it.path }) }) {
                            Text("Select received", color = Green, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                items(files, key = { it.path }) { FileRow(it) }
            }
        }
    }

    @Composable
    private fun DuplicatesTab(r: ScanResult) {
        if (r.duplicates.isEmpty()) return Empty("👯", "No duplicates found.")
        Column {
            HintBar("The oldest copy in each group is kept", Violet, "Select extras") { vm.selectAll(r.duplicates.flatMap { it.drop(1) }.map { it.path }) }
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                r.duplicates.forEach { group ->
                    item {
                        Row(Modifier.padding(16.dp, 12.dp, 16.dp, 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            Pill("${group.size} copies", Violet)
                            Spacer(Modifier.width(8.dp))
                            Text("${fmt(group[0].size * (group.size - 1))} wasted", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                    items(group, key = { it.path }) { FileRow(it) }
                }
            }
        }
    }

    @Composable
    private fun SimilarTab() {
        LaunchedEffect(Unit) { vm.loadSimilar() }
        val groups = vm.similar
        if (groups == null || vm.similarBusy) {
            Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                CircularProgressIndicator(color = Pink)
                Spacer(Modifier.height(14.dp))
                Text(vm.similarProgress.ifEmpty { "Looking for similar photos…" }, fontWeight = FontWeight.SemiBold)
                Text("This can take a minute. It all happens on your phone.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            return
        }
        if (groups.isEmpty()) return Empty("🖼️", "No similar photos found.")
        Column {
            HintBar("The biggest (best quality) photo in each group is kept. Tap a photo to compare.", Pink, "Select extras") { vm.selectAll(groups.flatMap { it.drop(1) }.map { it.path }) }
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
                groups.forEach { group ->
                    item(key = "sg-" + group[0].path) {
                        Row(Modifier.padding(16.dp, 12.dp, 16.dp, 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            Pill("${group.size} similar", Pink)
                            Spacer(Modifier.width(8.dp))
                            Text("${fmt(group.drop(1).sumOf { it.size })} could be freed", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                    items(group, key = { "s-" + it.path }) { FileRow(it) }
                }
            }
        }
    }

    @Composable
    private fun FileList(files: List<FileItem>, hint: Boolean = true) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 4.dp, bottom = 16.dp)) {
            if (hint) item(key = "hint") { HintBar("Tap a file to look at it before you delete.", Orange) }
            items(files, key = { it.path }) { FileRow(it) }
        }
    }

    @Composable
    private fun FileRow(f: FileItem) {
        val checked = f.path in vm.selected
        val c = fileColor(f.name)
        val bg = if (checked) c.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceVariant
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp).clip(RoundedCornerShape(18.dp)).background(bg)
                .clickable { vm.preview = f }.padding(start = 12.dp, end = 4.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            EmojiBadge(fileEmoji(f.name), c, 42)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(f.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${f.folder} · ${DateFormat.getDateInstance().format(Date(f.modified))}",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Pill(fmt(f.size), c)
            Checkbox(checked = checked, onCheckedChange = { vm.toggle(f.path) }, colors = CheckboxDefaults.colors(checkedColor = c))
        }
    }

    @Composable
    private fun AppsTab() {
        if (!usageOk) {
            Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                Text("🧩", fontSize = 48.sp)
                Spacer(Modifier.height(12.dp))
                Text("To see how much space each app uses, allow Usage access for this app.", textAlign = TextAlign.Center)
                Spacer(Modifier.height(16.dp))
                Button(onClick = { requestUsage() }, shape = RoundedCornerShape(50)) { Text("Open settings") }
            }
            return
        }
        if (vm.apps.isEmpty()) return Empty("🧩", "No app data yet.")
        val ctx = LocalContext.current
        val max = vm.apps.maxOfOrNull { it.bytes }?.coerceAtLeast(1) ?: 1
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 4.dp, bottom = 16.dp)) {
            items(vm.apps, key = { it.pkg }) { a ->
                SoftCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                            Text(a.name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(fmt(a.bytes), color = Indigo, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(6.dp))
                        ColorBar(a.bytes.toFloat() / max, Indigo, Modifier.fillMaxWidth())
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Cache ${fmt(a.cache)}", Modifier.weight(1f), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            TextButton(onClick = {
                                safeStart(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${a.pkg}")))
                            }) { Text("Clear cache") }
                            TextButton(onClick = {
                                safeStart(ctx, Intent(Intent.ACTION_DELETE, Uri.parse("package:${a.pkg}")))
                            }) { Text("Uninstall", color = Red) }
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun BinTab() {
        var look by remember { mutableStateOf<TrashItem?>(null) }
        var emptyAsk by remember { mutableStateOf(false) }
        val items = vm.bin
        if (items.isEmpty()) return Empty("🗑️", "The Bin is empty. Deleted files wait here for ${AppConfig.binDays} days.")
        Column {
            HintBar(
                "${items.size} files · ${fmt(items.sumOf { it.size })}. Removed for good after ${AppConfig.binDays} days.",
                Color(0xFF64748B), "Empty Bin",
            ) { emptyAsk = true }
            LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 4.dp, bottom = 16.dp)) {
                items(items, key = { it.id }) { t ->
                    val c = fileColor(t.name)
                    val daysLeft = (AppConfig.binDays - (System.currentTimeMillis() - t.deleted) / 86_400_000L).coerceAtLeast(0)
                    SoftCard(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)) {
                        Column(Modifier.padding(14.dp)) {
                            Row(Modifier.fillMaxWidth().clickable { look = t }, verticalAlignment = Alignment.CenterVertically) {
                                EmojiBadge(fileEmoji(t.name), c, 42)
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(t.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(
                                        t.original.substringBeforeLast('/').substringAfter("/storage/emulated/0"),
                                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis,
                                    )
                                }
                                Spacer(Modifier.width(8.dp))
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(fmt(t.size), fontWeight = FontWeight.Bold, color = c)
                                    Pill("$daysLeft days left", if (daysLeft <= 1) Red else Teal)
                                }
                            }
                            Row {
                                TextButton(onClick = { vm.restore(t.id) }) { Text("↩ Restore", color = Teal, fontWeight = FontWeight.Bold) }
                                TextButton(onClick = { vm.deleteForever(setOf(t.id)) }) { Text("Delete for good", color = Red) }
                            }
                        }
                    }
                }
            }
        }
        look?.let { t ->
            FilePreview(FileItem(t.stored, t.size, t.deleted), marked = false, onToggleMark = null, onClose = { look = null }, title = t.name)
        }
        if (emptyAsk) {
            AlertDialog(
                shape = RoundedCornerShape(24.dp),
                onDismissRequest = { emptyAsk = false },
                title = { Text("Empty the Bin?", fontWeight = FontWeight.Bold) },
                text = { Text("${items.size} files (${fmt(items.sumOf { it.size })}) will be removed for good.") },
                confirmButton = { Button(onClick = { emptyAsk = false; vm.deleteForever(items.map { it.id }.toSet()) }, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Empty Bin") } },
                dismissButton = { TextButton(onClick = { emptyAsk = false }) { Text("Cancel") } },
            )
        }
    }

    @Composable
    private fun DeleteBar(onDelete: () -> Unit) {
        Surface(tonalElevation = 8.dp, shadowElevation = 12.dp, shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)) {
            Row(Modifier.fillMaxWidth().padding(12.dp), Arrangement.spacedBy(8.dp), Alignment.CenterVertically) {
                TextButton(onClick = { vm.clearSelection() }) { Text("Clear") }
                Box(Modifier.weight(1f))
                Button(
                    onClick = onDelete,
                    shape = RoundedCornerShape(50),
                    colors = ButtonDefaults.buttonColors(containerColor = Pink),
                    modifier = Modifier.height(48.dp),
                ) { Text("🧹 Clean ${vm.selected.size} · ${fmt(vm.selectedBytes)}", fontWeight = FontWeight.Bold) }
            }
        }
    }

    @Composable
    private fun Empty(emoji: String, text: String) {
        Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text(emoji, fontSize = 64.sp)
            Spacer(Modifier.height(12.dp))
            Text(text, textAlign = TextAlign.Center, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    private fun fmt(b: Long): String = Formatter.formatShortFileSize(this, b)
}

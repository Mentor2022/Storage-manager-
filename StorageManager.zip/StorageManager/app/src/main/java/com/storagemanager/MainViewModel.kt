package com.storagemanager

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.compose.runtime.mutableIntStateOf
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Where the compressor is right now. */
data class CompressRun(val index: Int, val total: Int, val name: String, val percent: Int)

/** What the last compress run did. [binIds] are the originals still waiting in the Bin. */
data class CompressDone(val count: Int, val saved: Long, val skipped: Int, val failed: Int, val binIds: List<String>)

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("stats", 0)

    var scanning by mutableStateOf(false); private set
    var progress by mutableStateOf("")
    var result by mutableStateOf<ScanResult?>(null); private set
    var apps by mutableStateOf<List<AppItem>>(emptyList()); private set
    var message by mutableStateOf<String?>(null)
    var safety by mutableStateOf<List<AppRisk>>(emptyList()); private set
    /** Total space this app has freed over time (kept on the phone). */
    var freedTotal by mutableStateOf(prefs.getLong("freed", 0L)); private set
    val selected = mutableStateListOf<String>()
    /** The file the person tapped to look at before deciding. */
    var preview by mutableStateOf<FileItem?>(null)

    /** Photos that look alike. null = not looked at yet. */
    var similar by mutableStateOf<List<List<FileItem>>?>(null); private set
    var similarBusy by mutableStateOf(false); private set
    var similarProgress by mutableStateOf("")

    fun loadSimilar(force: Boolean = false) {
        if (similarBusy || (similar != null && !force)) return
        viewModelScope.launch {
            similarBusy = true
            similar = withContext(Dispatchers.IO) {
                val t = Thread.currentThread()
                val old = t.priority
                t.priority = Thread.MIN_PRIORITY
                try { StorageScanner.findSimilarPhotos { similarProgress = it } } finally { t.priority = old }
            }
            similarBusy = false
        }
    }

    /** Files that are safe to clear in one go: junk and extra copies of exact duplicates. One copy of every file always stays. */
    fun smartPaths(): List<String> {
        val r = result ?: return emptyList()
        val set = LinkedHashSet<String>()
        r.junk.forEach { set += it.path }
        r.duplicates.forEach { g -> g.drop(1).forEach { set += it.path } }
        r.duplicates.forEach { g -> if (g.all { it.path in set }) set -= g[0].path }
        return set.toList()
    }

    var bin by mutableStateOf<List<TrashItem>>(emptyList()); private set
    val binOn: Boolean get() = "bin" in AppConfig.features

    fun refreshBin() {
        viewModelScope.launch {
            bin = withContext(Dispatchers.IO) {
                // originals left by the compressor or the auto-clean rules expire even when the Bin feature is off
                Stats.addFreed(app, Trash.purgeOld(AppConfig.binDays))
                Trash.list()
            }
            freedTotal = Stats.freed(app)
        }
    }

    private fun addFreed(bytes: Long) {
        if (bytes <= 0) return
        freedTotal = Stats.addFreed(app, bytes)
    }

    fun restore(id: String) {
        viewModelScope.launch {
            val was = bin.firstOrNull { it.id == id }
            val back = withContext(Dispatchers.IO) { Trash.restore(app, id) }
            if (back != null && was != null) History.record(app, -was.reclaim)
            message = if (back != null) "Restored to ${back.substringBeforeLast('/').substringAfter("/storage/emulated/0")}" else "Could not restore this file"
            refreshBin()
            scan()
        }
    }

    fun deleteForever(ids: Set<String>) {
        viewModelScope.launch {
            val freed = withContext(Dispatchers.IO) { Trash.removeForever(ids) }
            addFreed(freed)
            message = "Freed ${fmt(freed)}"
            refreshBin()
            val (total, free) = withContext(Dispatchers.IO) { StorageScanner.space() }
            result = result?.copy(total = total, free = free)
        }
    }

    fun fileFor(path: String): FileItem? = allFiles()[path]

    fun scan() {
        if (scanning) return
        viewModelScope.launch {
            scanning = true
            selected.clear()
            similar = null
            cands = null
            cSelected.clear()
            result = withContext(Dispatchers.IO) {
                // Run at low priority so the UI thread (and the spinner) always gets CPU first
                val t = Thread.currentThread()
                val old = t.priority
                t.priority = Thread.MIN_PRIORITY
                try { StorageScanner.scan { progress = it } } finally { t.priority = old }
            }
            apps = withContext(Dispatchers.IO) { AppUsage.load(app) }
            safety = withContext(Dispatchers.IO) { SafetyCheck.run(app) }
            scanning = false
        }
    }

    fun refreshApps() {
        viewModelScope.launch { apps = withContext(Dispatchers.IO) { AppUsage.load(app) } }
    }

    fun toggle(path: String) { if (path in selected) selected.remove(path) else selected.add(path) }

    fun selectAll(paths: List<String>) { paths.filter { it !in selected }.forEach { selected.add(it) } }

    fun clearSelection() = selected.clear()

    private fun allFiles(): Map<String, FileItem> {
        val r = result ?: return emptyMap()
        return (r.large + r.junk + r.duplicates.flatten() + r.whatsapp + r.downloads + r.screenshots + (similar?.flatten() ?: emptyList()))
            .distinctBy { it.path }
            .associateBy { it.path }
    }

    val selectedBytes: Long
        get() {
            val all = allFiles()
            return selected.sumOf { all[it]?.size ?: 0L }
        }

    fun deleteSelected() {
        val paths = selected.toList()
        val sizes = allFiles()
        val toBin = binOn
        viewModelScope.launch {
            val gone = withContext(Dispatchers.IO) { if (toBin) Trash.moveIn(app, paths) else StorageScanner.delete(app, paths) }
            val freed = gone.sumOf { sizes[it]?.size ?: 0L }
            selected.clear()
            History.record(app, freed)
            if (!toBin) addFreed(freed)
            val (total, free) = StorageScanner.space()
            result = result?.without(gone)?.copy(total = total, free = free)
            similar = similar?.map { g -> g.filterNot { it.path in gone } }?.filter { it.size > 1 }
            if (toBin) refreshBin()
            message = if (toBin && gone.size == paths.size) "Moved ${gone.size} to the Bin (${fmt(freed)}). Undo any time in the Bin tab for ${AppConfig.binDays} days."
            else if (gone.size == paths.size) "Freed ${fmt(freed)}"
            else "Deleted ${gone.size} of ${paths.size} files (some could not be removed)"
        }
    }

    // ───────────── photo and video compressor ─────────────

    /** Photos and videos that can be made smaller. null = not looked at yet. */
    var cands by mutableStateOf<List<MediaCand>?>(null); private set
    var candsBusy by mutableStateOf(false); private set
    var candsProgress by mutableStateOf("")
    var level by mutableStateOf(Level.BALANCED)
    val cSelected = mutableStateListOf<String>()
    var cRun by mutableStateOf<CompressRun?>(null); private set
    var cDone by mutableStateOf<CompressDone?>(null)
    private var cJob: Job? = null

    fun loadCands(force: Boolean = false) {
        if (candsBusy || cRun != null || (cands != null && !force)) return
        viewModelScope.launch {
            candsBusy = true
            cands = withContext(Dispatchers.IO) {
                val t = Thread.currentThread()
                val old = t.priority
                t.priority = Thread.MIN_PRIORITY
                try { Compressor.find(app) { candsProgress = it } } finally { t.priority = old }
            }
            candsBusy = false
        }
    }

    fun compress() {
        if (cRun != null) return
        val list = (cands ?: return).filter { it.path in cSelected }
        if (list.isEmpty()) return
        val lv = level
        cDone = null
        cJob = viewModelScope.launch {
            var saved = 0L; var count = 0; var skipped = 0; var failed = 0
            val ids = ArrayList<String>()
            try {
                for ((i, c) in list.withIndex()) {
                    cRun = CompressRun(i, list.size, c.name, 0)
                    val tmp = Compressor.tempFile(app, c)
                    val ok = try {
                        if (c.isVideo) Compressor.video(app, c, lv, tmp) { p -> cRun = CompressRun(i, list.size, c.name, p) }
                        else withContext(Dispatchers.IO) { Compressor.photo(c, lv, tmp) }
                    } catch (e: CancellationException) {
                        tmp.delete(); throw e
                    } catch (e: Throwable) { false }
                    if (!ok) { tmp.delete(); failed++; continue }
                    when (val o = withContext(Dispatchers.IO) { Compressor.replace(app, c, tmp) }) {
                        is Compressor.Outcome.Saved -> {
                            count++
                            saved += o.before - o.after
                            o.binId?.let { ids += it }
                            History.record(app, o.before - o.after)
                        }
                        Compressor.Outcome.Skipped -> skipped++
                        Compressor.Outcome.Failed -> failed++
                    }
                }
            } finally {
                cRun = null
                cSelected.clear()
                if (count + skipped + failed > 0) cDone = CompressDone(count, saved, skipped, failed, ids)
                refreshBin()
                scan()
            }
        }
    }

    fun cancelCompress() { cJob?.cancel() }

    /** Removes the originals kept in the Bin after compressing, so the space comes back now. */
    fun freeOriginalsNow() {
        val d = cDone ?: return
        cDone = d.copy(binIds = emptyList())
        if (d.binIds.isNotEmpty()) deleteForever(d.binIds.toSet())
    }

    // ───────────── auto-clean rules ─────────────

    var rulesFound by mutableStateOf<Map<String, List<FileItem>>?>(null); private set
    var rulesBusy by mutableStateOf(false); private set
    /** Goes up whenever a rule is changed so the screen reads the settings again. */
    var rulesTick by mutableIntStateOf(0); private set

    fun checkRules() {
        if (rulesBusy) return
        viewModelScope.launch {
            rulesBusy = true
            rulesFound = withContext(Dispatchers.IO) { Rules.collect(app, Rules.all.map { it.id }) }
            rulesBusy = false
        }
    }

    fun setRule(id: String, s: RuleSetting) {
        Rules.put(app, id, s)
        rulesTick++
        rulesFound = null
    }

    fun runRulesNow() {
        if (rulesBusy) return
        viewModelScope.launch {
            rulesBusy = true
            val r = withContext(Dispatchers.IO) { Rules.run(app, force = true) }
            rulesBusy = false
            rulesFound = null
            rulesTick++
            if (r.files == 0) message = "Nothing to clean right now."
            else {
                message = "Moved ${r.files} files (${fmt(r.bytes)}) to the Bin. Undo any time in the Bin tab for ${AppConfig.binDays} days."
                refreshBin()
                scan()
            }
        }
    }

    private fun fmt(b: Long) = android.text.format.Formatter.formatShortFileSize(app, b)
}

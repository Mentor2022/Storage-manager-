package com.storagemanager

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(private val app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("stats", 0)

    var scanning by mutableStateOf(false); private set
    var progress by mutableStateOf("")
    var result by mutableStateOf<ScanResult?>(null); private set
    var apps by mutableStateOf<List<AppItem>>(emptyList()); private set
    var message by mutableStateOf<String?>(null)
    var safety by mutableStateOf<List<AppRisk>>(emptyList()); private set
    /** Total space this app has freed over time (kept on the phone). */
    var freedTotal by mutableStateOf(prefs.getLong("freed", 0L)); private set
    val selected = mutableStateListOf<String>()

    fun scan() {
        if (scanning) return
        viewModelScope.launch {
            scanning = true
            selected.clear()
            result = withContext(Dispatchers.IO) {
                // Run at low priority so the UI thread (and the spinner) always gets CPU first
                val t = Thread.currentThread()
                val old = t.priority
                t.priority = Thread.MIN_PRIORITY
                try { StorageScanner.scan { progress = it } } finally { t.priority = old }
            }
            apps = withContext(Dispatchers.IO) { AppUsage.load(app) }
            safety = withContext(Dispatchers.IO) { SafetyCheck.run(app) }
            scanning = false
        }
    }

    fun refreshApps() {
        viewModelScope.launch { apps = withContext(Dispatchers.IO) { AppUsage.load(app) } }
    }

    fun toggle(path: String) { if (path in selected) selected.remove(path) else selected.add(path) }

    fun selectAll(paths: List<String>) { paths.filter { it !in selected }.forEach { selected.add(it) } }

    fun clearSelection() = selected.clear()

    private fun allFiles(): Map<String, FileItem> {
        val r = result ?: return emptyMap()
        return (r.large + r.junk + r.duplicates.flatten() + r.whatsapp + r.downloads + r.screenshots)
            .distinctBy { it.path }
            .associateBy { it.path }
    }

    val selectedBytes: Long
        get() {
            val all = allFiles()
            return selected.sumOf { all[it]?.size ?: 0L }
        }

    fun deleteSelected() {
        val paths = selected.toList()
        val sizes = allFiles()
        viewModelScope.launch {
            val gone = withContext(Dispatchers.IO) { StorageScanner.delete(app, paths) }
            val freed = gone.sumOf { sizes[it]?.size ?: 0L }
            selected.clear()
            if (freed > 0) {
                freedTotal += freed
                prefs.edit().putLong("freed", freedTotal).apply()
            }
            val (total, free) = StorageScanner.space()
            result = result?.without(gone)?.copy(total = total, free = free)
            message = if (gone.size == paths.size) "Freed ${fmt(freed)}"
            else "Deleted ${gone.size} of ${paths.size} files (some could not be removed)"
        }
    }

    private fun fmt(b: Long) = android.text.format.Formatter.formatShortFileSize(app, b)
}

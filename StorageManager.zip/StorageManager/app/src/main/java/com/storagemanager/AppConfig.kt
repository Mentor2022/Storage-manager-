package com.storagemanager

import android.content.Context
import org.json.JSONObject

/**
 * Settings chosen by the admin in the portal. The build writes them to assets/config.json.
 * Without that file (a plain build), everything is on.
 */
object AppConfig {
    private val allFeatures = setOf("large", "duplicates", "junk", "whatsapp", "downloads", "screenshots", "safety", "email", "apps", "bin", "similar", "smart", "compress", "report", "rules")

    @Volatile var features: Set<String> = allFeatures
    @Volatile var reminderOn: Boolean = true
    @Volatile var reminderBelow: Int = 10
    /** How many days deleted files wait in the recycle bin. */
    @Volatile var binDays: Int = 7

    /** The Bin tab also shows when features that put originals in the Bin are on. */
    val binVisible: Boolean get() = "bin" in features || "compress" in features || "rules" in features

    fun load(ctx: Context) {
        try {
            val j = JSONObject(ctx.assets.open("config.json").bufferedReader().use { it.readText() })
            val f = j.optJSONObject("features")
            if (f != null) features = allFeatures.filter { f.optBoolean(it, true) }.toSet()
            j.optJSONObject("bin")?.let { binDays = it.optInt("days", 7).coerceIn(1, 60) }
            val r = j.optJSONObject("reminder")
            if (r != null) {
                reminderOn = r.optBoolean("on", true)
                reminderBelow = r.optInt("below", 10).coerceIn(1, 50)
            }
        } catch (e: Exception) {
            // no config: keep the defaults
        }
    }
}

# Storage Manager

An offline Android app that helps people free up space when their phone is full.
It never uses the internet and never uploads anything.

## What it does
- **Overview**: used and free space, plus a breakdown by photos, videos, audio, documents, installers and other.
- **Large files**: everything over 50 MB, biggest first.
- **Duplicates**: exact copies (same size, then same SHA-256). The oldest copy is kept, and the rest can be selected in one tap.
- **Junk**: temp and log files, thumbnails, old APK installers, empty files.
- **Apps**: size of each app (app + data + cache), with shortcuts to clear cache or uninstall.

## Build
1. Open this folder in Android Studio (Koala or newer). It will download Gradle and generate the wrapper.
2. Run on a device or emulator (Android 7.0 / API 24 and up).
3. Release APK: **Build > Generate Signed App Bundle / APK**.

## Permissions
| Permission | Why |
|---|---|
| All files access (Android 11+) / Storage (Android 10 and below) | Scan and delete files |
| Usage access | Read per-app storage sizes |
| Query all packages | List installed apps |

Note: Google Play restricts All files access and Query all packages. For Play Store release you must
complete the permission declaration form. Sideloading the APK (common for sharing in WhatsApp groups
or from a website) has no such restriction.

## Limits
- Android 11+ blocks every app from `Android/data` and `Android/obb`, so app-private files there are skipped. Use the Apps tab to clear an app's cache.
- Scanning a phone with 100k+ files can take about a minute.

## Ideas for next steps
- Compress or move old photos and videos to a memory card
- WhatsApp media cleaner (the folder is under `Android/media`, which is scannable)
- Scheduled reminder when free space drops under 10%

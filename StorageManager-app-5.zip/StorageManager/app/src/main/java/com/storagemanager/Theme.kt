package com.storagemanager

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** The colours used all over the app. */
object Pal {
    val teal = Color(0xFF00897B)
    val blue = Color(0xFF2979FF)
    val purple = Color(0xFF7C4DFF)
    val pink = Color(0xFFEC407A)
    val orange = Color(0xFFFF7043)
    val amber = Color(0xFFFFA000)
    val green = Color(0xFF43A047)
    val red = Color(0xFFE53935)
    val grey = Color(0xFF78909C)
}

private val LightColors = lightColorScheme(
    primary = Color(0xFF00897B), onPrimary = Color.White,
    primaryContainer = Color(0xFFB9F2EA), onPrimaryContainer = Color(0xFF00201C),
    secondary = Color(0xFFFF7043), onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFDBCF), onSecondaryContainer = Color(0xFF3A0B00),
    tertiary = Color(0xFF7C4DFF), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFE8DEFF), onTertiaryContainer = Color(0xFF21005D),
    background = Color(0xFFF3FAF9), surface = Color(0xFFF3FAF9),
    surfaceVariant = Color(0xFFDCE9E6),
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF4DD0C1), onPrimary = Color(0xFF00201C),
    primaryContainer = Color(0xFF00504A), onPrimaryContainer = Color(0xFFB9F2EA),
    secondary = Color(0xFFFFAB91), onSecondary = Color(0xFF3A0B00),
    secondaryContainer = Color(0xFF7A2E14), onSecondaryContainer = Color(0xFFFFDBCF),
    tertiary = Color(0xFFCFBCFF), onTertiary = Color(0xFF381E72),
    tertiaryContainer = Color(0xFF4F3B8F), onTertiaryContainer = Color(0xFFE8DEFF),
    background = Color(0xFF0E1514), surface = Color(0xFF0E1514),
    surfaceVariant = Color(0xFF2A3634),
)

@Composable
fun StorageTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = if (isSystemInDarkTheme()) DarkColors else LightColors, content = content)
}

fun catColor(c: Category): Color = when (c) {
    Category.IMAGES -> Pal.pink
    Category.VIDEO -> Pal.purple
    Category.AUDIO -> Pal.blue
    Category.DOCS -> Pal.amber
    Category.APK -> Pal.green
    Category.OTHER -> Pal.grey
}

fun catEmoji(c: Category): String = when (c) {
    Category.IMAGES -> "🖼️"
    Category.VIDEO -> "🎬"
    Category.AUDIO -> "🎵"
    Category.DOCS -> "📄"
    Category.APK -> "📦"
    Category.OTHER -> "📁"
}

fun tabEmoji(key: String): String = when (key) {
    "overview" -> "🏠"
    "large" -> "📦"
    "duplicates" -> "👯"
    "similar" -> "🖼️"
    "junk" -> "🧹"
    "whatsapp" -> "💬"
    "downloads" -> "⬇️"
    "screenshots" -> "📸"
    "safety" -> "🛡️"
    "email" -> "✉️"
    "apps" -> "📱"
    "bin" -> "🗑️"
    "battery" -> "🔋"
    else -> "•"
}

/** A small emoji and colour that tell at a glance what kind of file this is. */
fun fileLook(name: String): Pair<String, Color> = when (name.substringAfterLast('.', "").lowercase()) {
    "jpg", "jpeg", "png", "webp", "gif", "bmp", "heic" -> "🖼️" to Pal.pink
    "mp4", "mkv", "3gp", "avi", "mov", "webm" -> "🎬" to Pal.purple
    "mp3", "m4a", "aac", "wav", "ogg", "opus", "amr", "flac" -> "🎵" to Pal.blue
    "pdf" -> "📕" to Pal.red
    "doc", "docx", "txt", "epub" -> "📄" to Pal.blue
    "xls", "xlsx", "csv" -> "📊" to Pal.green
    "ppt", "pptx" -> "📙" to Pal.orange
    "apk" -> "📦" to Pal.green
    "zip", "rar", "7z" -> "🗜️" to Pal.amber
    else -> "📁" to Pal.grey
}

/** A ring that fills up to [fraction]. */
@Composable
fun StorageRing(fraction: Float, diameter: Dp, track: Color, color: Color, stroke: Dp = 14.dp, content: @Composable () -> Unit) {
    Box(Modifier.size(diameter), Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val w = stroke.toPx()
            val box = Size(this.size.width - w, this.size.height - w)
            val corner = Offset(w / 2, w / 2)
            drawArc(track, 0f, 360f, false, corner, box, style = Stroke(w, cap = StrokeCap.Round))
            drawArc(color, -90f, 360f * fraction.coerceIn(0.01f, 1f), false, corner, box, style = Stroke(w, cap = StrokeCap.Round))
        }
        content()
    }
}

/**
 * The waiting screen: a glowing ring with a bright sweeping tail, a slower ring turning the other way,
 * a breathing icon in the middle and three bouncing dots. [detail] is the live progress line.
 */
@Composable
fun FancyLoader(
    emoji: String,
    title: String,
    subtitle: String? = null,
    detail: String? = null,
    colors: List<Color> = listOf(Pal.teal, Pal.blue, Pal.purple),
) {
    val t = rememberInfiniteTransition(label = "loader")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(1500, easing = LinearEasing)), label = "spin")
    val spin2 by t.animateFloat(360f, 0f, infiniteRepeatable(tween(3200, easing = LinearEasing)), label = "spin2")
    val pulse by t.animateFloat(0.9f, 1.1f, infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse")
    val glow by t.animateFloat(0.08f, 0.26f, infiniteRepeatable(tween(1100, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "glow")
    val dot0 by t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(600), RepeatMode.Reverse, StartOffset(0)), label = "d0")
    val dot1 by t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(600), RepeatMode.Reverse, StartOffset(200)), label = "d1")
    val dot2 by t.animateFloat(0.25f, 1f, infiniteRepeatable(tween(600), RepeatMode.Reverse, StartOffset(400)), label = "d2")
    val track = MaterialTheme.colorScheme.surfaceVariant
    val c0 = colors[0]
    val c1 = colors.getOrElse(1) { colors[0] }
    val c2 = colors.getOrElse(2) { colors[0] }

    Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Box(Modifier.size(160.dp), Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val w = 11.dp.toPx()
                val topLeft = Offset(w / 2, w / 2)
                val box = Size(size.width - w, size.height - w)
                // soft breathing glow behind everything
                drawCircle(Brush.radialGradient(listOf(c1.copy(alpha = glow), Color.Transparent)), radius = size.minDimension / 2)
                drawArc(track, 0f, 360f, false, topLeft, box, style = Stroke(w))
                // main ring: a sweep that fades in from transparent to a bright head
                rotate(spin) {
                    drawArc(
                        Brush.sweepGradient(0f to Color.Transparent, 0.2f to c0, 0.5f to c1, 0.75f to c2, 1f to c2),
                        0f, 270f, false, topLeft, box, style = Stroke(w, cap = StrokeCap.Round),
                    )
                }
                // slower inner ring turning the other way
                val inset = 20.dp.toPx()
                val inner = Size(size.width - inset * 2, size.height - inset * 2)
                rotate(spin2) {
                    drawArc(c1.copy(alpha = 0.55f), 0f, 80f, false, Offset(inset, inset), inner, style = Stroke(4.dp.toPx(), cap = StrokeCap.Round))
                    drawArc(c2.copy(alpha = 0.40f), 180f, 45f, false, Offset(inset, inset), inner, style = Stroke(4.dp.toPx(), cap = StrokeCap.Round))
                }
            }
            Text(emoji, fontSize = 44.sp, modifier = Modifier.scale(pulse))
        }
        Spacer(Modifier.height(26.dp))
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(Modifier.size(8.dp).alpha(dot0).clip(CircleShape).background(c0))
            Box(Modifier.size(8.dp).alpha(dot1).clip(CircleShape).background(c1))
            Box(Modifier.size(8.dp).alpha(dot2).clip(CircleShape).background(c2))
        }
        if (!subtitle.isNullOrBlank()) {
            Spacer(Modifier.height(14.dp))
            Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
        }
        if (!detail.isNullOrBlank()) {
            Spacer(Modifier.height(14.dp))
            Box(Modifier.clip(RoundedCornerShape(50)).background(c0.copy(alpha = 0.12f)).padding(horizontal = 14.dp, vertical = 6.dp)) {
                Text(detail, style = MaterialTheme.typography.labelLarge, color = c0, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

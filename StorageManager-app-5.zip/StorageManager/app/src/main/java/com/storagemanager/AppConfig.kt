package com.storagemanager

import android.content.Context
import org.json.JSONObject

/**
 * Settings chosen by the admin in the portal. The build writes them to assets/config.json.
 * Without that file (a plain build), everything is on.
 */
object AppConfig {
    private val allFeatures = setOf("large", "duplicates", "junk", "whatsapp", "downloads", "screenshots", "safety", "email", "apps", "bin", "similar", "smart", "battery")

    @Volatile var features: Set<String> = allFeatures
    @Volatile var reminderOn: Boolean = true
    @Volatile var reminderBelow: Int = 10
    /** How many days deleted files wait in the recycle bin. */
    @Volatile var binDays: Int = 7

    // Starting values for the battery alarms (the admin sets them in the portal; people can change them in the app)
    @Volatile var batAlarms = true
    @Volatile var batFull = true
    @Volatile var batLow = true
    @Volatile var batOver = true
    @Volatile var batLowPct = 20
    @Volatile var batOverMin = 15
    @Volatile var batSound = 2
    @Volatile var batMsgs: Map<String, String> = emptyMap()
    @Volatile var updateOn = false
    @Volatile var updateUrl = ""
    @Volatile private var loaded = false

    /** The alarm service can start after a reboot without the main screen, so it makes sure the settings are read. */
    fun ensureLoaded(ctx: Context) { if (!loaded) load(ctx.applicationContext) }

    fun load(ctx: Context) {
        loaded = true
        try {
            val j = JSONObject(ctx.assets.open("config.json").bufferedReader().use { it.readText() })
            val f = j.optJSONObject("features")
            if (f != null) features = allFeatures.filter { f.optBoolean(it, true) }.toSet()
            j.optJSONObject("bin")?.let { binDays = it.optInt("days", 7).coerceIn(1, 60) }
            j.optJSONObject("battery")?.let { b ->
                batAlarms = b.optBoolean("alarms", true)
                batFull = b.optBoolean("full", true); batLow = b.optBoolean("low", true); batOver = b.optBoolean("over", true)
                batLowPct = b.optInt("low_pct", 20).coerceIn(5, 50)
                batOverMin = b.optInt("over_min", 15).coerceIn(5, 120)
                batSound = b.optInt("sound", 2).coerceIn(0, 2)
                b.optJSONObject("msg")?.let { m ->
                    batMsgs = listOf("full", "low", "over", "hot").mapNotNull { k -> m.optString(k, "").takeIf { it.isNotBlank() }?.let { k to it } }.toMap()
                }
            }
            j.optJSONObject("update")?.let { u -> updateOn = u.optBoolean("on", false); updateUrl = u.optString("url", "") }
            val r = j.optJSONObject("reminder")
            if (r != null) {
                reminderOn = r.optBoolean("on", true)
                reminderBelow = r.optInt("below", 10).coerceIn(1, 50)
            }
        } catch (e: Exception) {
            // no config: keep the defaults
        }
    }
}

package com.storagemanager

import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.InetSocketAddress
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

/**
 * Talks to Gmail over IMAP (Gmail's standard mail connection) with the person's own address and app password.
 * Nothing goes through the admin's website. All functions block, so call them from a background thread.
 */
object GmailImap {
    class BadLogin : Exception("Gmail did not accept that address and code")
    private class ImapNo(msg: String) : IOException(msg)

    /** Mailbox names exactly as Gmail sent them, already quoted. They differ by phone language. */
    data class Folders(val all: String, val trash: String, val spam: String)

    const val MAX_IDS = 10_000
    private const val CHUNK = 300

    private fun q(s: String) = "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\""

    class Session(private val sock: SSLSocket) {
        private val input = BufferedReader(InputStreamReader(sock.inputStream, Charsets.ISO_8859_1))
        private val output = sock.outputStream
        private var n = 0

        init {
            val hello = input.readLine() ?: throw IOException("No answer from Gmail")
            if (!hello.startsWith("* OK")) throw IOException("Gmail refused the connection")
        }

        class Reply(val lines: List<String>, val status: String)

        fun cmd(text: String): Reply {
            val tag = "a${++n}"
            output.write("$tag $text\r\n".toByteArray(Charsets.ISO_8859_1))
            output.flush()
            val lines = ArrayList<String>()
            while (true) {
                val l = input.readLine() ?: throw IOException("Gmail closed the connection")
                if (l.startsWith("$tag ")) {
                    val st = l.substring(tag.length + 1)
                    if (!st.startsWith("OK")) throw ImapNo(st)
                    return Reply(lines, st)
                }
                lines += l
            }
        }

        fun login(user: String, pass: String) {
            try { cmd("LOGIN ${q(user)} ${q(pass)}") } catch (e: ImapNo) { throw BadLogin() }
        }

        fun logout() { try { cmd("LOGOUT") } catch (_: Exception) {} }

        fun folders(): Folders {
            var all = ""; var trash = ""; var spam = ""
            val rx = Regex("""^\* LIST \(([^)]*)\) (?:"[^"]*"|NIL) (.+)$""")
            for (l in cmd("LIST \"\" \"*\"").lines) {
                val m = rx.find(l) ?: continue
                val attrs = m.groupValues[1].lowercase()
                var name = m.groupValues[2].trim()
                if (!name.startsWith("\"")) name = q(name)
                if ("\\all" in attrs) all = name
                if ("\\trash" in attrs) trash = name
                if ("\\junk" in attrs) spam = name
            }
            return Folders(
                all.ifEmpty { q("[Gmail]/All Mail") },
                trash.ifEmpty { q("[Gmail]/Trash") },
                spam.ifEmpty { q("[Gmail]/Spam") },
            )
        }

        fun select(box: String) { cmd("SELECT $box") }

        fun search(query: String?): List<Long> {
            val r = cmd(if (query == null) "UID SEARCH ALL" else "UID SEARCH X-GM-RAW ${q(query)}")
            val ids = ArrayList<Long>()
            for (l in r.lines) if (l.startsWith("* SEARCH")) {
                l.removePrefix("* SEARCH").trim().split(' ').forEach { t -> t.toLongOrNull()?.let { ids += it } }
            }
            return ids.take(MAX_IDS)
        }

        /** Copies emails into another mailbox. Returns the new ids there, so we know exactly which ones to remove. */
        fun copy(uids: List<Long>, to: String): String {
            val r = cmd("UID COPY ${uids.joinToString(",")} $to")
            val m = Regex("""COPYUID \d+ \S+ ([\d:,*]+)""").find(r.status) ?: throw IOException("Gmail did not confirm the move, so nothing was deleted")
            return m.groupValues[1]
        }

        fun deleteMarked(uidSet: String) { cmd("UID STORE $uidSet +FLAGS.SILENT (\\Deleted)") }
        fun expunge() { cmd("EXPUNGE") }
    }

    private fun <T> open(user: String, pass: String, block: (Session) -> T): T {
        val sock = SSLSocketFactory.getDefault().createSocket() as SSLSocket
        return sock.use {
            it.connect(InetSocketAddress("imap.gmail.com", 993), 20_000)
            it.soTimeout = 60_000
            val s = Session(it)
            s.login(user, pass)
            try { block(s) } finally { s.logout() }
        }
    }

    private fun boxName(f: Folders, box: String) = when (box) { "spam" -> f.spam; "trash" -> f.trash; else -> f.all }

    /** Checks the address and code, and learns the mailbox names. */
    fun connect(user: String, pass: String): Folders = open(user, pass) { it.folders() }

    /** Emails matching a Gmail search in "all" mail, or every email in "spam" / "trash". */
    fun find(user: String, pass: String, f: Folders, query: String, box: String): List<Long> = open(user, pass) { s ->
        s.select(boxName(f, box))
        s.search(if (box == "all") query else null)
    }

    /** Moves emails from All Mail to Trash. They can still be brought back for 30 days. */
    fun trash(user: String, pass: String, f: Folders, uids: List<Long>) = open(user, pass) { s ->
        s.select(f.all)
        uids.chunked(CHUNK).forEach { s.copy(it, f.trash) }
    }

    /** Deletes for good. Cannot be undone, and it frees the space straight away. */
    fun deleteForever(user: String, pass: String, f: Folders, uids: List<Long>, box: String) = open(user, pass) { s ->
        if (box == "all") {
            // Gmail only really deletes what is in Trash: move there first, then remove exactly those copies
            s.select(f.all)
            val moved = uids.chunked(CHUNK).map { s.copy(it, f.trash) }
            s.select(f.trash)
            moved.forEach { s.deleteMarked(it) }
        } else {
            s.select(boxName(f, box))
            uids.chunked(CHUNK).forEach { s.deleteMarked(it.joinToString(",")) }
        }
        s.expunge()
    }
}

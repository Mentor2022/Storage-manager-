package com.storagemanager

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.FilterChip
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import android.Manifest
import android.content.pm.PackageManager
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

/** One reading of the battery. Everything here is offline and read-only. */
data class BatteryInfo(
    val percent: Int,
    val charging: Boolean,
    val plugged: String,
    val tempC: Float,
    val voltageV: Float,
    val health: String,
    val healthOk: Boolean,
    val technology: String,
    /** null when this Android version or phone does not report it. */
    val cycles: Int?,
    /** Battery "state of health" in percent (Android 14+, only on phones that report it). */
    val healthPercent: Int?,
)

object BatteryReader {
    fun read(i: Intent?, ctx: Context): BatteryInfo? {
        i ?: return null
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
        if (level < 0 || scale <= 0) return null
        val status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val plugged = when (i.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)) {
            BatteryManager.BATTERY_PLUGGED_AC -> "Charger"
            BatteryManager.BATTERY_PLUGGED_USB -> "USB"
            BatteryManager.BATTERY_PLUGGED_WIRELESS -> "Wireless"
            else -> "Not plugged in"
        }
        val (health, ok) = when (i.getIntExtra(BatteryManager.EXTRA_HEALTH, -1)) {
            BatteryManager.BATTERY_HEALTH_GOOD -> "Good" to true
            BatteryManager.BATTERY_HEALTH_OVERHEAT -> "Overheating" to false
            BatteryManager.BATTERY_HEALTH_DEAD -> "Dead, needs replacing" to false
            BatteryManager.BATTERY_HEALTH_OVER_VOLTAGE -> "Over voltage" to false
            BatteryManager.BATTERY_HEALTH_COLD -> "Too cold" to false
            BatteryManager.BATTERY_HEALTH_UNSPECIFIED_FAILURE -> "Failure" to false
            else -> "Unknown" to true
        }
        var cycles: Int? = null
        var healthPct: Int? = null
        if (Build.VERSION.SDK_INT >= 34) {
            val c = i.getIntExtra(BatteryManager.EXTRA_CYCLE_COUNT, -1)
            if (c > 0) cycles = c
            val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
            val h = bm.getIntProperty(10) // 10 = BATTERY_PROPERTY_STATE_OF_HEALTH (written as a number so older build tools still compile)
            if (h in 1..100) healthPct = h
        }
        return BatteryInfo(
            percent = level * 100 / scale,
            charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL,
            plugged = plugged,
            tempC = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10f,
            voltageV = i.getIntExtra(BatteryManager.EXTRA_VOLTAGE, 0) / 1000f,
            health = health,
            healthOk = ok,
            technology = i.getStringExtra(BatteryManager.EXTRA_TECHNOLOGY) ?: "Unknown",
            cycles = cycles,
            healthPercent = healthPct,
        )
    }

    /** Honest, specific advice based on the current reading. Nothing here claims to add battery life. */
    fun tips(b: BatteryInfo): List<String> = buildList {
        if (b.tempC >= 40f) add("🌡️ Battery is hot (${"%.0f".format(b.tempC)}°C). Take off the case, stop heavy use and keep it out of the sun while it charges.")
        if (b.charging && b.percent >= 80) add("🔌 Past 80%. Unplugging around 80% puts less stress on the battery over the years.")
        if (!b.charging && b.percent <= 20) add("🪫 Under 20%. Turn on Battery Saver now and charge soon.")
        if (b.healthPercent != null && b.healthPercent < 80) add("🔋 Battery holds about ${b.healthPercent}% of its original capacity. If it dies quickly, a replacement will help more than any app.")
        if (b.cycles != null && b.cycles >= 800) add("♻️ ${b.cycles} charge cycles. Most phone batteries wear noticeably after 500 to 1000.")
        add("🔆 Lower screen brightness and shorten screen timeout. The screen is usually the biggest drain.")
        add("🌙 Use Adaptive Battery or Battery Saver in Settings. Android decides which apps may run in the background.")
    }
}

@Composable
fun BatteryTab() {
    val ctx = LocalContext.current
    var info by remember { mutableStateOf(BatteryReader.read(ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)), ctx)) }

    // Update live while this tab is open
    DisposableEffect(ctx) {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context, i: Intent) { BatteryReader.read(i, c)?.let { info = it } }
        }
        ContextCompat.registerReceiver(ctx, receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED), ContextCompat.RECEIVER_NOT_EXPORTED)
        onDispose { try { ctx.unregisterReceiver(receiver) } catch (_: Exception) {} }
    }

    val b = info
    if (b == null) {
        Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("🔋", fontSize = 56.sp)
            Spacer(Modifier.height(10.dp))
            Text("This phone did not report battery details.")
        }
        return
    }

    val ringColor = when {
        b.percent <= 15 -> Pal.red
        b.percent <= 30 -> Pal.orange
        else -> Pal.green
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), Arrangement.Center) {
                StorageRing(b.percent / 100f, 190.dp, MaterialTheme.colorScheme.surfaceVariant, ringColor, 16.dp) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("${b.percent}%", fontSize = 40.sp, fontWeight = FontWeight.Bold)
                        Text(if (b.charging) "⚡ Charging" else "On battery", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
        item {
            Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
                Column(Modifier.fillMaxWidth().padding(16.dp)) {
                    Text("Battery health", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Stat("Condition", (if (b.healthOk) "✅ " else "⚠️ ") + b.health)
                    b.healthPercent?.let { Stat("Capacity left", "$it% of new") }
                    b.cycles?.let { Stat("Charge cycles", "$it") }
                    Stat("Temperature", "${"%.1f".format(b.tempC)}°C")
                    Stat("Voltage", "${"%.2f".format(b.voltageV)} V")
                    Stat("Power", b.plugged)
                    Stat("Type", b.technology)
                    if (b.healthPercent == null && b.cycles == null) {
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Capacity and charge cycles need Android 14 or newer and a phone that reports them.",
                            style = MaterialTheme.typography.bodySmall,
                        )
                    }
                }
            }
        }
        if (BatteryAlerts.available(ctx)) item { AlertsCard() }
        item {
            Text("Tips for you", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        }
        items(BatteryReader.tips(b)) { tip ->
            Text(tip, style = MaterialTheme.typography.bodyMedium)
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                HorizontalDivider()
                Text("Open Android's own battery tools", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                OutlinedButton(onClick = { open(ctx, Settings.ACTION_BATTERY_SAVER_SETTINGS) }, Modifier.fillMaxWidth()) { Text("🪫 Battery Saver") }
                OutlinedButton(onClick = { open(ctx, Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) }, Modifier.fillMaxWidth()) { Text("⚙️ Optimise background apps") }
                OutlinedButton(onClick = { open(ctx, "android.intent.action.POWER_USAGE_SUMMARY") }, Modifier.fillMaxWidth()) { Text("📊 See which apps use the most battery") }
            }
        }
    }
}

@Composable
private fun Stat(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.SemiBold)
    }
}

private fun open(ctx: Context, action: String) {
    try {
        ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try { ctx.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}
    }
}

@Composable
private fun AlertsCard() {
    val ctx = LocalContext.current
    var master by remember { mutableStateOf(BatteryAlerts.master(ctx)) }
    var full by remember { mutableStateOf(BatteryAlerts.full(ctx)) }
    var low by remember { mutableStateOf(BatteryAlerts.low(ctx)) }
    var over by remember { mutableStateOf(BatteryAlerts.over(ctx)) }
    var plug by remember { mutableStateOf(BatteryAlerts.plug(ctx)) }
    var lowPct by remember { mutableStateOf(BatteryAlerts.lowPct(ctx)) }
    var overMin by remember { mutableStateOf(BatteryAlerts.overMin(ctx)) }
    var mode by remember { mutableStateOf(BatteryAlerts.soundMode(ctx)) }

    fun turnOn() { master = true; BatteryAlerts.set(ctx, "master", true); BatteryAlerts.sync(ctx) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { turnOn() }

    Surface(shape = RoundedCornerShape(20.dp), color = MaterialTheme.colorScheme.surfaceVariant) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("🔔 Battery alarms", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Rings even when the app is closed", style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = master, onCheckedChange = { on ->
                    if (on) {
                        val need = Build.VERSION.SDK_INT >= 33 &&
                            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        if (need) ask.launch(Manifest.permission.POST_NOTIFICATIONS) else turnOn()
                    } else { master = false; BatteryAlerts.set(ctx, "master", false); BatteryAlerts.sync(ctx) }
                })
            }
            if (master) {
                HorizontalDivider()
                Text("Sound", fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("🔔 Tone" to 0, "🗣️ Voice" to 1, "Both" to 2).forEach { (label, v) ->
                        FilterChip(selected = mode == v, onClick = { mode = v; BatteryAlerts.set(ctx, "soundMode", v) }, label = { Text(label) })
                    }
                }
                AlertRow("Battery full", "Rings at 100% while charging", full) { full = it; BatteryAlerts.set(ctx, "full", it); BatteryAlerts.sync(ctx) }
                AlertRow("Battery low", "Rings at $lowPct% or less", low) { low = it; BatteryAlerts.set(ctx, "low", it); BatteryAlerts.sync(ctx) }
                if (low) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(10, 15, 20, 30).forEach { v ->
                            FilterChip(selected = lowPct == v, onClick = { lowPct = v; BatteryAlerts.set(ctx, "lowPct", v) }, label = { Text("$v%") })
                        }
                    }
                }
                AlertRow("Overcharge warning", "Still plugged in at 100% after $overMin min, or too hot while charging", over) { over = it; BatteryAlerts.set(ctx, "over", it); BatteryAlerts.sync(ctx) }
                if (over) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(5, 15, 30, 60).forEach { v ->
                            FilterChip(selected = overMin == v, onClick = { overMin = v; BatteryAlerts.set(ctx, "overMin", v) }, label = { Text("$v min") })
                        }
                    }
                }
                AlertRow("Charger connected / unplugged", "Tells you when charging starts and when it is unplugged", plug) { plug = it; BatteryAlerts.set(ctx, "plug", it); BatteryAlerts.sync(ctx) }
                if (mode != 0) {
                    HorizontalDivider()
                    Text("What the phone says", fontWeight = FontWeight.SemiBold)
                    if (full) MessageEditor(ctx, "full", "When full")
                    if (plug) { MessageEditor(ctx, "plug", "When plugged in"); MessageEditor(ctx, "unplug", "When unplugged") }
                    if (low) MessageEditor(ctx, "low", "When low")
                    if (over) { MessageEditor(ctx, "over", "Still plugged in"); MessageEditor(ctx, "hot", "Too hot") }
                }
                Text(
                    "Phones stop charging by themselves at 100%, so this is not a real overcharge. Staying plugged in keeps the battery warm and slowly wears it, so the warning reminds you to unplug.",
                    style = MaterialTheme.typography.bodySmall,
                )
            }
        }
    }
}

@Composable
private fun AlertRow(title: String, sub: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.SemiBold)
            Text(sub, style = MaterialTheme.typography.bodySmall)
        }
        Switch(checked = on, onCheckedChange = onChange)
    }
}

@Composable
private fun MessageEditor(ctx: Context, key: String, label: String) {
    var text by remember { mutableStateOf(BatteryAlerts.msg(ctx, key)) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it; BatteryAlerts.setMsg(ctx, key, it) },
            label = { Text(label) },
            modifier = Modifier.weight(1f),
        )
        TextButton(onClick = {
            try {
                ContextCompat.startForegroundService(
                    ctx, Intent(ctx, BatteryAlertService::class.java).setAction(BatteryAlertService.ACTION_TEST).putExtra("key", key)
                )
            } catch (_: Exception) {}
        }) { Text("▶ Test") }
    }
}
